execute as @e[type=item,nbt={Age:0s}] at @s run tag @s add forbidden

#Cactus
    execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_cactus"}] unless entity @e[tag=cont,distance=..0.5] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5,tag=!bridged] run tag @s add placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_cactus"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_cactus"}] run playsound minecraft:block.wool.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_cactus"}] at @s as @n[tag=path_block] at @s run summon minecraft:falling_block ~ ~1 ~ {NoGravity:1b,BlockState:{id:"cactus",Name:"cactus"},Invulnerable:1b,Time:-2147483648,Tags:["cactus","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=cactus] at @s run scoreboard players set @s game.data.health 15
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=cactus] at @s run scoreboard players set @s game.data.max_health 15
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=cactus] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=cactus] at @s run scoreboard players set @s game.data.cont.worth_raw 15

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_cactus"}] run kill @s

#Egg Dispenser
    #checks if at least one of the adjacent 4 blocks are path blocks and if so then legitimate
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] unless block ~ ~-1 ~ air positioned ~1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] unless block ~ ~-1 ~ air positioned ~-1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~-1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    #and if the current block is a path block then take the legitimate judgement Close
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s remove placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] run playsound minecraft:block.stone.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] at @s run setblock ~ ~ ~ dispenser
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] at @s run summon minecraft:glow_item_frame ~ ~1 ~ {Fixed:1b, Item:{count:1, id:"minecraft:egg"},Invisible:1b,Facing:1b,Invulnerable:1b,Tags:["egg_disp","disp","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.max_health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.disp_cont.damage 3
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.disp_cont.range 1
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.disp_cont.fire_rate 40

    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=egg_disp] at @s run scoreboard players set @s game.data.cont.worth_raw 50

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_egg_disp"}] run kill @s

#Water
    execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_water"}] unless entity @e[tag=cont,distance=..0.5] positioned ~ ~-1 ~ unless entity @e[tag=lava,distance=..1.75] if entity @e[tag=path_block,distance=..0.5,tag=!bridged] run tag @s add placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_water"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_water"}] run playsound item.bucket.empty block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_water"}] at @s as @n[tag=path_block,tag=!bridged] at @s run setblock ~ ~1 ~ water

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_water"}] at @s as @n[tag=path_block,tag=!bridged] at @s run summon minecraft:marker ~ ~1 ~ {Tags:["water","cont","newbie"],CustomName:"\u00a7b水"}


    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=water] at @s run scoreboard players set @s game.data.health 80
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=water] at @s run scoreboard players set @s game.data.max_health 80
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=water] at @s run scoreboard players set @s game.data.cont.viscosity 1
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=water] at @s run scoreboard players set @s game.data.cont.worth_raw 50

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_water"}] run kill @s

#Trapdoor
    execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] unless entity @e[tag=cont,distance=..0.5] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] run playsound block.wood.place block @a ~ ~ ~

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=-45..45] run summon minecraft:marker ~ ~1 ~ {Tags:["trapdoor","cont","south","newbie"],CustomName:"\u00a76活板门"}
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=45..135] run summon minecraft:marker ~ ~1 ~ {Tags:["trapdoor","cont","west","newbie"],CustomName:"\u00a76活板门"}
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=135..-135] run summon minecraft:marker ~ ~1 ~ {Tags:["trapdoor","cont","north","newbie"],CustomName:"\u00a76活板门"}
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=-135..-45] run summon minecraft:marker ~ ~1 ~ {Tags:["trapdoor","cont","east","newbie"],CustomName:"\u00a76活板门"}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @e[tag=cont,tag=trapdoor,tag=north] at @s run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=north,open=false]
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @e[tag=cont,tag=trapdoor,tag=west] at @s run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=west,open=false]
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @e[tag=cont,tag=trapdoor,tag=east] at @s run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=east,open=false]
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @e[tag=cont,tag=trapdoor,tag=south] at @s run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=south,open=false]

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @e[tag=cont,tag=trapdoor] at @s as @n[tag=path_block] if entity @s[tag=bridged] run tag @n[tag=cont,tag=trapdoor] add on_bridge

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=trapdoor] at @s run scoreboard players set @s game.data.health 80
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=trapdoor] at @s run scoreboard players set @s game.data.max_health 80
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=trapdoor,tag=!on_bridge] at @s run scoreboard players set @s game.data.cont.capacity 2
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=trapdoor,tag=on_bridge] at @s run scoreboard players set @s game.data.cont.capacity 2147483647
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=trapdoor] at @s run scoreboard players set @s game.data.cont.worth_raw 150

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=trapdoor] at @s run scoreboard players set @s game.data.cont.mobs_trapped 0

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_trapdoor"}] run kill @s

#Arrow Dispenser
    #checks if at least one of the adjacent 4 blocks are path blocks and if so then legitimate
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] unless block ~ ~-1 ~ air positioned ~1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] unless block ~ ~-1 ~ air positioned ~-1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~-1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    #and if the current block is a path block then take the legitimate judgement Close
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s remove placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] run playsound minecraft:block.stone.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] at @s run setblock ~ ~ ~ dispenser
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] at @s run summon minecraft:glow_item_frame ~ ~1 ~ {Fixed:1b, Item:{count:1, id:"minecraft:arrow"},Invisible:1b,Facing:1b,Invulnerable:1b,Tags:["arrow_disp","disp","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.max_health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.disp_cont.damage 5
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.disp_cont.range 3
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.disp_cont.fire_rate 40

    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=arrow_disp] at @s run scoreboard players set @s game.data.cont.worth_raw 150

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_arrow_disp"}] run kill @s

#Iron Bars
    execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] unless entity @e[tag=cont,distance=..0.5] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] run playsound block.iron.place block @a ~ ~ ~

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=-45..45] run summon minecraft:marker ~ ~1 ~ {Tags:["iron_bars","cont","+z","z","newbie"],CustomName:"\u00a77铁栅栏"}
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=45..135] run summon minecraft:marker ~ ~1 ~ {Tags:["iron_bars","cont","-x","x","newbie"],CustomName:"\u00a77铁栅栏"}
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=135..-135] run summon minecraft:marker ~ ~1 ~ {Tags:["iron_bars","cont","-z","z","newbie"],CustomName:"\u00a77铁栅栏"}
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] at @s as @n[tag=path_block] at @s if entity @s[y_rotation=-135..-45] run summon minecraft:marker ~ ~1 ~ {Tags:["iron_bars","cont","+x","x","newbie"],CustomName:"\u00a77铁栅栏"}

    execute as @e[tag=cont,tag=iron_bars,tag=newbie,tag=+z] at @s positioned ~ ~-1 ~-1 unless entity @e[tag=path_block,distance=..0.5] run tag @s add reversed
    execute as @e[tag=cont,tag=iron_bars,tag=newbie,tag=-z] at @s positioned ~ ~-1 ~1 unless entity @e[tag=path_block,distance=..0.5] run tag @s add reversed
    execute as @e[tag=cont,tag=iron_bars,tag=newbie,tag=+x] at @s positioned ~-1 ~-1 ~ unless entity @e[tag=path_block,distance=..0.5] run tag @s add reversed
    execute as @e[tag=cont,tag=iron_bars,tag=newbie,tag=-x] at @s positioned ~1 ~-1 ~ unless entity @e[tag=path_block,distance=..0.5] run tag @s add reversed

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=iron_bars] at @s run scoreboard players set @s game.data.health 1600
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=iron_bars] at @s run scoreboard players set @s game.data.max_health 1600
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=iron_bars] at @s run scoreboard players set @s game.data.cont.worth_raw 200

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_iron_bars"}] run kill @s

    #tag @e[tag=cont,tag=iron_bars,tag=newbie] remove newbie

#Slime Dispenser
    #checks if at least one of the adjacent 4 blocks are path blocks and if so then legitimate
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] unless block ~ ~-1 ~ air positioned ~1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] unless block ~ ~-1 ~ air positioned ~-1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~-1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    #and if the current block is a path block then take the legitimate judgement Close
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s remove placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] run playsound minecraft:block.stone.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] at @s run setblock ~ ~ ~ dispenser
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] at @s run summon minecraft:glow_item_frame ~ ~1 ~ {Fixed:1b, Item:{count:1, id:"minecraft:slime_ball"},Invisible:1b,Facing:1b,Invulnerable:1b,Tags:["slime_disp","disp","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.max_health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.disp_cont.duration 20
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.disp_cont.range 3
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.disp_cont.fire_rate 40
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=slime_disp] at @s run scoreboard players set @s game.data.cont.worth_raw 100

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_slime_disp"}] run kill @s

#TNT
    execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] unless entity @e[tag=cont,distance=..0.5] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] run playsound block.grass.break block @a ~ ~ ~ 1 0.8
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] run playsound entity.tnt.primed block @a ~ ~ ~ 1 1

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] at @s as @n[tag=path_block] at @s run summon tnt ~ ~1 ~ {Tags:["inferior_cont","tnt"],fuse:41s,Motion:[0d,0.35d,0d]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] run kill @s
    
    #finale
        execute if score #global game.level matches 1000 as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] if entity @e[tag=tnt_launchpad,distance= ..0.7] run tag @n[tag=tnt_launchpad] add launch_tnt
        execute if score #global game.level matches 1000 as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_tnt"}] if entity @e[tag=tnt_launchpad,distance= ..0.7] run kill @s

        execute as @e[tag=tnt_launchpad,tag=launch_tnt] at @s run particle poof ~ ~ ~ 0 0 0 0.1 50
        execute as @e[tag=tnt_launchpad,tag=launch_tnt] at @s run playsound block.grass.break block @a ~ ~ ~ 1 0.8
        execute as @e[tag=tnt_launchpad,tag=launch_tnt] at @s run playsound entity.tnt.primed block @a ~ ~ ~ 1 1

        execute as @e[tag=tnt_launchpad,tag=launch_tnt] at @s run summon tnt ~ ~-0.5 ~ {Tags:["inferior_cont","tnt","crystal_tnt"],fuse:41s,Motion:[0d,1.5d,0d]}

        tag @e[tag=tnt_launchpad] remove launch_tnt

#Snow Dispenser
    #checks if at least one of the adjacent 4 blocks are path blocks and if so then legitimate
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] unless block ~ ~-1 ~ air positioned ~1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] unless block ~ ~-1 ~ air positioned ~-1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~-1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    #and if the current block is a path block then take the legitimate judgement Close
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s remove placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] run playsound minecraft:block.stone.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] at @s run setblock ~ ~ ~ dispenser
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] at @s run summon minecraft:glow_item_frame ~ ~1 ~ {Fixed:1b, Item:{count:1, id:"minecraft:snowball"},Invisible:1b,Facing:1b,Invulnerable:1b,Tags:["snow_disp","disp","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.max_health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.disp_cont.duration 10
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.disp_cont.range 3
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.disp_cont.fire_rate 40

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=snow_disp] at @s run scoreboard players set @s game.data.cont.worth_raw 100


    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_snow_disp"}] run kill @s

#Lava
    execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_lava"}] unless entity @e[tag=water,distance=..1.75] unless entity @e[tag=cont,distance=..0.5] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5,tag=!bridged] run tag @s add placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_lava"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_lava"}] run playsound item.bucket.empty_lava block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_lava"}] at @s as @n[tag=path_block,tag=!bridged] at @s run setblock ~ ~1 ~ lava

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_lava"}] at @s as @n[tag=path_block,tag=!bridged] at @s run summon minecraft:marker ~ ~1 ~ {Tags:["lava","cont","newbie"],CustomName:"\u00a76岩浆"}


    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=lava] at @s run scoreboard players set @s game.data.health 80
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=lava] at @s run scoreboard players set @s game.data.max_health 80
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=lava] at @s run scoreboard players set @s game.data.cont.damage 10

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=lava] at @s run scoreboard players set @s game.data.cont.worth_raw 200

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_lava"}] run kill @s

#Fireball Dispenser
    #checks if at least one of the adjacent 4 blocks are path blocks and if so then legitimate
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] unless block ~ ~-1 ~ air positioned ~1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] unless block ~ ~-1 ~ air positioned ~-1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~-1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    #and if the current block is a path block then take the legitimate judgement Close
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s remove placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] run playsound minecraft:block.stone.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] at @s run setblock ~ ~ ~ dispenser
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] at @s run summon minecraft:glow_item_frame ~ ~1 ~ {Fixed:1b, Item:{count:1, id:"minecraft:fire_charge"},Invisible:1b,Facing:1b,Invulnerable:1b,Tags:["fireball_disp","disp","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.max_health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.disp_cont.duration 40
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.disp_cont.range 3
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.disp_cont.fire_rate 40

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=fireball_disp] at @s run scoreboard players set @s game.data.cont.worth_raw 150

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_fireball_disp"}] run kill @s

#Ender Pearl Dispenser
    #checks if at least one of the adjacent 4 blocks are path blocks and if so then legitimate
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] unless block ~ ~-1 ~ air positioned ~1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] unless block ~ ~-1 ~ air positioned ~-1 ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] unless block ~ ~-1 ~ air positioned ~ ~-1 ~-1 if entity @e[tag=path_block,distance=..0.5] run tag @s add placed
    #and if the current block is a path block then take the legitimate judgement Close
        execute as @e[type=item,tag=!forbidden] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] positioned ~ ~-1 ~ if entity @e[tag=path_block,distance=..0.5] run tag @s remove placed
    
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] run particle poof ~ ~ ~ 0 0 0 0.1 50
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] run playsound minecraft:block.stone.place block @a ~ ~ ~
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] at @s run setblock ~ ~ ~ dispenser
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] at @s run summon minecraft:glow_item_frame ~ ~1 ~ {Fixed:1b, Item:{count:1, id:"minecraft:ender_pearl"},Invisible:1b,Facing:1b,Invulnerable:1b,Tags:["ender_pearl_disp","disp","cont","newbie"]}

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=ender_pearl_disp] at @s run scoreboard players set @s game.data.health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=ender_pearl_disp] at @s run scoreboard players set @s game.data.max_health 150
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=ender_pearl_disp] at @s run scoreboard players set @s game.data.cont.damage_cd 0

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=ender_pearl_disp] at @s run scoreboard players set @s game.data.disp_cont.range 3
    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=ender_pearl_disp] at @s run scoreboard players set @s game.data.disp_cont.fire_rate 80

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s as @n[tag=cont,tag=ender_pearl_disp] at @s run scoreboard players set @s game.data.cont.worth_raw 450

    execute as @e[type=item,tag=!forbidden,tag=placed] at @s if items entity @s contents *[custom_data~{id:"cont_ender_pearl_disp"}] run kill @s

tag @e[tag=forbidden] remove forbidden
