execute if score #global game.mechanism.active_ticks matches 10.. if score #global game.level matches 4 as @a[x=-16,y=0,z=-16,dx=32,dy=10,dz=32,nbt={OnGround:1b}] at @s run damage @s 114514 fall
execute if score #global game.mechanism.active_ticks matches 10.. if score #global game.level matches 8 as @a[x=-16,y=0,z=-16,dx=32,dy=8,dz=32,nbt={OnGround:1b}] at @s run damage @s 114514 fall
execute if score #global game.mechanism.active_ticks matches 10.. as @a at @s unless entity @s[nbt={Fire:-20s}] run damage @s 10000000 lava

execute if score #global game.data.speed_up matches 0 run effect clear @a speed
execute if score #global game.data.speed_up matches 1 run effect give @a speed infinite 1 true
execute if score #global game.data.speed_up matches 2 run effect give @a speed infinite 3 true

#gives the player(s) a green overlay on their health hearts
    execute if score #global game.data.poisoning matches 2 run tellraw @a "\u00a72泥\u00a7a中毒\u00a72了! 从现在起, 泥在每波怪开始的时候会失去\u00a7c1\u2665\u00a72。注意这个伤害可\u00a74致命\u00a72!"
    execute if score #global game.data.poisoning matches 2 run scoreboard players set #global game.data.poisoning 1
    effect clear @a poison
    execute if score #global game.data.poisoning matches 1 run effect give @a poison 1 0 true
