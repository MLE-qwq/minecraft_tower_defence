function game:load_level_generic.before

scoreboard players set #global game.data.what_happens_to_water 1
#water freezes to ice

#set biome
    execute in overworld run fillbiome -24 -8 -24 24 24 24 snowy_slopes

#displaying instructions in chat
    tellraw @a "\u00a7b第9关: 半山坡"

    tellraw @a "\u00a7a关于:"
    tellraw @a "\u00a7a- 地形: \u00a7f闹吃, MLE_qwq"
    tellraw @a "\u00a77> (因为地形是从原版地形里摘的=w=)"
    tellraw @a "\u00a7a- 代码: \u00a7fMLE_qwq"
    
#specifying path blocks and pre-built path blocks
    execute in overworld run setblock 15 -2 -15 dirt
#specifying dedicated original block
    execute in overworld run setblock 15 -2 -13 snow_block

#marking
    execute in overworld run summon minecraft:marker 16 -64 16 {Tags:["terrain_origin"],CustomName:"Terrain Origin"}
    execute in overworld run summon minecraft:marker -2 3 -14 {Tags:["path_start","mob_spawnpoint"],CustomName:"Path Start"}
    execute in overworld run summon minecraft:marker -2 3 5 {Tags:["path_ending"],CustomName:"Path Ending"}

#initial currency
    scoreboard players set #global game.data.currency 450

#stores wave data
    scoreboard players set #global game.state.total_waves 10
    #wave 1: wolf * 10
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 2: snow golem * 15
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 11
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 2
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 3: wolf * 20
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 20
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 3
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 35
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 4: snow golem * 25
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 25
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 11
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 4
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 60
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 5: spider jockey * 4
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 4
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 90
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 6: wolf * 30
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 30
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 6
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 135
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 7: snow golem * 35
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 35
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 11
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 7
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 170
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 8: wolf * 40
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 40
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 8
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 220
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 9: snow golem * 45
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 45
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 11
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 9
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 270
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 10
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 10: spider jockey * 8
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 8
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 320
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

function game:load_level_generic.after
