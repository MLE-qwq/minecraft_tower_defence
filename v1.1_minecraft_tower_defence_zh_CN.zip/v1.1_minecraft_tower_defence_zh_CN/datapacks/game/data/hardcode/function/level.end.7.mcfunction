#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 8.. run scoreboard players set #global game.saves.levels_unlocked 8
