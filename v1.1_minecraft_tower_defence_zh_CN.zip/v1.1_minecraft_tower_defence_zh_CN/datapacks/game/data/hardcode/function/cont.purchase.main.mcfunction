#quits if game paused
    execute if score #global game.state.paused matches 1 run return fail
    execute if score #global game.mechanism.items_falling matches 1 run return fail

#Cactus
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 run tellraw @a[scores={game.trigger.purchase=1},limit=1] "\u00a7c尚未解锁装置\u00a72仙人掌\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run scoreboard players remove #global game.data.currency_new 15

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currency matches 15.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a72仙人掌\u00a7c呜喵! 至少需要\u00a7a$15\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currency matches 15.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run give @s minecraft:cactus[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a72仙人掌",lore=["","\u00a7b用途: 对接触到的怪物造成\u00a7c10点伤害\u00a7b","\u00a7b并失去\u00a7c10点耐久\u00a7b。","\u00a7b初始时有\u00a7c15点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。","\u00a7e不可放置于木板上。"],custom_data={id:"cont_cactus",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$15\u00a7b购买了\u00a72仙人掌\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run scoreboard players remove #global game.data.currency 15

#Egg Dispenser
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 run tellraw @a[scores={game.trigger.purchase=2},limit=1] "\u00a7c尚未解锁装置\u00a7e鸡蛋发射器\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run scoreboard players remove #global game.data.currency_new 50

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currency matches 50.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a7e鸡蛋发射器\u00a7c呜喵! 至少需要\u00a7a$50\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currency matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run give @s minecraft:egg[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7e鸡蛋发射器",lore=["","\u00a7b用途: 往四周发射鸡蛋。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_egg_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$50\u00a7b购买了\u00a7e鸡蛋发射器\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run scoreboard players remove #global game.data.currency 50

#Water
    execute unless score #global game.saves.cont_unlocked.water matches 1 run tellraw @a[scores={game.trigger.purchase=3},limit=1] "\u00a7c尚未解锁装置\u00a7b水\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run scoreboard players remove #global game.data.currency_new 50

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currency matches 50.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a7b水\u00a7c呜喵! 至少需要\u00a7a$50\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currency matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run give @s minecraft:water_bucket[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7b水",lore=["","\u00a7b用途: 减缓与之接触到的怪物的速度。","\u00a7e使用方式: 将物品丢弃至路径上。","\u00a7e不可放置于木板上。"],custom_data={id:"cont_water",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$50\u00a7b购买了\u00a7b水\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run scoreboard players remove #global game.data.currency 50

#Trapdoor
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 run tellraw @a[scores={game.trigger.purchase=4},limit=1] "\u00a7c尚未解锁装置\u00a76活板门\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run scoreboard players remove #global game.data.currency_new 150

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currency matches 150.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a76活板门\u00a7c呜喵! 至少需要\u00a7a$150\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currency matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run give @s minecraft:oak_trapdoor[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a76活板门",lore=["","\u00a7b用途: 困住并击杀移速低于","\u00a7b4格每秒的怪物。","\u00a7b放置于木板上时容量无穷大。","\u00a7e使用方式: 将物品丢弃至路径上。"," "],custom_data={id:"cont_trapdoor",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$150\u00a7b购买了\u00a76活板门\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run scoreboard players remove #global game.data.currency 150

#Arrow Dispenser
    execute unless score #global game.saves.cont_unlocked.arrow_disp matches 1 run tellraw @a[scores={game.trigger.purchase=5},limit=1] "\u00a7c尚未解锁装置\u00a77箭矢发射器\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s run scoreboard players remove #global game.data.currency_new 150

    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s unless score #global game.data.currency matches 150.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a77箭矢发射器\u00a7c呜喵! 至少需要\u00a7a$150\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s unless score #global game.data.currency matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run give @s minecraft:arrow[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a77箭矢发射器",lore=["","\u00a7b用途: 向四周发射箭矢。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_arrow_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$150\u00a7b购买了\u00a77箭矢发射器\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run scoreboard players remove #global game.data.currency 150

#Iron Bars
    execute unless score #global game.saves.cont_unlocked.iron_bars matches 1 run tellraw @a[scores={game.trigger.purchase=6},limit=1] "\u00a7c尚未解锁装置\u00a77铁栅栏\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s run scoreboard players remove #global game.data.currency_new 200

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s unless score #global game.data.currency matches 200.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a77铁栅栏\u00a7c呜喵! 至少需要\u00a7a$200\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s unless score #global game.data.currency matches 200.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run give @s minecraft:iron_bars[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a77铁栅栏",lore=[" ","\u00a7b用途: 阻挡怪物前进。","\u00a7b每与1个怪物接触1秒会失去\u00a7c20点耐久\u00a7b,","\u00a7b可叠加。初始时有\u00a7c1600点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。"],custom_data={id:"cont_iron_bars",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$200\u00a7b购买了\u00a77铁栅栏\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run scoreboard players remove #global game.data.currency 200

#Slime Dispenser
    execute unless score #global game.saves.cont_unlocked.slime_disp matches 1 run tellraw @a[scores={game.trigger.purchase=7},limit=1] "\u00a7c尚未解锁装置\u00a7a粘液发射器\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s run scoreboard players remove #global game.data.currency_new 100

    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s unless score #global game.data.currency matches 100.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a7a粘液发射器\u00a7c呜喵! 至少需要\u00a7a$100\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s unless score #global game.data.currency matches 100.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run give @s minecraft:slime_ball[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7a粘液发射器",lore=[" ","\u00a7b用途: 向四周发射粘液球。","\u00a7b被击中的怪物将会被减速","\u00a7b至其原始速度的一半。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_slime_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$100\u00a7b购买了\u00a7a粘液发射器\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run scoreboard players remove #global game.data.currency 100

#TNT
    execute unless score #global game.saves.cont_unlocked.tnt matches 1 run tellraw @a[scores={game.trigger.purchase=8},limit=1] "\u00a7c尚未解锁装置\u00a7cTNT\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s run scoreboard players remove #global game.data.currency_new 250

    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s unless score #global game.data.currency matches 250.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a7cTNT\u00a7c呜喵! 至少需要\u00a7a$250\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s unless score #global game.data.currency matches 250.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run give @s minecraft:tnt[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7cTNT",lore=["","\u00a7b用途: 在2秒内爆炸。","\u00a7b爆炸会对4格内的怪物造成","\u00a7c500点伤害\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。"],custom_data={id:"cont_tnt",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$250\u00a7b购买了\u00a7cTNT\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run scoreboard players remove #global game.data.currency 250

#Snow Dispenser
    execute unless score #global game.saves.cont_unlocked.snow_disp matches 1 run tellraw @a[scores={game.trigger.purchase=9},limit=1] "\u00a7c尚未解锁装置\u00a7f雪球发射器\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s run scoreboard players remove #global game.data.currency_new 100

    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s unless score #global game.data.currency matches 100.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a7f雪球发射器\u00a7c呜喵! 至少需要\u00a7a$100\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s unless score #global game.data.currency matches 100.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run give @s minecraft:snowball[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7f雪球发射器",lore=["","\u00a7b用途: 往四周发射雪球。","\u00a7b雪球会暂时将击中的怪物冰冻。","\u00a7b届时怪物将无法移动。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_snow_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$100\u00a7b购买了\u00a7f雪球发射器\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run scoreboard players remove #global game.data.currency 100

#Lava
    execute unless score #global game.saves.cont_unlocked.lava matches 1 run tellraw @a[scores={game.trigger.purchase=10},limit=1] "\u00a7c尚未解锁装置\u00a76岩浆\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s run scoreboard players remove #global game.data.currency_new 200

    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s unless score #global game.data.currency matches 200.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a76岩浆\u00a7c呜喵! 至少需要\u00a7a$200\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s unless score #global game.data.currency matches 200.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run give @s minecraft:lava_bucket[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a76岩浆",lore=["","\u00a7b用途: 持续对接触的怪物","\u00a7b造成伤害并让其着火。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。"],custom_data={id:"cont_lava",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$200\u00a7b购买了\u00a76岩浆\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run scoreboard players remove #global game.data.currency 200

#Fireball Dispenser
    execute unless score #global game.saves.cont_unlocked.fireball_disp matches 1 run tellraw @a[scores={game.trigger.purchase=11},limit=1] "\u00a7c尚未解锁装置\u00a76火球发射器\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s run scoreboard players remove #global game.data.currency_new 150

    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s unless score #global game.data.currency matches 150.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a76火球发射器\u00a7c呜喵! 至少需要\u00a7a$150\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s unless score #global game.data.currency matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run give @s minecraft:fire_charge[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a76火球发射器",lore=[" ","\u00a7b用途: 向四周发射火球。","\u00a7b被击中的怪物将会着火。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_fireball_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$150\u00a7b购买了\u00a76火球发射器\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run scoreboard players remove #global game.data.currency 150

#Ender Pearl Dispenser
    execute unless score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 run tellraw @a[scores={game.trigger.purchase=12},limit=1] "\u00a7c尚未解锁装置\u00a73末影珍珠发射器\u00a7c呜喵! QAQ"
    execute unless score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s run scoreboard players remove #global game.data.currency_new 450

    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s unless score #global game.data.currency matches 450.. run tellraw @s ["\u00a7c没有足够的货币以购买\u00a73末影珍珠发射器\u00a7c呜喵! 至少需要\u00a7a$450\u00a7c, 但老大只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s unless score #global game.data.currency matches 450.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run give @s minecraft:ender_pearl[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a73末影珍珠发射器",lore=[" ","\u00a7b用途: 往四周发射末影珍珠。","\u00a7b末影珍珠会将击中的怪物","\u00a7b传送回其刷新点。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_ender_pearl_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run tellraw @a [{"selector":"@s"},"\u00a7b花费\u00a7a$450\u00a7b购买了\u00a73末影珍珠发射器\u00a7b, 剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run scoreboard players remove #global game.data.currency 450
