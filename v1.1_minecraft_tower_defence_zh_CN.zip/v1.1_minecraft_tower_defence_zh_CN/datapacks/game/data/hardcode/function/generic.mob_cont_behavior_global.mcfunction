#preventing water contraption from flowing everywhere
    #water freezing
        execute if score #global game.data.what_happens_to_water matches 1 run tag @e[tag=water] add ice
        execute if score #global game.data.what_happens_to_water matches 1 as @e[tag=water] at @s run function game:cont_health_display_removal with entity @s
        execute if score #global game.data.what_happens_to_water matches 1 as @e[tag=water] at @s run particle minecraft:poof ~ ~ ~ 0 0 0 0.1 25
        execute if score #global game.data.what_happens_to_water matches 1 run tag @e[tag=water] add cannot_be_selected
        tag @e[tag=ice] remove water
        execute as @e[tag=ice] at @s run setblock ~ ~ ~ air
        execute as @e[tag=ice] at @s run setblock ~ ~-1 ~ ice
    #water evaporating
        execute if score #global game.data.what_happens_to_water matches 2 as @e[tag=water] at @s run function game:cont_health_display_removal with entity @s
        execute if score #global game.data.what_happens_to_water matches 2 as @e[tag=water] at @s run setblock ~ ~ ~ air
        execute if score #global game.data.what_happens_to_water matches 2 as @e[tag=water] at @s run playsound block.fire.extinguish block @a ~ ~1 ~ 1 1
        execute if score #global game.data.what_happens_to_water matches 2 as @e[tag=water] at @s run particle minecraft:poof ~ ~ ~ 0 0 0 0.1 25
        execute if score #global game.data.what_happens_to_water matches 2 run kill @e[tag=water]

    execute as @e[tag=water] at @s run setblock ~ ~ ~ water replace

    execute as @e[tag=water] at @s positioned ~1 ~ ~ if block ~ ~ ~ air run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~-1 ~ ~ if block ~ ~ ~ air run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~ ~ ~1 if block ~ ~ ~ air run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~ ~ ~-1 if block ~ ~ ~ air run setblock ~ ~ ~ structure_void

    execute as @e[tag=water] at @s positioned ~1 ~ ~ if block ~ ~ ~ #replaceable unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~-1 ~ ~ if block ~ ~ ~ #replaceable unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~ ~ ~1 if block ~ ~ ~ #replaceable unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~ ~ ~-1 if block ~ ~ ~ #replaceable unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void

    execute as @e[tag=water] at @s positioned ~1 ~ ~ if block ~ ~ ~ cobweb unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~-1 ~ ~ if block ~ ~ ~ cobweb unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~ ~ ~1 if block ~ ~ ~ cobweb unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=water] at @s positioned ~ ~ ~-1 if block ~ ~ ~ cobweb unless block ~ ~ ~ water[level=0] run setblock ~ ~ ~ structure_void

#Lava
    execute as @e[tag=lava] at @s run setblock ~ ~ ~ lava replace

    execute as @e[tag=lava] at @s positioned ~1 ~ ~ if block ~ ~ ~ air run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~-1 ~ ~ if block ~ ~ ~ air run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~ ~ ~1 if block ~ ~ ~ air run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~ ~ ~-1 if block ~ ~ ~ air run setblock ~ ~ ~ structure_void

    execute as @e[tag=lava] at @s positioned ~1 ~ ~ if block ~ ~ ~ #replaceable unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~-1 ~ ~ if block ~ ~ ~ #replaceable unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~ ~ ~1 if block ~ ~ ~ #replaceable unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~ ~ ~-1 if block ~ ~ ~ #replaceable unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void

    execute as @e[tag=lava] at @s positioned ~1 ~ ~ if block ~ ~ ~ cobweb unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~-1 ~ ~ if block ~ ~ ~ cobweb unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~ ~ ~1 if block ~ ~ ~ cobweb unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void
    execute as @e[tag=lava] at @s positioned ~ ~ ~-1 if block ~ ~ ~ cobweb unless block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ structure_void

#trapdoors opening and closing up depending on whether there are mobs nearby
    execute as @e[tag=cont,tag=trapdoor] at @s unless entity @e[tag=mob,distance=..1] if block ~ ~-1 ~ oak_trapdoor[open=true] run playsound block.wooden_trapdoor.close block @a ~ ~2 ~ 1 1
    execute as @e[tag=cont,tag=trapdoor,tag=north] at @s unless entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=north,open=false]
    execute as @e[tag=cont,tag=trapdoor,tag=west] at @s unless entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=west,open=false]
    execute as @e[tag=cont,tag=trapdoor,tag=east] at @s unless entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=east,open=false]
    execute as @e[tag=cont,tag=trapdoor,tag=south] at @s unless entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=south,open=false]
    
    execute as @e[tag=cont,tag=trapdoor] at @s if score @s game.data.cont.mobs_trapped >= @s game.data.cont.capacity if block ~ ~-1 ~ oak_trapdoor[open=true] run playsound block.wooden_trapdoor.close block @a ~ ~2 ~ 1 1
    execute as @e[tag=cont,tag=trapdoor,tag=north] at @s if score @s game.data.cont.mobs_trapped >= @s game.data.cont.capacity run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=north,open=false]
    execute as @e[tag=cont,tag=trapdoor,tag=west] at @s if score @s game.data.cont.mobs_trapped >= @s game.data.cont.capacity run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=west,open=false]
    execute as @e[tag=cont,tag=trapdoor,tag=east] at @s if score @s game.data.cont.mobs_trapped >= @s game.data.cont.capacity run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=east,open=false]
    execute as @e[tag=cont,tag=trapdoor,tag=south] at @s if score @s game.data.cont.mobs_trapped >= @s game.data.cont.capacity run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=south,open=false]

    execute as @e[tag=cont,tag=trapdoor] at @s if score @s game.data.cont.mobs_trapped < @s game.data.cont.capacity if entity @e[tag=mob,distance=..1] if block ~ ~-1 ~ oak_trapdoor[open=false] run playsound block.wooden_trapdoor.open block @a ~ ~2 ~ 1 1
    execute as @e[tag=cont,tag=trapdoor,tag=north] at @s if score @s game.data.cont.mobs_trapped < @s game.data.cont.capacity if entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=north,open=true]
    execute as @e[tag=cont,tag=trapdoor,tag=west] at @s if score @s game.data.cont.mobs_trapped < @s game.data.cont.capacity if entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=west,open=true]
    execute as @e[tag=cont,tag=trapdoor,tag=east] at @s if score @s game.data.cont.mobs_trapped < @s game.data.cont.capacity if entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=east,open=true]
    execute as @e[tag=cont,tag=trapdoor,tag=south] at @s if score @s game.data.cont.mobs_trapped < @s game.data.cont.capacity if entity @e[tag=mob,distance=..1] run setblock ~ ~-1 ~ oak_trapdoor[half=top,facing=south,open=true]

#iron bars
    execute as @e[tag=cont,tag=iron_bars] at @s run setblock ~ ~ ~ air
    execute as @e[tag=cont,tag=iron_bars,tag=z,tag=!reversed] at @s run setblock ~ ~ ~ iron_bars[north=false,south=false,east=true,west=true]
    execute as @e[tag=cont,tag=iron_bars,tag=x,tag=reversed] at @s run setblock ~ ~ ~ iron_bars[north=false,south=false,east=true,west=true]
    execute as @e[tag=cont,tag=iron_bars,tag=x,tag=!reversed] at @s run setblock ~ ~ ~ iron_bars[north=true,south=true,east=false,west=false]
    execute as @e[tag=cont,tag=iron_bars,tag=z,tag=reversed] at @s run setblock ~ ~ ~ iron_bars[north=true,south=true,east=false,west=false]
    execute as @e[tag=cont,tag=iron_bars] at @s if score @s game.data.health matches ..0 run tag @s add kill
#tnt - when game paused, freeze fusing timer
    scoreboard objectives add _ dummy
    execute as @e[tag=inferior_cont,tag=tnt] at @s store result score @s _ run data get entity @s fuse
    execute if score #global game.state.paused matches 1 as @e[tag=inferior_cont,tag=tnt] at @s run scoreboard players add @s _ 1
    execute if score #global game.state.paused matches 1 as @e[tag=inferior_cont,tag=tnt] at @s store result entity @s fuse short 1 run scoreboard players get @s _
    #finale
        scoreboard objectives add _ dummy
        execute store result score #global _ run bossbar get finale value
        execute as @e[tag=inferior_cont,tag=tnt,tag=crystal_tnt,nbt={fuse:1s}] at @s run scoreboard players remove #global _ 400
        execute store result bossbar finale value run scoreboard players get #global _
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 1 2
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s run playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 1 0.8
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s as @e[tag=cont,distance=..4] at @s run scoreboard players remove @s game.data.health 40
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s as @e[tag=mob,distance=..4] at @s run scoreboard players remove @s game.data.health 400
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s as @e[tag=mob,distance=..4] at @s unless score @s game.data.health matches ..0 run damage @s 1 out_of_world
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s as @e[tag=mob,distance=..4] at @s unless score @s game.data.health matches ..0 run scoreboard players set @s game.mechanism.display_damage_on_display_entity 1
    execute as @e[tag=inferior_cont,tag=tnt,nbt={fuse:1s}] at @s run kill @s

execute as @e[tag=cont] at @s if score @s game.data.health matches ..0 run scoreboard players set @s game.data.health 0
execute as @e[tag=mob] at @s if score @s game.data.health matches ..0 run scoreboard players set @s game.data.health 0

execute as @e[tag=cont] at @s if score @s game.data.health matches ..0 run tag @s add kill
