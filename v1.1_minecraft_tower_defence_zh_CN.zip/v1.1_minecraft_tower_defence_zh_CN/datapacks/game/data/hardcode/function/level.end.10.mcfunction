#unlock contraptions
    execute in overworld unless score #global game.saves.cont_unlocked.fireball_disp matches 1 run scoreboard players set #global game.saves.cont_unlocked.fireball_disp 2
#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 11.. run scoreboard players set #global game.saves.levels_unlocked 11
