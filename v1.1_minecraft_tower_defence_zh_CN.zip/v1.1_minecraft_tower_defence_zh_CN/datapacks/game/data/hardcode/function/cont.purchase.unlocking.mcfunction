#Cactus
    execute if score #global game.saves.cont_unlocked.cactus matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.cactus matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a72仙人掌\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.cactus matches 2 run scoreboard players set #global game.saves.cont_unlocked.cactus 1
#Water
    execute if score #global game.saves.cont_unlocked.water matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.water matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a7b水\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.water matches 2 run scoreboard players set #global game.saves.cont_unlocked.water 1
#Egg Dispenser
    execute if score #global game.saves.cont_unlocked.egg_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.egg_disp matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a7e鸡蛋发射器\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.egg_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.egg_disp 1
#Trapdoor
    execute if score #global game.saves.cont_unlocked.trapdoor matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.trapdoor matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a76活板门\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.trapdoor matches 2 run scoreboard players set #global game.saves.cont_unlocked.trapdoor 1
#Arrow Dispenser
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a77箭矢发射器\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.arrow_disp 1
#Iron Bars
    execute if score #global game.saves.cont_unlocked.iron_bars matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.iron_bars matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a77铁栅栏\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.iron_bars matches 2 run scoreboard players set #global game.saves.cont_unlocked.iron_bars 1
#Slime Dispenser
    execute if score #global game.saves.cont_unlocked.slime_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.slime_disp matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a7a粘液发射器\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.slime_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.slime_disp 1
#TNT
    execute if score #global game.saves.cont_unlocked.tnt matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.tnt matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a7cTNT\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.tnt matches 2 run scoreboard players set #global game.saves.cont_unlocked.tnt 1
#Snow Dispenser
    execute if score #global game.saves.cont_unlocked.snow_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.snow_disp matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a7f雪球发射器\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.snow_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.snow_disp 1
#Lava
    execute if score #global game.saves.cont_unlocked.lava matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.lava matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a76岩浆\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.lava matches 2 run scoreboard players set #global game.saves.cont_unlocked.lava 1
#Fireball Dispenser
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a76火球发射器\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.fireball_disp 1
#Fireball Dispenser
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 2 run tellraw @a "\u00a7kM\u00a7a 解锁了新装置: \u00a73末影珍珠发射器\u00a7a! \u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.ender_pearl_disp 1
