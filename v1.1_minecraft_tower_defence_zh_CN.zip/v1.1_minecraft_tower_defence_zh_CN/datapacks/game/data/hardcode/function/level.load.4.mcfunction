function game:load_level_generic.before

#set biome
    execute in overworld run fillbiome -24 -8 -24 24 24 24 plains

#displaying instructions in chat
    tellraw @a "\u00a7b第4关: 峡谷"

    tellraw @a "\u00a7a关于:"
    tellraw @a "\u00a7a- 地形: \u00a7fMLE_qwq"
    tellraw @a "\u00a7a- 代码: \u00a7fMLE_qwq"
    
#specifying path blocks and pre-built path blocks
    execute in overworld run setblock 15 -2 -15 gravel
    execute in overworld run setblock 15 -2 -14 minecraft:dirt_path
#specifying dedicated original block
    execute in overworld run setblock 15 -2 -13 grass_block

#marking
    execute in overworld run summon minecraft:marker -48 -64 -16 {Tags:["terrain_origin"],CustomName:"Terrain Origin"}
    execute in overworld run summon minecraft:marker -4 12 12 {Tags:["path_start","mob_spawnpoint"],CustomName:"Path Start"}
    execute in overworld run summon minecraft:marker -4 12 -15 {Tags:["path_ending"],CustomName:"Path Ending"}


#initial currency
    scoreboard players set #global game.data.currency 250

#stores wave data
    scoreboard players set #global game.state.total_waves 10

    #wave 1: creeper*12
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 12
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 1
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 10
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 2: zombie*14
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 14
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 2
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 2
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 20
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 3: skeleton*16
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 16
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 3
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 3
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 30
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 4: creeper*18
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 18
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 4
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 40
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 5: zombie*20
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 20
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 2
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 5
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 50
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 6: skeleton*22
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 22
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 3
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 6
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 60
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 7: creeper*24
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 24
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 7
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 70
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 8: zombie*26
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 26
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 2
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 8
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 80
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 9: skeleton*28
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 28
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 3
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 9
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 90
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie


    #wave 10: spider jockey*5
    execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 5
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 5
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 10
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 100
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    scoreboard players set @e[tag=wave_data] game.data.wave.mob_spawn_cd_org 20

function game:load_level_generic.after
