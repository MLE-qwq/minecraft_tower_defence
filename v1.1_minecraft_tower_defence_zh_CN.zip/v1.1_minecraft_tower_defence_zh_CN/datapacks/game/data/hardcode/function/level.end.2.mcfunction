#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 3.. run scoreboard players set #global game.saves.levels_unlocked 3
