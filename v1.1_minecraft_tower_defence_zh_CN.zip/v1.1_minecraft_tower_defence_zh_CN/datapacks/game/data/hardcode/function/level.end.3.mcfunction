#unlock contraptions
    execute in overworld unless score #global game.saves.cont_unlocked.trapdoor matches 1 run scoreboard players set #global game.saves.cont_unlocked.trapdoor 2
#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 4.. run scoreboard players set #global game.saves.levels_unlocked 4
