execute if entity @e[tag=target_cont,tag=on_bridge] run data merge storage game:dynamic_dialog.upgrades.trapdoor {this:{capacity_display:"\u221e"}}
$execute unless entity @e[tag=target_cont,tag=on_bridge] run data merge storage game:dynamic_dialog.upgrades.trapdoor {this:{capacity_display:"$(capacity)"}}

execute if entity @e[tag=target_cont,tag=on_bridge] run data merge storage game:dynamic_dialog.upgrades.trapdoor {this:{capacity_info:"\u00a7f\u221e\u00a7e->\u00a7c\u00a7o已满级"}}

$execute if entity @e[tag=target_cont,tag=!on_bridge] unless score @e[tag=target_cont,limit=1] game.data.cont.capacity_next matches -1 if score #global game.data.currency >= @e[tag=target_cont,limit=1] game.data.cont.capacity_cost run data merge storage game:dynamic_dialog.upgrades.trapdoor {this:{capacity_info:"\u00a7f$(capacity)\u00a7e->\u00a7f$(capacity_next) \u00a7e(\u00a72价格: \u00a7a$$(capacity_cost)\u00a7e)"}}
$execute if entity @e[tag=target_cont,tag=!on_bridge] unless score @e[tag=target_cont,limit=1] game.data.cont.capacity_next matches -1 unless score #global game.data.currency >= @e[tag=target_cont,limit=1] game.data.cont.capacity_cost run data merge storage game:dynamic_dialog.upgrades.trapdoor {this:{capacity_info:"\u00a7f$(capacity)\u00a7e->\u00a7f$(capacity_next) \u00a7e(\u00a74价格: \u00a7c$$(capacity_cost)\u00a7e)"}}
$execute if entity @e[tag=target_cont,tag=!on_bridge] if score @e[tag=target_cont,limit=1] game.data.cont.capacity_next matches -1 run data merge storage game:dynamic_dialog.upgrades.trapdoor {this:{capacity_info:"\u00a7f$(capacity)\u00a7e->\u00a7c\u00a7o已满级"}}

execute as @e[tag=target_cont,limit=1] at @s run function game:dynamic_dialog.upgrades.trapdoor.2 with storage game:dynamic_dialog.upgrades.trapdoor this
