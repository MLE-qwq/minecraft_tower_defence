#if tutorial conduction finished then return
    execute if score #global game.saves.tutorial.conducted matches 1 run return fail

#if waiting for response
    scoreboard objectives add _ dummy
    scoreboard players operation #global _ = #global game.data.tutorial.waiting_for_response
    scoreboard players operation #global _ %= #global const.200
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global _ matches 0 as @a at @s run playsound entity.cat.ambient master @s ~ ~ ~
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 2 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 要不要嘛喵...? =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 9 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 前往[关卡选择 > 第1关: 沙漠]以开始\u00a7b教学关卡\u00a7f...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 20 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 把路径延伸到\u00a7a绿色发光方块\u00a7f...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 25 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 从背包中\u00a7e购买\u00a7f一个\u00a7b仙人掌\u00a7f, 并将其拿到\u00a7b主手\u00a7f上...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 29 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 把这个仙人掌装置\u00a7e丢弃\u00a7f至路径上...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 37 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 通过把\u00a7e锄头\u00a7f丢弃至仙人掌上以打开\u00a7b控制面板\u00a7f...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 45 if score #global _ matches 0 run tellraw @a "<MLE_qwq> 老大泥快点... 在\u00a7b菜单\u00a7f中选择\u00a7e跳过倒计时\u00a7f...! =w="

    #step_id 2: Yes or No
        scoreboard objectives add game.trigger.tutorial_response trigger
        
        execute if score #global game.data.tutorial.step_id matches 2 unless score #global game.data.tutorial.waiting_for_response matches 0 if score #global _ matches 0 run tellraw @a ["",{"text":"[是]","color":"green","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 2"}}," ",{"text":"[否]","color":"red","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 1"}}]
        
        execute if score #global game.data.tutorial.step_id matches 2 as @a at @s if score @s game.trigger.tutorial_response matches 1.. run scoreboard players set #global game.data.tutorial.step_finished 0
        execute as @a at @s if score @s game.trigger.tutorial_response matches 1.. if score #global game.data.tutorial.step_id matches 2 run scoreboard players set #global game.data.tutorial.waiting_for_response 0

        execute if score #global game.data.tutorial.step_id matches 2 run scoreboard players enable @a game.trigger.tutorial_response

        execute if score #global game.data.tutorial.step_id matches 2 as @a at @s if score @s game.trigger.tutorial_response matches 1 run scoreboard players set #global game.data.tutorial.step_id 3
        execute if score #global game.data.tutorial.step_id matches 2 as @a at @s if score @s game.trigger.tutorial_response matches 2 run scoreboard players set #global game.data.tutorial.step_id 5

    #step id 9: waiting for the tutorial level to begin
        execute if score #global game.data.tutorial.step_id matches 9 if score #global game.state matches 1 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 9 if score #global game.state matches 1 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 9 if score #global game.state matches 1 run scoreboard players set #global game.data.tutorial.step_id 10

    #step id 20: waiting for the path construction to finish
        execute if score #global game.data.tutorial.step_id matches 20 if score #global game.state matches 2 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 20 if score #global game.state matches 2 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 20 if score #global game.state matches 2 run scoreboard players set #global game.data.tutorial.step_id 21

    #step id 25: waiting for a cactus to be purchased
        execute if score #global game.data.tutorial.step_id matches 25 if items entity @a weapon.mainhand cactus[custom_data~{is_cont:true}] run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 25 if items entity @a weapon.mainhand cactus[custom_data~{is_cont:true}] run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 25 if items entity @a weapon.mainhand cactus[custom_data~{is_cont:true}] run scoreboard players set #global game.data.tutorial.step_id 26

    #step id 29: waiting for a cactus to be placed
        execute if score #global game.data.tutorial.step_id matches 29 if entity @e[tag=cont] run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 29 if entity @e[tag=cont] run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 29 if entity @e[tag=cont] run scoreboard players set #global game.data.tutorial.step_id 30

    #step id 37: waiting for control panel to be opened
        execute if score #global game.data.tutorial.step_id matches 37 if score #global game.data.tutorial.opened_control_panel matches 1 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 37 if score #global game.data.tutorial.opened_control_panel matches 1 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 37 if score #global game.data.tutorial.opened_control_panel matches 1 run scoreboard players set #global game.data.tutorial.step_id 38

    #step id 45: waiting for waves to start
        execute if score #global game.data.tutorial.step_id matches 45 if score #global game.state.waves_have_started matches 1 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 45 if score #global game.state.waves_have_started matches 1 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 45 if score #global game.state.waves_have_started matches 1 run scoreboard players set #global game.data.tutorial.step_id 46

        
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. run scoreboard players add #global game.data.tutorial.waiting_for_response 1

    #return
        execute if score #global game.data.tutorial.waiting_for_response matches 1.. run return fail

#if the current step in tutorial finished then return
    execute if score #global game.data.tutorial.step_finished matches 1 run return fail

scoreboard players set #global game.data.tutorial.step_finished 1

execute if score #global game.data.tutorial.step_id matches 1.. as @a at @s run playsound entity.cat.ambient master @s ~ ~ ~
execute if score #global game.data.tutorial.step_id matches 1 run tellraw @a "<MLE_qwq> 老大泥嚎! uwu"
execute if score #global game.data.tutorial.step_id matches 1 run scoreboard players set * game.trigger.tutorial_response 0
execute if score #global game.data.tutorial.step_id matches 1 run scoreboard players set @a game.trigger.tutorial_response 0

execute if score #global game.data.tutorial.step_id matches 2 run tellraw @a "<MLE_qwq> 要进行新手教程吗呜喵...? OwO"
execute if score #global game.data.tutorial.step_id matches 2 run tellraw @a ["",{"text":"[是]","color":"green","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 2"}}," ",{"text":"[否]","color":"red","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 1"}}]
execute if score #global game.data.tutorial.step_id matches 2 run scoreboard players set #global game.data.tutorial.waiting_for_response 1


execute if score #global game.data.tutorial.step_id matches 3 run tellraw @a "<MLE_qwq> 这么自信吗喵... =w="
execute if score #global game.data.tutorial.step_id matches 4 run tellraw @a "<MLE_qwq> 那祝老大好运, 我先撤了...! OwO"
execute if score #global game.data.tutorial.step_id matches 4 run tellraw @a "\u00a7a=== 教程已结束 ==="
execute if score #global game.data.tutorial.step_id matches 4 run scoreboard players set #global game.saves.tutorial.conducted 1
execute if score #global game.data.tutorial.step_id matches 4 run return fail

execute if score #global game.data.tutorial.step_id matches 5 run tellraw @a "<MLE_qwq> 好哒! 那我们开始吧喵...!"
execute if score #global game.data.tutorial.step_id matches 6 run tellraw @a "<MLE_qwq> 看到\u00a7b快捷栏\u00a7f里的\u00a7b指南针\u00a7f了没,?"
execute if score #global game.data.tutorial.step_id matches 7 run tellraw @a "<MLE_qwq> 把它\u00a7e拿\u00a7f在\u00a7b主手\u00a7f上..."
execute if score #global game.data.tutorial.step_id matches 8 run tellraw @a "<MLE_qwq> ...并点击右键!"
execute if score #global game.data.tutorial.step_id matches 9 run tellraw @a "<MLE_qwq> 在菜单弹出来后, 请前往[关卡选择 > 第1关: 沙漠]以开始教学关卡...!"
execute if score #global game.data.tutorial.step_id matches 9 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 10 run tellraw @a "<MLE_qwq> 棒! OwO"
execute if score #global game.data.tutorial.step_id matches 11 run tellraw @a "<MLE_qwq> 老大看到快捷栏里的\u00a7b铲子\u00a7f了没...?"
execute if score #global game.data.tutorial.step_id matches 12 run tellraw @a "<MLE_qwq> 把它拿在\u00a7b主手\u00a7f上...!"
execute if score #global game.data.tutorial.step_id matches 13 run tellraw @a "<MLE_qwq> 然后\u00a7e四处走动\u00a7f可以将脚下的\u00a7b路径\u00a7e延伸\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 14 run tellraw @a "<MLE_qwq> 显而易见, 路径的\u00a7b尽头\u00a7f被一个\u00a7e黄色发光方块\u00a7f所指示..."
execute if score #global game.data.tutorial.step_id matches 15 run tellraw @a "<MLE_qwq> 注意路径只能往与\u00a7e黄色发光方块\u00a7c相邻\u00a7f的方块上延伸...!"
execute if score #global game.data.tutorial.step_id matches 16 run tellraw @a "<MLE_qwq> 另外, 路径不可以和前面的部分\u00a7e重叠\u00a7f!"
execute if score #global game.data.tutorial.step_id matches 17 run tellraw @a "<MLE_qwq> 只有当泥所处的位置\u00a7a合规\u00a7f, 路径才会\u00a7e延伸\u00a7f...! OwO"
execute if score #global game.data.tutorial.step_id matches 18 run tellraw @a "<MLE_qwq> 想把路径建到\u00a7b水上\u00a7f也可以!"
execute if score #global game.data.tutorial.step_id matches 20 run tellraw @a "<MLE_qwq> 现在, 想让老大把\u00a7b路径\u00a7e延伸\u00a7f至\u00a7a绿色发光方块\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 19 run tellraw @a "<MLE_qwq> 注意在教学关卡除外的关卡泥只有\u00a7b1分40秒\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 20 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 21 run tellraw @a "<MLE_qwq> 老大好棒! OwO"
execute if score #global game.data.tutorial.step_id matches 22 run tellraw @a "<MLE_qwq> 好了老大, 现在该使用\u00a7b装置\u00a7f来\u00a7e防卫\u00a7f自己了...!"
execute if score #global game.data.tutorial.step_id matches 23 run tellraw @a "<MLE_qwq> 打开背包..."
execute if score #global game.data.tutorial.step_id matches 24 run tellraw @a "<MLE_qwq> 然后就可以看到商店了!"
execute if score #global game.data.tutorial.step_id matches 25 run tellraw @a "<MLE_qwq> 现在需要老大买一个\u00a7b仙人掌\u00a7f并拿到\u00a7b主手\u00a7f上...!"
execute if score #global game.data.tutorial.step_id matches 25 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 26 run tellraw @a "<MLE_qwq> 棒! OwO"
execute if score #global game.data.tutorial.step_id matches 27 run tellraw @a "<MLE_qwq> 现在老大需要把仙人掌\u00a7e丢弃\u00a7f (默认键位: Q) 到路径上!"
execute if score #global game.data.tutorial.step_id matches 28 run tellraw @a "<MLE_qwq> 注意如果装置是一个\u00a7b发射器\u00a7f (显然仙人掌不是发射器啦), 那泥需要把它丢弃至于路径\u00a7c相邻\u00a7f的方块上, 因为\u00a7c不能\u00a7f把它\u00a7c直接\u00a7f放置于路径上...!"
execute if score #global game.data.tutorial.step_id matches 29 run tellraw @a "<MLE_qwq> 老大泥继续...!"
execute if score #global game.data.tutorial.step_id matches 29 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 30 run tellraw @a "<MLE_qwq> 好样的老大! awa"
execute if score #global game.data.tutorial.step_id matches 31 run tellraw @a "<MLE_qwq> 可以看到, 显示在装置上方的那行字是它们的耐久...!"
execute if score #global game.data.tutorial.step_id matches 32 run tellraw @a "<MLE_qwq> 另外, 通过把快捷栏中的\u00a7b锄头\u00a7b丢弃\u00a7f到一个装置上..."
execute if score #global game.data.tutorial.step_id matches 33 run tellraw @a "<MLE_qwq> 老大就可以打开那个装置的\u00a7b控制面板\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 34 run tellraw @a "<MLE_qwq> 在面板里, 老大可以看到一系列可以对装置进行的操作..."
execute if score #global game.data.tutorial.step_id matches 35 run tellraw @a "<MLE_qwq> 包括装置的移除..."
execute if score #global game.data.tutorial.step_id matches 36 run tellraw @a "<MLE_qwq> 以及一些升级的选项 (仙人掌没有啦...)!"
execute if score #global game.data.tutorial.step_id matches 37 run tellraw @a "<MLE_qwq> 老大泥继续, 把\u00a7b锄头\u00a7e丢弃\u00a7f到仙人掌上呜喵...!"
scoreboard objectives add game.data.tutorial.opened_control_panel dummy
execute if score #global game.data.tutorial.step_id matches 36 run scoreboard players set #global game.data.tutorial.opened_control_panel 0
execute if score #global game.data.tutorial.step_id matches 37 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 38 run tellraw @a "<MLE_qwq> 棒! OwO"
execute if score #global game.data.tutorial.step_id matches 39 run tellraw @a "<MLE_qwq> 老大可以在任何时候在菜单中选择暂停..."
execute if score #global game.data.tutorial.step_id matches 40 run tellraw @a "<MLE_qwq> 如果老大需要额外时间从一处走到另一处..."
execute if score #global game.data.tutorial.step_id matches 41 run tellraw @a "<MLE_qwq> ...或是老大单纯想四处看看...!"
execute if score #global game.data.tutorial.step_id matches 42 run tellraw @a "<MLE_qwq> 老大还可以在菜单中选择给游戏的运行\u00a7b加速\u00a7f (选项有x1.0, x2.0和x3.0)!"
execute if score #global game.data.tutorial.step_id matches 43 run tellraw @a "<MLE_qwq> 当老大觉得可以迎接下一波怪的到来时..."
execute if score #global game.data.tutorial.step_id matches 44 run tellraw @a "<MLE_qwq> 老大可以在菜单中选择\u00a7e跳过倒计时\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 45 run tellraw @a "<MLE_qwq> 那么, 老大, 跳过倒计时吧! 除非泥想一直等到它结束...! =w="
execute if score #global game.data.tutorial.step_id matches 45 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 46 run scoreboard players set #global game.state.paused 1
execute if score #global game.data.tutorial.step_id matches 46 as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.5
execute if score #global game.data.tutorial.step_id matches 46 run tellraw @a ["MLE_qwq","\u00a7c暂停\u00a7e了时间。"]
execute if score #global game.data.tutorial.step_id matches 46 run tellraw @a "<MLE_qwq> 与装置类似, 泥也可以通过把准心对准一个怪来查看它当前的血量...!"
execute if score #global game.data.tutorial.step_id matches 47 run tellraw @a "<MLE_qwq> 注意老大只能通过装置来对它们造成伤害!"
execute if score #global game.data.tutorial.step_id matches 48 run tellraw @a "<MLE_qwq> 通过击杀怪物, 老大可以获得货币, 可以用来升级或是购买新道具...!"
execute if score #global game.data.tutorial.step_id matches 49 run tellraw @a "<MLE_qwq> 在这个教学关卡里, 在每波之间, 老大有\u00a7b1分钟\u00a7f准备时间..."
execute if score #global game.data.tutorial.step_id matches 49 run tellraw @a "<MLE_qwq> 在其他的关卡中, 老大只有\u00a7b20秒\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 50 run tellraw @a "<MLE_qwq> 那么, 老大, 窝就先不打扰泥了... =w="
execute if score #global game.data.tutorial.step_id matches 51 run tellraw @a "<MLE_qwq> 差不多就这样了咪!"
execute if score #global game.data.tutorial.step_id matches 52 run tellraw @a "<MLE_qwq> 祝老大好运! 窝先撤了...! OwO"
execute if score #global game.data.tutorial.step_id matches 52 run tellraw @a "\u00a7a=== 教程已结束 ==="
execute if score #global game.data.tutorial.step_id matches 52 run tellraw @a ["MLE_qwq","\u00a7a恢复\u00a7e了时间。"]
execute if score #global game.data.tutorial.step_id matches 52 run scoreboard players set #global game.state.paused 0
execute if score #global game.data.tutorial.step_id matches 52 as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
execute if score #global game.data.tutorial.step_id matches 52 run scoreboard players set #global game.saves.tutorial.conducted 1
execute if score #global game.data.tutorial.step_id matches 52 run return fail

schedule clear game:tutorial_progression
execute unless score #global game.data.tutorial.waiting_for_response matches 1 run schedule function game:tutorial_progression 50 append
