execute as @e[type=item] at @s if items entity @s contents *[custom_data~{display_only:1b}] run kill @s
execute as @e[type=item] at @s if items entity @s contents *[custom_data~{slot_placeholder:1b}] run kill @s

#if game not paused, trigger purchase scoreboard when player interact with purchase menu
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"cactus"}] run trigger game.trigger.purchase set 1
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"water"}] run trigger game.trigger.purchase set 3
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"trapdoor"}] run trigger game.trigger.purchase set 4
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"iron_bars"}] run trigger game.trigger.purchase set 6
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"egg_disp"}] run trigger game.trigger.purchase set 2
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"arrow_disp"}] run trigger game.trigger.purchase set 5
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"slime_disp"}] run trigger game.trigger.purchase set 7
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"tnt"}] run trigger game.trigger.purchase set 8
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"snow_disp"}] run trigger game.trigger.purchase set 9
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"lava"}] run trigger game.trigger.purchase set 10
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"fireball_disp"}] run trigger game.trigger.purchase set 11
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"ender_pearl_disp"}] run trigger game.trigger.purchase set 12

#if game paused, notify that they cannot interact with purchase menu rn when they do so
    execute if score #global game.state.paused matches 1 as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{display_only:1b}] run tellraw @s "\u00a7c暂停状态下不可以购买装置的呜喵! QAQ"
    execute if score #global game.state.paused matches 1 as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{display_only:1b}] run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

#if inventory full then they cannot continue purchasing
    function game:full_inventory_check
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score @s game.mechanism.inventory_slots_occupied matches 18 run tellraw @s "\u00a7c物品栏满了喵... QAQ"
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score @s game.mechanism.inventory_slots_occupied matches 18 run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score @s game.mechanism.inventory_slots_occupied matches 18 run scoreboard players set @s game.trigger.purchase 0

#if there is currently a contraption item present then they cannot continue purchasing
    scoreboard objectives add game.mechanism.items_falling dummy
    scoreboard players set #global game.mechanism.items_falling 0
    execute as @e[type=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run scoreboard players set #global game.mechanism.items_falling 1

    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score #global game.mechanism.items_falling matches 1 run tellraw @s "\u00a7c别急啊喵! 请先等待丢弃的装置物品落地呜! QAQ"
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score #global game.mechanism.items_falling matches 1 run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score #global game.mechanism.items_falling matches 1 run scoreboard players set @s game.trigger.purchase 0

clear @a *[minecraft:custom_data~{display_only:1b}]
execute as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{display_only:1b}] run item replace entity @s player.cursor with air

clear @a *[custom_data~{slot_placeholder:1b}]
execute as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{slot_placeholder:1b}] run item replace entity @s player.cursor with air


item replace entity @a container.9 with cactus[custom_data={display_only:1b,id:"cactus"},item_name="\u00a72仙人掌",lore=["\u00a7r\u00a7a价格: $15","","\u00a7b用途: 对接触到的怪物造成\u00a7c10点伤害\u00a7b","\u00a7b并失去\u00a7c10点耐久\u00a7b。","\u00a7b初始时有\u00a7c15点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。","\u00a7e不可放置于木板上。"]]
item replace entity @a container.10 with water_bucket[custom_data={display_only:1b,id:"water"},item_name="\u00a7b水",lore=["\u00a7a价格: $50","","\u00a7b用途: 减缓与之接触到的怪物的速度。","\u00a7e使用方式: 将物品丢弃至路径上。","\u00a7e不可放置于木板上。"]]
item replace entity @a container.11 with oak_trapdoor[custom_data={display_only:1b,id:"trapdoor"},item_name="\u00a76活板门",lore=["\u00a7a价格: $150","","\u00a7b用途: 困住并击杀移速低于","\u00a7b4格每秒的怪物。","\u00a7b放置于木板上时容量无穷大。","\u00a7e使用方式: 将物品丢弃至路径上。"," "]]
item replace entity @a container.12 with iron_bars[custom_data={display_only:1b,id:"iron_bars"},item_name="\u00a77铁栅栏",lore=["\u00a7a价格: $200"," ","\u00a7b用途: 阻挡怪物前进。","\u00a7b每与1个怪物接触1秒会失去\u00a7c20点耐久\u00a7b,","\u00a7b可叠加。初始时有\u00a7c1600点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。"]]
item replace entity @a container.13 with tnt[custom_data={display_only:1b,id:"tnt"},item_name="\u00a7cTNT",lore=["\u00a7a价格: $250"," ","\u00a7b用途: 在2秒内爆炸。","\u00a7b爆炸会对4格内的怪物造成","\u00a7c500点伤害\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。"]]
item replace entity @a container.14 with lava_bucket[custom_data={display_only:1b,id:"lava"},item_name="\u00a76岩浆",lore=["\u00a7a价格: $200","","\u00a7b用途: 持续对接触的怪物","\u00a7b造成伤害并让其着火。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至路径上。"]]
item replace entity @a container.15 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.16 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.17 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]

item replace entity @a container.18 with egg[custom_data={display_only:1b,id:"egg_disp"},item_name="\u00a7e鸡蛋发射器",lore=["\u00a7a价格: $50","","\u00a7b用途: 往四周发射鸡蛋。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"]]
item replace entity @a container.19 with arrow[custom_data={display_only:1b,id:"arrow_disp"},item_name="\u00a77箭矢发射器",lore=["\u00a7a价格: $150","","\u00a7b用途: 向四周发射箭矢。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"]]
item replace entity @a container.20 with slime_ball[custom_data={display_only:1b,id:"slime_disp"},item_name="\u00a7a粘液发射器",lore=["\u00a7a价格: $100","","\u00a7b用途: 向四周发射粘液球。","\u00a7b被击中的怪物将会被减速","\u00a7b至其原始速度的一半。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"]]
item replace entity @a container.21 with snowball[custom_data={display_only:1b,id:"snow_disp"},item_name="\u00a7f雪球发射器",lore=["\u00a7a价格: $100"," ","\u00a7b用途: 往四周发射雪球。","\u00a7b雪球会暂时将击中的怪物冰冻。","\u00a7b届时怪物将无法移动。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"]]
item replace entity @a container.22 with fire_charge[custom_data={display_only:1b,id:"fireball_disp"},item_name="\u00a76火球发射器",lore=["\u00a7a价格: $150","","\u00a7b用途: 向四周发射火球。","\u00a7b被击中的怪物将会着火。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"]]
item replace entity @a container.23 with ender_pearl[custom_data={display_only:1b,id:"ender_pearl_disp"},item_name="\u00a73末影珍珠发射器",lore=["\u00a7a价格: $450","","\u00a7b用途: 往四周发射末影珍珠。","\u00a7b末影珍珠会将击中的怪物","\u00a7b传送回其刷新点。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"]]
item replace entity @a container.24 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.25 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.26 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]

execute unless score #global game.saves.cont_unlocked.cactus matches 1 run item replace entity @a container.9 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.water matches 1 run item replace entity @a container.10 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 run item replace entity @a container.11 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.iron_bars matches 1 run item replace entity @a container.12 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.tnt matches 1 run item replace entity @a container.13 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.lava matches 1 run item replace entity @a container.14 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 run item replace entity @a container.18 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.arrow_disp matches 1 run item replace entity @a container.19 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.slime_disp matches 1 run item replace entity @a container.20 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.snow_disp matches 1 run item replace entity @a container.21 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.fireball_disp matches 1 run item replace entity @a container.22 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 run item replace entity @a container.23 with red_stained_glass_pane[item_name="\u00a7c\u00a7o未解锁",custom_data={slot_placeholder:1b}]
