data merge storage game:dynamic_dialog.level_selection {this:{lvl_1:"\u00a77\u00a7o未解锁",lvl_2:"\u00a77\u00a7o未解锁",lvl_3:"\u00a77\u00a7o未解锁",lvl_4:"\u00a77\u00a7o未解锁",lvl_5:"\u00a77\u00a7o未解锁",lvl_6:"\u00a77\u00a7o未解锁",lvl_7:"\u00a77\u00a7o未解锁",lvl_8:"\u00a77\u00a7o未解锁",lvl_9:"\u00a77\u00a7o未解锁",lvl_10:"\u00a77\u00a7o未解锁",lvl_11:"\u00a77\u00a7o未解锁",lvl_12:"\u00a77\u00a7o未解锁",lvl_finale:"\u00a77\u00a7o未解锁"}}

execute if score #global game.saves.levels_unlocked matches 1.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_1:"第1关: 沙漠"}}
execute if score #global game.saves.levels_unlocked matches 2.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_2:"第2关: 森林"}}
execute if score #global game.saves.levels_unlocked matches 3.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_3:"第3关: 村庄"}}
execute if score #global game.saves.levels_unlocked matches 4.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_4:"第4关: 峡谷"}}
execute if score #global game.saves.levels_unlocked matches 5.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_5:"第5关: 矿井1"}}
execute if score #global game.saves.levels_unlocked matches 6.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_6:"第6关: 矿井2"}}
execute if score #global game.saves.levels_unlocked matches 7.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_7:"第7关: 蜘蛛洞穴"}}
execute if score #global game.saves.levels_unlocked matches 8.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_8:"第8关: 地下峡谷"}}
execute if score #global game.saves.levels_unlocked matches 9.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_9:"第9关: 半山坡"}}
execute if score #global game.saves.levels_unlocked matches 10.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_10:"第10关: 雪峰"}}
execute if score #global game.saves.levels_unlocked matches 11.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_11:"第11关: 绯红森林"}}
execute if score #global game.saves.levels_unlocked matches 12.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_12:"第12关: 下界要塞"}}
execute if score #global game.saves.levels_unlocked matches 1000.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_finale:"\u00a7d终章: 末地 (boss战)"}}

function game:dynamic_dialog.level_selection.1 with storage game:dynamic_dialog.level_selection this
