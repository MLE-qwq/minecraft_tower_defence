$tag @e[nbt={UUID:$(UUID)},limit=1] add target_cont
execute as @a at @s if score @s game.data.uuid = @e[tag=target_cont,limit=1] game.data.uuid run tag @s add target_player

execute store result storage game:dynamic_dialog.upgrades.cactus this.currency int 1 run scoreboard players get #global game.data.currency

execute store result storage game:dynamic_dialog.upgrades.cactus this.health int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.health
execute store result storage game:dynamic_dialog.upgrades.cactus this.max_health int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.max_health

scoreboard objectives add _ dummy
scoreboard players operation #global _ = #global const.100
scoreboard players operation #global _ *= @e[tag=target_cont,limit=1] game.data.health
scoreboard players operation #global _ /= @e[tag=target_cont,limit=1] game.data.max_health
execute store result storage game:dynamic_dialog.upgrades.cactus this.health_percentage int 1 run scoreboard players get #global _
scoreboard players operation #global _ = @e[tag=target_cont,limit=1] game.data.cont.worth_raw
scoreboard players operation #global _ *= @e[tag=target_cont,limit=1] game.data.health
scoreboard players operation #global _ /= @e[tag=target_cont,limit=1] game.data.max_health
execute store result storage game:dynamic_dialog.upgrades.cactus this.worth int 1 run scoreboard players get #global _
scoreboard players operation #global _ *= #global const.60
scoreboard players operation #global _ /= #global const.100
execute store result storage game:dynamic_dialog.upgrades.cactus this.worth_discount int 1 run scoreboard players get #global _

function game:dynamic_dialog.upgrades.cactus.1 with storage game:dynamic_dialog.upgrades.cactus this

tag @a remove target_player
tag @e[tag=cont] remove target_cont
