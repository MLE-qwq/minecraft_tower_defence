#resetting result of level choosing
    execute unless score #global game.state_prev matches 0 run scoreboard players set @a game.trigger.level_chosen 0
    execute unless score #global game.state_prev matches 0 run scoreboard players set * game.trigger.level_chosen 0
      
#menu-displaying item and its prevention of duping
    execute as @a at @s if items entity @s player.cursor *[custom_data~{id:"show_menu"}] run item replace entity @s hotbar.8 from entity @s player.cursor
    execute as @a at @s if items entity @s player.cursor *[custom_data~{id:"show_menu"}] run item replace entity @s player.cursor with air
    
    execute as @e[type=item] at @s if items entity @s contents *[custom_data~{kill_on_drop:1b}] run kill @s
    
    scoreboard objectives add game.watchdog.excess_items dummy
    scoreboard players set @a game.watchdog.excess_items 0
    item replace entity @a hotbar.8 with minecraft:compass[minecraft:item_name="游戏菜单",lore=["","\u00a7b用途: 显示菜单。","\u00a7e使用方式: 右键。"],minecraft:custom_data={id:"show_menu",kill_on_drop:1b},minecraft:consumable={consume_seconds:2147483647,sound:{sound_id:""},animation:"none",has_consume_particles:false},minecraft:use_effects={can_sprint:true,speed_multiplier:1}]
    execute as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"show_menu"}]
    execute as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"show_menu"}]

#loading level
    scoreboard players enable @a game.trigger.level_chosen
    execute as @a at @s if score @s game.trigger.level_chosen matches 1.. run tellraw @a ["",{"selector":"@s"},"\u00a7e选择了一个关卡。"]
    execute as @a at @s if score @s game.trigger.level_chosen matches 1.. run clear @a *[minecraft:custom_data~{id:"show_menu"}]
    execute as @a at @s if score @s game.trigger.level_chosen matches 1.. run scoreboard players operation #global game.level = @s game.trigger.level_chosen
    
    function game:settings

    execute as @a at @s if score @s game.trigger.level_chosen matches ..-1 run scoreboard players set @s game.trigger.level_chosen 0

    function hardcode:level.load

#giving players effects
    effect give @a resistance infinite 255 true
    effect give @a instant_health 1 100 true
    effect give @a saturation infinite 255 true
    effect clear @a poison
    effect clear @a speed
    scoreboard players set #global game.data.speed_up 0
