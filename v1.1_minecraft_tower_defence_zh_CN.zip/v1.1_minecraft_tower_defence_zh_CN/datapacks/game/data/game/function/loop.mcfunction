function game:close_dialog

execute unless score #global game.level matches 1000 if score #global game.data.speed_up matches 0 run function game:loop_sub
execute unless score #global game.level matches 1000 if score #global game.data.speed_up matches 1 run function game:loop_sub
execute unless score #global game.level matches 1000 if score #global game.data.speed_up matches 1 run function game:loop_sub
execute unless score #global game.level matches 1000 if score #global game.data.speed_up matches 2 run function game:loop_sub
execute unless score #global game.level matches 1000 if score #global game.data.speed_up matches 2 run function game:loop_sub
execute unless score #global game.level matches 1000 if score #global game.data.speed_up matches 2 run function game:loop_sub

execute if score #global game.level matches 1000 if score #global game.data.speed_up matches 0 run function finale:loop_sub
execute if score #global game.level matches 1000 if score #global game.data.speed_up matches 1 run function finale:loop_sub
execute if score #global game.level matches 1000 if score #global game.data.speed_up matches 1 run function finale:loop_sub
execute if score #global game.level matches 1000 if score #global game.data.speed_up matches 2 run function finale:loop_sub
execute if score #global game.level matches 1000 if score #global game.data.speed_up matches 2 run function finale:loop_sub
execute if score #global game.level matches 1000 if score #global game.data.speed_up matches 2 run function finale:loop_sub

function finale:ending
