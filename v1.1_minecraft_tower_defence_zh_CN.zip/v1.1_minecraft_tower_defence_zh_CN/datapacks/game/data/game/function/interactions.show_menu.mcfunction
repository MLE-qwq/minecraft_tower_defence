clear @a *[custom_data~{id:"show_menu"}]
playsound ui.button.click master @s ~ ~ ~
advancement revoke @s only game:interactions.show_menu

function game:dynamic_dialog.game_menu.0
