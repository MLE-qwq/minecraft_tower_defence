#this function processes how the player interacts with the contraptions


#processes speeding up
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 run scoreboard players add #global game.data.speed_up 1
    execute in overworld if score #global game.data.speed_up matches 3.. run scoreboard players set #global game.data.speed_up 0
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 if score #global game.data.speed_up matches 2 as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 if score #global game.data.speed_up matches 1 as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.74915353843834
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 if score #global game.data.speed_up matches 0 as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 if score #global game.data.speed_up matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e已将\u00a7b运行速度\u00a7e调至\u00a7ax1.0\u00a7e。"]
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 if score #global game.data.speed_up matches 1 run tellraw @a ["",{"selector":"@s"},"\u00a7e已将\u00a7b运行速度\u00a7e调至\u00a7ex2.0\u00a7e。"]
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 if score #global game.data.speed_up matches 2 run tellraw @a ["",{"selector":"@s"},"\u00a7e已将\u00a7b运行速度\u00a7e调至\u00a7cx3.0\u00a7e。"]

    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 run function game:dynamic_dialog.game_menu.0
    execute in overworld as @a at @s if score @s game.trigger.operation matches 3 run scoreboard players set @s game.trigger.operation 0

#recovery of items accidentally put in slots preserved for functional items
    function game:item_recovery_main

#display purchase gui
    function game:display_purchases

#recovery for egg dispensers in case they accidentally projected the egg by right clicking
    execute in overworld as @e[type=egg] at @s run give @p minecraft:egg[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7e鸡蛋发射器",lore=["","\u00a7b用途: 往四周发射鸡蛋。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_egg_disp",is_cont:true,item_recovery:true}] 1
    execute in overworld as @e[type=egg] as @p at @s run playsound entity.chicken.hurt master @s ~ ~1 ~
    execute in overworld as @e[type=egg] at @s run tellraw @p "\u00a7c呱! 老大, 这个道具不是这么用的呜! 泥要把它丢弃 (默认键位: Q) 到相邻于路径的方块上, 而不是将它投掷出去的呜喵! QAQ"
    execute in overworld as @e[type=egg] at @s run kill @s

#recovery for snow dispensers in case they accidentally projected the egg by right clicking
    execute in overworld as @e[type=snowball] at @s run give @p minecraft:snowball[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7f雪球发射器",lore=[" ","\u00a7b用途: 往四周发射雪球。","\u00a7b雪球会暂时将击中的怪物冰冻。","\u00a7b届时怪物将无法移动。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_snow_disp",is_cont:true,item_recovery:true}] 1
    execute in overworld as @e[type=snowball] as @p at @s run playsound block.anvil.land master @s ~ ~1 ~ 1 0.5
    execute in overworld as @e[type=snowball] at @s run tellraw @p "\u00a7c呱! 老大, 这个道具不是这么用的呜! 泥要把它丢弃 (默认键位: Q) 到相邻于路径的方块上, 而不是将它投掷出去的呜喵! QAQ"
    execute in overworld as @e[type=snowball] at @s run kill @s

#recovery for ender pearl dispensers in case they accidentally projected the egg by right clicking
    execute in overworld as @e[type=ender_pearl] at @s run give @p minecraft:ender_pearl[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a73末影珍珠发射器",lore=[" ","\u00a7b用途: 往四周发射末影珍珠。","\u00a7b末影珍珠会将击中的怪物","\u00a7b传送回其刷新点。","\u00a7b有\u00a7c150点耐久\u00a7b。","\u00a7e使用方式: 将物品丢弃至","\u00a7a相邻\u00a7e于路径的方块上。","\u00a7e不可直接放置于路径上。"],custom_data={id:"cont_ender_pearl_disp",is_cont:true,item_recovery:true}] 1
    execute in overworld as @e[type=ender_pearl] as @p at @s run playsound block.anvil.land master @s ~ ~1 ~ 1 0.5
    execute in overworld as @e[type=ender_pearl] at @s run tellraw @p "\u00a7c呱! 老大, 这个道具不是这么用的呜! 泥要把它丢弃 (默认键位: Q) 到相邻于路径的方块上, 而不是将它投掷出去的呜喵! QAQ"
    execute in overworld as @e[type=ender_pearl] at @s run kill @s


#removes tools, bridging blocks and the outline at the block at the end of the path
    clear @a *[minecraft:custom_data~{id:"tool"}]
    clear @a *[minecraft:custom_data~{id:"bridging_block"}]
    #tps the outline to somewhere not visible
    tp @e[tag=block_outline] 0 -1 0
    effect clear @e[tag=block_outline] minecraft:glowing

function hardcode:generic.mob_cont_behavior_global

#process contraption upgrades
    function game:cont_upgrades

#removes all projectiles
    execute in overworld if score #global game.state.waves_have_started matches 0 run kill @e[tag=projectile]

#proccesses usage of items
    item replace entity @a hotbar.8 with compass[enchantment_glint_override=true,minecraft:item_name="游戏菜单",lore=["","\u00a7b用途: 打开游戏菜单。","\u00a7e使用方式: 右键。"],minecraft:custom_data={id:"show_menu",kill_on_drop:1b},minecraft:consumable={consume_seconds:2147483647,sound:{sound_id:""},animation:"none",has_consume_particles:false},minecraft:use_effects={can_sprint:true,speed_multiplier:1}]

    item replace entity @a hotbar.7 with golden_hoe[attribute_modifiers=[{id:"minecraft:attack_speed","amount":4.0,type:"attack_speed",operation:"add_multiplied_base"}],tooltip_display={hidden_components:["attack_range","damage","attribute_modifiers"]},damage_resistant={types:"#minecraft:is_fire"},enchantment_glint_override=true,item_name="装置选项",lore=["","\u00a7b用途: 打开装置的控制面板。","\u00a7b控制面板可用于升级或出售道具。","\u00a7e使用方式: 将该物品丢弃至装置上。",""],custom_data={id:"cont_options"}] 1

    #if paused, prevent interaction with contraptions
        execute in overworld if score #global game.state.paused matches 1 run item replace entity @a hotbar.7 with red_stained_glass_pane[item_name="物品不可用",lore=["","\u00a7c暂停状态下不能用这个物品的呜喵! QAQ"],custom_data={kill_on_drop:1b,id:"placeholder"}]

    #contraption upgrades & operations
        execute in overworld as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @e[tag=cont,tag=!cannot_be_selected,distance=..0.5] run function game:assign_cont_to_thrower with entity @s
        #execute in overworld as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @e[tag=cont,tag=!cannot_be_selected,distance=..0.5] run dialog clear @a
        execute in overworld as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @e[tag=cont,tag=!cannot_be_selected,distance=..0.5] run kill @s
        execute in overworld as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @s[nbt={OnGround:1b}] run kill @s

    #processes game menu
        scoreboard players enable @a game.trigger.operation
        #processes countdown skipping: #1
            #succeeded
                execute in overworld as @a at @s if score @s game.trigger.operation matches 1 run dialog clear @s
                execute in overworld as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run scoreboard players set #global game.state.paused 0
                execute in overworld as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run time set 14000
                execute in overworld as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run scoreboard players set #global game.mechanism.timer 0
                execute in overworld as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 as @a at @s run playsound entity.bat.takeoff master @s ~ ~ ~ 1 1
                #announces who skipped the countdown (the player nearest to the item)
                    execute in overworld as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e跳过了倒计时。"]
            
            #failed: waves already started
                execute in overworld unless score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 1.. run tellraw @s "\u00a7c我寻思现在也没有倒计时, 怎么跳过啊喵... =-="
                execute in overworld unless score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 1.. run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
            execute in overworld as @a at @s if score @s game.trigger.operation matches 1 run scoreboard players set @s game.trigger.operation 0

        #processes purchase menu display: #2
            scoreboard players enable @a game.trigger.purchase
            execute in overworld if score #global game.state.paused matches 0 as @a at @s if score @s game.trigger.operation matches 2 run tag @s add show_purchase_menu
            execute in overworld if score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 2 run tellraw @s "\u00a7c暂停状态下不能打开商店的呜喵! QAQ"
            execute in overworld if score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 2 run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
            execute in overworld if entity @a[tag=show_purchase_menu] run function game:purchases
            execute in overworld unless entity @a[tag=show_purchase_menu] as @a at @s if score @s game.trigger.purchase matches 1.. run function game:purchases
            execute in overworld as @a at @s if score @s game.trigger.operation matches 2 run scoreboard players set @s game.trigger.operation 0
    

    #removes dropped items
    execute in overworld as @e[type=item] if items entity @s contents *[custom_data~{kill_on_drop:1b}] run kill @s

    #prevents duping
        execute in overworld as @a at @s if items entity @s player.cursor *[custom_data~{kill_on_drop:1b}] run item replace entity @s player.cursor with air
        execute in overworld as @a at @s if items entity @s player.cursor *[custom_data~{id:"cont_options"}] run item replace entity @s player.cursor with air

        scoreboard objectives add game.watchdog.excess_items dummy

        scoreboard players set @a game.watchdog.excess_items 0
        execute in overworld as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"show_menu"}]
        execute in overworld as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"show_menu"}]

        scoreboard players set @a game.watchdog.excess_items 0
        execute in overworld as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"cont_options"}]
        execute in overworld as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"cont_options"}]
        
        scoreboard players set @a game.watchdog.excess_items 0
        execute in overworld as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"placeholder"}]
        execute in overworld as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"placeholder"}]

#processes the progress of time
    execute in overworld unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run scoreboard players remove #global game.mechanism.timer 1
    #time progresses from 0 to 14000 in 1 min 40 sec, hence +7 per tick
    execute in overworld unless score #global game.level matches 1 unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run time add 7
    
    scoreboard objectives add _ dummy
    scoreboard players operation #global _ = #global game.mechanism.active_ticks
    scoreboard players operation #global _ %= #global const.3
    execute in overworld if score #global game.level matches 1 if score #global _ matches 0 unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run time add 7
    
    
    scoreboard objectives add game.mechanism.timer.sec dummy
    scoreboard objectives add game.mechanism.timer.min dummy
    scoreboard objectives add const.20 dummy
    scoreboard objectives add const.60 dummy
    scoreboard players set #global const.20 20
    scoreboard players set #global const.60 60
    scoreboard players operation #global game.mechanism.timer.sec = #global game.mechanism.timer
    scoreboard players operation #global game.mechanism.timer.sec /= #global const.20
    scoreboard players operation #global game.mechanism.timer.min = #global game.mechanism.timer.sec
    scoreboard players operation #global game.mechanism.timer.min /= #global const.60
    scoreboard players operation #global game.mechanism.timer.sec %= #global const.60

    function game:actionbar


#processes contraction placement
    function hardcode:cont.new
    function hardcode:cont.new.health_tag
    tag @e[tag=cont] remove newbie

    #items dropped must not be in batches if so then return it to the player
        execute in overworld as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[custom_data~{is_cont:true}] unless items entity @s contents *[count=1] run data merge entity @s {PickupDelay:0s}
        execute in overworld as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[custom_data~{is_cont:true}] unless items entity @s contents *[count=1] run tellraw @p "\u00a7c一次只能丢弃一个物品, 不然会被吞掉的呜喵! QAQ"
        execute in overworld as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[custom_data~{is_cont:true}] unless items entity @s contents *[count=1] as @p at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute in overworld as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[custom_data~{is_cont:true}] unless items entity @s contents *[count=1] run tp @p

    #once item falls onto the ground, or when game paused give it Close to the player
        execute in overworld as @e[type=item,tag=!ignore_existence,nbt={OnGround:1b}] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] run data merge entity @s {PickupDelay:0s}
        execute in overworld as @e[type=item,tag=!ignore_existence,nbt={OnGround:1b}] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] run tellraw @p "\u00a7c不可以放在这里的呜喵! QAQ"
        execute in overworld as @e[type=item,tag=!ignore_existence,nbt={OnGround:1b}] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] as @p at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute in overworld as @e[type=item,tag=!ignore_existence,nbt={OnGround:1b}] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] run tp @p

        execute in overworld if score #global game.state.paused matches 1 as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] run data merge entity @s {PickupDelay:0s}
        execute in overworld if score #global game.state.paused matches 1 as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] run tellraw @p "\u00a7c暂停状态下不可用放置装置的呜喵! QAQ"
        execute in overworld if score #global game.state.paused matches 1 as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] as @p at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute in overworld if score #global game.state.paused matches 1 as @e[type=item,tag=!ignore_existence] at @s if items entity @s contents *[count=1] if items entity @s contents *[custom_data~{is_cont:true}] run tp @p

#processes level quitting
    scoreboard players enable @a game.trigger.operation
    execute as @a at @s if score @s game.trigger.operation matches -3 run dialog show @s {"type":"minecraft:multi_action","after_action":"none","title":"关卡终止","columns":1,"body":[{"type":"minecraft:plain_message","contents":"确实要终止该关卡?","width":400}],"pause":false,"actions":[{"label":"\u00a7c继续","width":150,"action":{"type":"run_command","command":"/trigger game.trigger.operation set -1"}},{"label":"返回","width":150,"action":{"type":"run_command","command":"/trigger game.trigger.operation set -4"}}],"exit_action":{"label":"关闭","action":{"type":"run_command","command":"trigger game.trigger.close_dialog set 1"}}}
    execute as @a at @s if score @s game.trigger.operation matches -4 run function game:dynamic_dialog.game_menu.0
    execute as @a at @s if score @s game.trigger.operation matches -4..-3 run scoreboard players set @s game.trigger.operation 0
    #displays which player triggered level quitting in chat
        execute in overworld as @a at @s if score @s game.trigger.operation matches -1 as @a at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute in overworld as @a at @s if score @s game.trigger.operation matches -1 run tellraw @a ["",{"selector":"@s"},"\u00a7e终止了该关卡。"]
        execute in overworld as @a at @s if score @s game.trigger.operation matches -1 run tellraw @a "\u00a7c关卡被终止了呜..."
    execute in overworld as @a at @s if score @s game.trigger.operation matches -1 run function game:quit_level
    execute in overworld as @a at @s if score @s game.trigger.operation matches -1 run scoreboard players set @s game.trigger.operation 0

#tps mannequin to the ending of the path
    execute in overworld as @e[tag=path_tracker] at @s run tp @e[tag=npc] ~ ~1 ~
    execute in overworld as @e[tag=path_tracker] at @s as @e[tag=npc] at @s positioned ~ ~-1 ~ run rotate @s facing entity @n[tag=path_block,tag=!additional,distance=0.5..]
    execute in overworld as @e[tag=npc] at @s run rotate @s ~ 0

#gives players effects
effect give @a saturation infinite 255 true
effect clear @a resistance
