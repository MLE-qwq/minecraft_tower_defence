scoreboard players add #global game.data.tutorial.step_id 1
scoreboard players set #global game.data.tutorial.step_finished 0
