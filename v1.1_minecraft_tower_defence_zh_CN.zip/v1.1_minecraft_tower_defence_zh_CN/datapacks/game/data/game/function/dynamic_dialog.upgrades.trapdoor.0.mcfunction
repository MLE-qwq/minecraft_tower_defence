$tag @e[nbt={UUID:$(UUID)},limit=1] add target_cont
execute as @a at @s if score @s game.data.uuid = @e[tag=target_cont,limit=1] game.data.uuid run tag @s add target_player

execute store result storage game:dynamic_dialog.upgrades.trapdoor this.currency int 1 run scoreboard players get #global game.data.currency

execute store result storage game:dynamic_dialog.upgrades.trapdoor this.health int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.health
execute store result storage game:dynamic_dialog.upgrades.trapdoor this.max_health int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.max_health

scoreboard objectives add _ dummy
scoreboard players operation #global _ = #global const.100
scoreboard players operation #global _ *= @e[tag=target_cont,limit=1] game.data.health
scoreboard players operation #global _ /= @e[tag=target_cont,limit=1] game.data.max_health
execute store result storage game:dynamic_dialog.upgrades.trapdoor this.health_percentage int 1 run scoreboard players get #global _
scoreboard players operation #global _ = @e[tag=target_cont,limit=1] game.data.cont.worth_raw
scoreboard players operation #global _ *= @e[tag=target_cont,limit=1] game.data.health
scoreboard players operation #global _ /= @e[tag=target_cont,limit=1] game.data.max_health
execute store result storage game:dynamic_dialog.upgrades.trapdoor this.worth int 1 run scoreboard players get #global _
scoreboard players operation #global _ *= #global const.60
scoreboard players operation #global _ /= #global const.100
execute store result storage game:dynamic_dialog.upgrades.trapdoor this.worth_discount int 1 run scoreboard players get #global _

execute store result storage game:dynamic_dialog.upgrades.trapdoor this.capacity int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.capacity
execute store result storage game:dynamic_dialog.upgrades.trapdoor this.capacity_next int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.capacity_next
execute store result storage game:dynamic_dialog.upgrades.trapdoor this.capacity_cost int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.capacity_cost

execute store result storage game:dynamic_dialog.upgrades.trapdoor this.mobs_trapped int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.mobs_trapped

function game:dynamic_dialog.upgrades.trapdoor.1 with storage game:dynamic_dialog.upgrades.trapdoor this

tag @a remove target_player
tag @e[tag=cont] remove target_cont
