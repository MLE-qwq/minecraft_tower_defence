execute if score #global game.state.paused matches 0 run data merge storage game:dynamic_dialog.game_menu {this:{pausing:"\u00a7c暂停\u00a7e时间"}}
execute if score #global game.state.paused matches 1 run data merge storage game:dynamic_dialog.game_menu {this:{pausing:"\u00a7a恢复\u00a7e时间"}}


execute if score #global game.data.speed_up matches 0 run data merge storage game:dynamic_dialog.game_menu {this:{speed_up:"运行速度: \u00a7ax1.0"}}
execute if score #global game.data.speed_up matches 1 run data merge storage game:dynamic_dialog.game_menu {this:{speed_up:"运行速度: \u00a7ex2.0"}}
execute if score #global game.data.speed_up matches 2 run data merge storage game:dynamic_dialog.game_menu {this:{speed_up:"运行速度: \u00a7cx3.0"}}

function game:dynamic_dialog.game_menu.1 with storage game:dynamic_dialog.game_menu this
