function game:item_recovery_main

clear @a *[custom_data~{slot_placeholder:1b}]
item replace entity @a inventory.0 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.1 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.2 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.3 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.4 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.5 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.6 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.7 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.8 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.9 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.10 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.11 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.12 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.13 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.14 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.15 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.16 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a inventory.17 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
execute as @a at @s if items entity @s player.cursor *[custom_data~{slot_placeholder:1b}] run item replace entity @s player.cursor with air

tag @e[tag=cont] add kill
function game:cont_upgrades

execute as @e[tag=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run tellraw @p "\u00a7c不可用在路径还建设完成前放置装置的呜喵! QAQ"
execute as @e[tag=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] as @p at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
execute as @e[tag=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run data merge entity @s {PickupDelay:0s}
execute as @e[tag=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run tp @p

bossbar set finale players @a

clear @a *[minecraft:custom_data~{id:"cont_options"}]

#initializes timer
    execute in the_end unless score #global game.state_prev matches 1 run time set 0
    execute in the_end unless score #global game.state_prev matches 1 run scoreboard objectives add game.mechanism.timer dummy
    # 1 min and 40 sec = 2000 ticks
    execute in the_end unless score #global game.level matches 1 unless score #global game.state_prev matches 1 run scoreboard players set #global game.mechanism.timer 1000
    
    #teleports the tester to any player holding the tool
        tag @a remove tester_anchor
        execute in the_end as @a[x=-21,y=0,z=-21,dx=42,dy=100,dz=42,nbt={Dimension:"minecraft:the_end"}] at @s if items entity @s weapon.mainhand *[custom_data~{id:"tool"}] run tag @s add tester_anchor
        execute in the_end as @r[tag=tester_anchor] at @s run tp @e[tag=path_tester] ~ ~-1 ~
        tag @a remove tester_anchor

    #normalizing the coordinates of the tester
        scoreboard objectives add _ dummy
        execute in the_end as @e[tag=path_tester] at @s store result score #global _ run data get entity @s Pos[0] 1.0
        scoreboard players operation #global _ *= #global const.10
        scoreboard players operation #global _ += #global const.5
        execute in the_end store result entity @e[tag=path_tester,limit=1] Pos[0] double 0.1 run scoreboard players get #global _

        execute in the_end store result entity @e[tag=path_tester,limit=1] Pos[1] double 1 run scoreboard players get #global game.data.y_level

        execute in the_end as @e[tag=path_tester] at @s store result score #global _ run data get entity @s Pos[2] 1.0
        scoreboard players operation #global _ *= #global const.10
        scoreboard players operation #global _ += #global const.5
        execute in the_end store result entity @e[tag=path_tester,limit=1] Pos[2] double 0.1 run scoreboard players get #global _

    #if the tester is at a block other than the dedicated original block, water, air AND there are no markers indicating that the position is valid, then invalid
        execute in the_end as @e[tag=path_tester] at @s unless blocks ~ ~ ~ ~ ~ ~ 15 0 -13 all unless block ~ ~ ~ water unless block ~ ~ ~ air unless entity @e[tag=path_validity,distance=..0.5] run tp @e[tag=path_tester] @e[tag=path_tracker,limit=1]

    #if the tester is at a block containing a marker with path_forbidden tag then invalid
        execute in the_end as @e[tag=path_tester] at @s if entity @e[tag=path_forbidden,distance=..0.5] run tp @e[tag=path_tester] @e[tag=path_tracker,limit=1]

    #but if there are adjacent blocks that are intended to be "auto-adsorped" then proceed
        execute in the_end as @e[tag=path_tracker] at @s positioned ~1 ~ ~ if entity @e[tag=auto_replace,distance=..0.5] run tp @e[tag=path_tester] ~ ~ ~
        execute in the_end as @e[tag=path_tracker] at @s positioned ~-1 ~ ~ if entity @e[tag=auto_replace,distance=..0.5] run tp @e[tag=path_tester] ~ ~ ~
        execute in the_end as @e[tag=path_tracker] at @s positioned ~ ~ ~1 if entity @e[tag=auto_replace,distance=..0.5] run tp @e[tag=path_tester] ~ ~ ~
        execute in the_end as @e[tag=path_tracker] at @s positioned ~ ~ ~-1 if entity @e[tag=auto_replace,distance=..0.5] run tp @e[tag=path_tester] ~ ~ ~

    #detects if the path_tester is at the same y level as the path_tracker if so legitimate so far
        scoreboard objectives add game.mechanism.path_tracker_y dummy
        execute in the_end as @e[tag=path_tracker] at @s store result score #global game.mechanism.path_tracker_y run data get entity @s Pos[1] 1.0
        scoreboard objectives add game.mechanism.path_tester_y dummy
        execute in the_end as @e[tag=path_tester] at @s store result score #global game.mechanism.path_tester_y run data get entity @s Pos[1] 1.0
        execute in the_end unless score #global game.mechanism.path_tracker_y = #global game.mechanism.path_tester_y run tp @e[tag=path_tester] @e[tag=path_tracker,limit=1]

    #detects if the path_tester is adjacent to the path_tracker if so legitimate so far
        scoreboard objectives add _ dummy
        scoreboard objectives add game.mechanism.path_tracker_x dummy
        scoreboard objectives add game.mechanism.path_tracker_z dummy
        scoreboard objectives add game.mechanism.path_tester_x dummy
        scoreboard objectives add game.mechanism.path_tester_z dummy

        execute in the_end as @e[tag=path_tracker] at @s store result score #global game.mechanism.path_tracker_x run data get entity @s Pos[0] 1.0
        execute in the_end as @e[tag=path_tracker] at @s store result score #global game.mechanism.path_tracker_z run data get entity @s Pos[2] 1.0

        execute in the_end as @e[tag=path_tester] at @s store result score #global game.mechanism.path_tester_x run data get entity @s Pos[0] 1.0
        execute in the_end as @e[tag=path_tester] at @s store result score #global game.mechanism.path_tester_z run data get entity @s Pos[2] 1.0

        scoreboard players set #global _ 0

        scoreboard players add #global game.mechanism.path_tracker_x 1
        execute in the_end if score #global game.mechanism.path_tester_x = #global game.mechanism.path_tracker_x if score #global game.mechanism.path_tester_z = #global game.mechanism.path_tracker_z run scoreboard players set #global _ 1

        scoreboard players remove #global game.mechanism.path_tracker_x 2
        execute in the_end if score #global game.mechanism.path_tester_x = #global game.mechanism.path_tracker_x if score #global game.mechanism.path_tester_z = #global game.mechanism.path_tracker_z run scoreboard players set #global _ 1

        scoreboard players add #global game.mechanism.path_tracker_x 1
        scoreboard players add #global game.mechanism.path_tracker_z 1
        execute in the_end if score #global game.mechanism.path_tester_x = #global game.mechanism.path_tracker_x if score #global game.mechanism.path_tester_z = #global game.mechanism.path_tracker_z run scoreboard players set #global _ 1

        scoreboard players remove #global game.mechanism.path_tracker_z 2
        execute in the_end if score #global game.mechanism.path_tester_x = #global game.mechanism.path_tracker_x if score #global game.mechanism.path_tester_z = #global game.mechanism.path_tracker_z run scoreboard players set #global _ 1

        #execute in the_end if score #global _ matches 1 run tellraw @a [{"score":{"objective":"game.mechanism.path_tracker_x","name":"#global"}}," ",{"score":{"objective":"game.mechanism.path_tracker_z","name":"#global"}}," / ",{"score":{"objective":"game.mechanism.path_tester_x","name":"#global"}}," ",{"score":{"objective":"game.mechanism.path_tester_z","name":"#global"}}]
        execute in the_end unless score #global _ matches 1 run tp @e[tag=path_tester] @e[tag=path_tracker,limit=1]
   
    #execute in the_end as @a at @s if items entity @s weapon.mainhand *[custom_data~{id:"tool"}] as @e[tag=path_tester] at @s run summon armor_stand

    scoreboard objectives add game.mechanism.adjacent_path_blocks dummy
    scoreboard players set #global game.mechanism.adjacent_path_blocks 0
    execute in the_end as @e[tag=path_tester] at @s positioned ~1 ~ ~ if entity @e[tag=path_block,tag=!additional,distance=..0.5] run scoreboard players add #global game.mechanism.adjacent_path_blocks 1
    execute in the_end as @e[tag=path_tester] at @s positioned ~-1 ~ ~ if entity @e[tag=path_block,tag=!additional,distance=..0.5] run scoreboard players add #global game.mechanism.adjacent_path_blocks 1
    execute in the_end as @e[tag=path_tester] at @s positioned ~ ~ ~1 if entity @e[tag=path_block,tag=!additional,distance=..0.5] run scoreboard players add #global game.mechanism.adjacent_path_blocks 1
    execute in the_end as @e[tag=path_tester] at @s positioned ~ ~ ~-1 if entity @e[tag=path_block,tag=!additional,distance=..0.5] run scoreboard players add #global game.mechanism.adjacent_path_blocks 1

    execute in the_end if score #global game.mechanism.adjacent_path_blocks matches 1 run tp @e[tag=path_tracker] @e[tag=path_tester,limit=1]
    execute in the_end if score #global game.mechanism.adjacent_path_blocks matches 1 as @e[tag=path_tracker,limit=1] at @s run rotate @n[tag=path_block,tag=!additional] facing entity @s
    execute in the_end unless score #global game.mechanism.adjacent_path_blocks matches 1 run tp @e[tag=path_tester] @e[tag=path_tracker,limit=1]
#end

#processes bonus chests
    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] run scoreboard players operation #global game.data.currency += @n[tag=bonus_chest] game.data.bonus_chest.currency

    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] run scoreboard players operation #global game.mechanism.new_currency_display = @n[tag=bonus_chest] game.data.bonus_chest.currency
    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] run scoreboard players set #global game.mechanism.new_currency_display_cd 40

    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] run playsound block.chest.open block @a ~ ~1 ~
    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] as @a at @s run playsound block.amethyst_block.hit master @s ~ ~ ~
    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] run kill @n[tag=bonus_chest_display]
    execute in the_end as @e[tag=path_tracker] at @s if entity @e[tag=bonus_chest,distance=..0.5] run kill @n[tag=bonus_chest]

#generates path block marker
    tag @e[tag=path_tracker] remove on_bridge
    execute in the_end as @e[tag=path_tracker] at @s if block ~ ~ ~ air run tag @s add on_bridge
    execute in the_end as @e[tag=path_tracker] at @s if block ~ ~ ~ water run tag @s add on_bridge

    execute in the_end as @e[tag=path_tracker] at @s unless entity @e[distance=..0.5,tag=path_block] if entity @e[tag=auto_replace,distance=..0.5] run summon minecraft:marker ~ ~ ~ {Tags:["path_block","newbie"],CustomName:"Path Block"}
    execute in the_end as @e[tag=path_tracker,tag=!on_bridge] at @s unless entity @e[distance=..0.5,tag=path_block] run summon minecraft:marker ~ ~ ~ {Tags:["path_block","newbie"],CustomName:"Path Block"}
    execute in the_end as @e[tag=path_tracker,tag=on_bridge] at @s unless entity @e[distance=..0.5,tag=path_block] run summon minecraft:marker ~ ~ ~ {Tags:["path_block","bridged","newbie"],CustomName:"Path Block"}
    execute in the_end as @e[tag=path_block,tag=newbie,tag=!bridged] at @s run setblock ~ ~ ~ air destroy
    execute in the_end as @e[tag=path_block,tag=newbie,tag=!bridged] at @s if block 15 1 -15 dirt run playsound minecraft:block.gravel.place block @a ~ ~ ~ 1 0.8
    execute in the_end as @e[tag=path_block,tag=newbie,tag=!bridged] at @s if block 15 1 -15 gravel run playsound minecraft:block.gravel.place block @a ~ ~ ~ 1 0.8
    execute in the_end as @e[tag=path_block,tag=newbie,tag=!bridged] at @s if block 15 1 -15 sand run playsound minecraft:block.sand.place block @a ~ ~ ~ 1 0.8
    execute in the_end as @e[tag=path_block,tag=newbie,tag=bridged] at @s run playsound block.wood.place block @a ~ ~ ~
    tag @e[tag=path_block,tag=newbie] remove newbie
    execute in the_end as @e[tag=path_tracker] at @s run kill @e[tag=auto_replace,distance=..0.5]

    tp @e[tag=block_outline2] @e[tag=path_tracker,limit=1]

#displays path blocks
    execute in the_end as @e[tag=!additional,tag=path_block] at @s unless block ~ ~1 ~ cobweb run fill ~ ~1 ~ ~ ~2 ~ air
    execute in the_end as @e[tag=!additional,tag=path_block,tag=bridged] at @s run setblock ~ ~ ~ oak_planks
    execute in the_end as @e[tag=!additional,tag=path_block,tag=!bridged] at @s run clone 15 1 -15 15 1 -15 ~ ~ ~

#manages items
    execute in the_end as @a at @s if items entity @s player.cursor *[custom_data~{kill_on_drop:1b}] run item replace entity @s player.cursor with air
    execute in the_end as @a at @s run item replace entity @s hotbar.7 with minecraft:iron_shovel[attribute_modifiers=[{id:"minecraft:attack_speed","amount":4.0,type:"attack_speed",operation:"add_multiplied_base"}],tooltip_display={hidden_components:["attack_range","damage","attribute_modifiers"]},minecraft:lore=["","\u00a7b用途: 建设路径。","\u00a7e使用方式: 手持该物品并走到","\u00a7e想将路径建在的方块上。","  "],custom_data={kill_on_drop:1b,id:"tool"}]

    #if paused, prevent interaction with terrain
        execute in the_end if score #global game.state.paused matches 1 run item replace entity @a hotbar.7 with red_stained_glass_pane[item_name="物品不可用",lore=["","\u00a7c暂停状态下不能用这个物品的呜喵! QAQ"],custom_data={kill_on_drop:1b,id:"placeholder"}]

    #processes the usage of tools
    item replace entity @a hotbar.8 with compass[enchantment_glint_override=true,minecraft:item_name="游戏菜单",lore=["","\u00a7b用途: 显示菜单。","\u00a7e使用方式: 右键。"],minecraft:custom_data={id:"show_menu",kill_on_drop:1b},minecraft:consumable={consume_seconds:2147483647,sound:{sound_id:"minecraft:ui.button.click"},animation:"none",has_consume_particles:false},minecraft:use_effects={can_sprint:true,speed_multiplier:1}]

    #processes game menu
        scoreboard players enable @a game.trigger.operation

    #removes dropped items
    execute in the_end as @e[type=item] if items entity @s contents *[custom_data~{kill_on_drop:1b}] run kill @s
    
    #duping prevention
        scoreboard objectives add game.watchdog.excess_items dummy

        scoreboard players set @a game.watchdog.excess_items 0
        execute in the_end as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"tool"}]
        execute in the_end as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"tool"}]

        scoreboard players set @a game.watchdog.excess_items 0
        execute in the_end as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"show_menu"}]
        execute in the_end as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"show_menu"}]
        
        scoreboard players set @a game.watchdog.excess_items 0
        execute in the_end as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"placeholder"}]
        execute in the_end as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"placeholder"}]

#progresses the timer
    execute in the_end unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run scoreboard players remove #global game.mechanism.timer 1
    #time progresses from 0 to 14000 in 1 min 40 sec, hence +7 per tick
    execute in the_end unless score #global game.level matches 1 unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run time add 7
    
    scoreboard players operation #global _ = #global game.mechanism.active_ticks
    scoreboard players operation #global _ %= #global const.3
    execute in the_end if score #global game.level matches 1 if score #global _ matches 0 unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run time add 7
    
    scoreboard objectives add game.mechanism.timer.sec dummy
    scoreboard objectives add game.mechanism.timer.min dummy
    scoreboard objectives add const.20 dummy
    scoreboard objectives add const.60 dummy
    scoreboard players set #global const.20 20
    scoreboard players set #global const.60 60
    scoreboard players operation #global game.mechanism.timer.sec = #global game.mechanism.timer
    scoreboard players operation #global game.mechanism.timer.sec /= #global const.20
    scoreboard players operation #global game.mechanism.timer.min = #global game.mechanism.timer.sec
    scoreboard players operation #global game.mechanism.timer.min /= #global const.60
    scoreboard players operation #global game.mechanism.timer.sec %= #global const.60
    

    function game:actionbar

#detects if the path construction is complete
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] as @e[tag=path_ending] at @s run tp @s @n[tag=path_block]
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] unless score #global game.state matches 0 run scoreboard players set #global game.state 2

    #execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] as @e[tag=!additional,tag=path_block] at @s run fill ~ ~1 ~ ~ ~2 ~ air

    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run function game:summon_mannequin with entity @a[limit=1]
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run tp @e[tag=npc] ~ ~1 ~
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run effect clear @e[tag=block_outline] glowing
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run effect clear @e[tag=block_outline2] glowing
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run tp @e[tag=block_outline2] 0 -10000 0
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run kill @e[tag=block_outline2]
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run tp @e[tag=block_outline] 0 -10000 0
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run kill @e[tag=block_outline]
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run tag @s add path_construction_complete
    execute in the_end as @e[tag=path_tracker,tag=!path_construction_complete] at @s if entity @e[tag=path_ending,distance=..0.5] run dialog clear @a

#adjusts rotation of bonus chests
    execute in the_end as @e[tag=bonus_chest] at @s run rotate @s facing entity @p
    tag @e[tag=bonus_chest] add rotation_assignment
    function game:assign_rotation_tags
    execute in the_end as @e[tag=bonus_chest,tag=+x] at @s run setblock ~ ~1 ~ chest[facing=east]
    execute in the_end as @e[tag=bonus_chest,tag=-x] at @s run setblock ~ ~1 ~ chest[facing=west]
    execute in the_end as @e[tag=bonus_chest,tag=+z] at @s run setblock ~ ~1 ~ chest[facing=south]
    execute in the_end as @e[tag=bonus_chest,tag=-z] at @s run setblock ~ ~1 ~ chest[facing=north]


#processes level quitting
    scoreboard players enable @a game.trigger.operation
    execute as @a at @s if score @s game.trigger.operation matches -3 run dialog show @s {"type":"minecraft:multi_action","after_action":"none","title":"关卡终止","columns":1,"body":[{"type":"minecraft:plain_message","contents":"确实要终止该关卡?","width":400}],"pause":false,"actions":[{"label":"\u00a7c继续","width":150,"action":{"type":"run_command","command":"/trigger game.trigger.operation set -1"}},{"label":"返回","width":150,"action":{"type":"run_command","command":"/trigger game.trigger.operation set -4"}}],"exit_action":{"label":"关闭","action":{"type":"run_command","command":"trigger game.trigger.close_dialog set 1"}}}
    execute as @a at @s if score @s game.trigger.operation matches -4 run function game:dynamic_dialog.game_menu.0
    execute as @a at @s if score @s game.trigger.operation matches -4..-3 run scoreboard players set @s game.trigger.operation 0
    #displays which player triggered level quitting in chat
        execute in the_end as @a at @s if score @s game.trigger.operation matches -1 as @a at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute in the_end as @a at @s if score @s game.trigger.operation matches -1 run tellraw @a ["",{"selector":"@s"},"\u00a7e终止了该关卡。"]
        execute in the_end as @a at @s if score @s game.trigger.operation matches -1 run tellraw @a "\u00a7c关卡被终止了呜..."
    execute in the_end as @a at @s if score @s game.trigger.operation matches -1 run function finale:build_terrain
    execute in the_end as @a at @s if score @s game.trigger.operation matches -1 run function game:quit_level
    execute in the_end as @a at @s if score @s game.trigger.operation matches -1 run scoreboard players set @s game.trigger.operation 0
#gives players effects
    effect give @a saturation infinite 255 true
    effect clear @a resistance
