execute in the_end run fill -21 61 -21 21 75 21 air
execute in the_end run fill -21 61 -21 21 61 21 red_wool
execute in the_end run fill 20 61 20 -20 61 -20 minecraft:end_stone
execute in the_end run fill -14 62 -14 -18 72 -18 minecraft:obsidian
execute in the_end run fill -18 72 -18 -18 62 -18 air
execute in the_end run fill -18 62 -14 -18 72 -14 air
execute in the_end run fill -14 72 -14 -14 62 -14 air
execute in the_end run fill -14 62 -18 -14 72 -18 air
execute in the_end run fill 14 62 -18 18 72 -14 minecraft:obsidian
execute in the_end run fill 18 72 -14 18 62 -14 air
execute in the_end run fill 14 62 -14 14 72 -14 air
execute in the_end run fill 14 72 -18 14 62 -18 air
execute in the_end run fill 18 62 -18 18 72 -18 air
execute in the_end run fill 14 62 14 18 72 18 minecraft:obsidian
execute in the_end run fill 18 62 18 18 72 18 air
execute in the_end run fill 18 72 14 18 62 14 air
execute in the_end run fill 14 72 14 14 62 14 air
execute in the_end run fill 14 72 18 14 62 18 air
execute in the_end run setblock 16 73 16 minecraft:bedrock
execute in the_end run setblock 16 73 -16 minecraft:bedrock
execute in the_end run setblock -16 73 -16 minecraft:bedrock
execute in the_end run setblock 16 74 16 minecraft:fire
execute in the_end run setblock 16 74 -16 minecraft:fire
execute in the_end run setblock -16 74 -16 minecraft:fire

execute in the_end run fill -3 62 1 -3 61 -1 minecraft:bedrock
execute in the_end run fill -1 62 3 1 61 3 minecraft:bedrock
execute in the_end run fill 3 62 1 3 61 -1 minecraft:bedrock
execute in the_end run fill 1 62 -3 -1 61 -3 minecraft:bedrock
execute in the_end run fill 2 62 -2 2 61 -2 minecraft:bedrock
execute in the_end run fill -2 62 -2 -2 61 -2 minecraft:bedrock
execute in the_end run fill -2 62 2 -2 61 2 minecraft:bedrock
execute in the_end run fill 2 62 2 2 61 2 minecraft:bedrock
execute in the_end run fill 0 62 0 0 65 0 minecraft:bedrock
execute in the_end run fill -2 61 2 2 61 -2 minecraft:bedrock

execute in the_end run setblock 0 66 0 minecraft:dragon_egg
execute in the_end run setblock 1 64 0 minecraft:wall_torch[facing=east]
execute in the_end run setblock 0 64 -1 minecraft:wall_torch[facing=north]
execute in the_end run setblock -1 64 0 minecraft:wall_torch[facing=west]
execute in the_end run setblock 0 64 1 minecraft:wall_torch[facing=south]
