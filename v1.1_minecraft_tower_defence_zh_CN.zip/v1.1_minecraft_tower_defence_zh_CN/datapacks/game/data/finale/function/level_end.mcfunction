scoreboard players set #global game.saves.game_beat 1
advancement revoke @a only end/kill_dragon
advancement grant @a only end/kill_dragon

function finale:open_portal
