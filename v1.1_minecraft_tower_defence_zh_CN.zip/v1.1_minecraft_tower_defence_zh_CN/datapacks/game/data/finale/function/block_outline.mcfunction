#giving outline to the target block
    kill @e[tag=block_outline]
    kill @e[tag=block_outline2]
    execute in the_end in the_end run summon minecraft:shulker 0 -1 0 {NoAI:1b,Tags:["block_outline2"],CustomName:"Block Outline 2"}
    execute in the_end in the_end run summon minecraft:shulker 0 -1 0 {NoAI:1b,Tags:["block_outline"],CustomName:"Block Outline"}
        effect give @e[tag=block_outline] minecraft:invisibility infinite 255 true
        effect give @e[tag=block_outline] minecraft:glowing infinite 255 true
        effect give @e[tag=block_outline] minecraft:resistance infinite 255 true

        effect give @e[tag=block_outline2] minecraft:invisibility infinite 255 true
        effect give @e[tag=block_outline2] minecraft:glowing infinite 255 true
        effect give @e[tag=block_outline2] minecraft:resistance infinite 255 true
    attribute @e[tag=block_outline,limit=1] scale base set 0.9999
    attribute @e[tag=block_outline2,limit=1] scale base set 0.9999
    team add game.green_outline
        team modify game.green_outline color green
        team join game.green_outline @e[tag=block_outline]
    team add game.yellow_outline
        team modify game.yellow_outline color yellow
        team join game.yellow_outline @e[tag=block_outline2]
    tp @e[tag=block_outline] @e[tag=path_ending,limit=1]
    tp @e[tag=block_outline2] @e[tag=path_start,limit=1]
