#Cactus
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 run tellraw @a[scores={game.trigger.purchase=1},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7eCactus\u00a7c."
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 15

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currancy matches 15.. run tellraw @s ["\u00a7cYou do not have enough currancy to purchase\u00a7e Cactus\u00a7c.\u00a7a $15 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"}," \u00a7cremaining."]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currancy matches 15.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run give @s minecraft:cactus[lore=["","\u00a7bFunction: Gives \u00a7c50 Damage\u00a7b to mobs upon contact,","\u00a7b while losing \u00a7c50 Durability\u00a7b. Initially has \u00a7c50 Durability\u00a7b.","\u00a7eTrigger: Drop the item onto a path block. Cannot be put on bridges."],custom_data={id:"cont_cactus",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run tellraw @a [{"selector":"@s"},"\u00a7b purchased\u00a7e Cactus \u00a7efor\u00a7a $15\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run scoreboard players remove #global game.data.currancy 15

#Egg Dispenser
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 run tellraw @a[scores={game.trigger.purchase=2},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7eEgg Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 50

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currancy matches 50.. run tellraw @s ["\u00a7cYou do not have enough currancy to purchase\u00a7e Egg Dispenser\u00a7c.\u00a7a $50 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"}," \u00a7cremaining."]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currancy matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run give @s minecraft:egg[lore=["","\u00a7bFunction: Projects eggs in all 4 directions. Has \u00a7c150 Durability\u00a7b.","\u00a7eTrigger: Drop the item onto a block \u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_egg_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b purchased\u00a7e Egg Dispenser \u00a7efor\u00a7a $50\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run scoreboard players remove #global game.data.currancy 50

#Water
    execute unless score #global game.saves.cont_unlocked.water matches 1 run tellraw @a[scores={game.trigger.purchase=3},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a71Water\u00a7c."
    execute unless score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 50

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currancy matches 50.. run tellraw @s ["\u00a7cYou do not have enough currancy to purchase\u00a71 Water\u00a7c.\u00a7a $50 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"}," \u00a7cremaining."]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currancy matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run give @s minecraft:water_bucket[lore=["","\u00a7bFunction: Slows mobs down upon contact","\u00a7eTrigger: Drop the item onto a path block. Cannot be put on bridges."],custom_data={id:"cont_water",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b purchased\u00a71 Water \u00a7efor\u00a7a $50\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run scoreboard players remove #global game.data.currancy 50

#Trapdoor
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 run tellraw @a[scores={game.trigger.purchase=4},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a76Trapdoor\u00a7c."
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 150

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currancy matches 150.. run tellraw @s ["\u00a7cYou do not have enough currancy to purchase \u00a76Trapdoor\u00a7c.\u00a7a $150 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"}," \u00a7cremaining."]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currancy matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run give @s minecraft:oak_trapdoor[lore=["","\u00a7bFunction: Traps and kills mobs moving slower than 4 blocks per second upon contact.","\u00a7eTrigger: Drop the item onto a path block. Has infinite capacity if put on bridges."],custom_data={id:"cont_trapdoor",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b purchased \u00a76Trapdoor \u00a7efor\u00a7a $150\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run scoreboard players remove #global game.data.currancy 150
