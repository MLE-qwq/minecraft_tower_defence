#for those trying to understand how this datapack works, this is the 8th file you should read
#this function is triggered per tick if the game state is 1..
#this function detects whether a player has died and if so processes the game over event

execute if entity @a[scores={game.state.player_dead=1}] run tellraw @a "\u00a7cYou failed the level!"
execute if entity @a[scores={game.state.player_dead=1}] run title @a title "\u00a7cYou Died!"
execute if entity @a[scores={game.state.player_dead=1}] run title @a subtitle ""
execute if entity @a[scores={game.state.player_dead=1}] as @e[tag=path_start] at @s run playsound ambient.cave master @a ~ ~1 ~

execute if entity @a[scores={game.state.player_dead=1}] run function game:quit_level
execute if entity @a[scores={game.state.player_dead=1}] run scoreboard players set * game.state.player_dead 0
