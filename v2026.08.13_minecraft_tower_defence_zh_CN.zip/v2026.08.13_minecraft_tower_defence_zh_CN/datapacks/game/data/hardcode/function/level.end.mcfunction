execute if score #global game.level matches 1 run function hardcode:level.end.1
execute if score #global game.level matches 2 run function hardcode:level.end.2
execute if score #global game.level matches 3 run function hardcode:level.end.3
execute if score #global game.level matches 4 run function hardcode:level.end.4

function hardcode:cont.purchase.unlocking