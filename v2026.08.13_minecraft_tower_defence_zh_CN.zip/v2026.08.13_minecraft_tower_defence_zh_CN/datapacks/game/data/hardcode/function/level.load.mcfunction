execute if score #global game.level matches 1 run function hardcode:level.load.1
execute if score #global game.level matches 2 run function hardcode:level.load.2
execute if score #global game.level matches 3 run function hardcode:level.load.3
execute if score #global game.level matches 4 run function hardcode:level.load.4
execute if score #global game.level matches 5 run function hardcode:level.load.5