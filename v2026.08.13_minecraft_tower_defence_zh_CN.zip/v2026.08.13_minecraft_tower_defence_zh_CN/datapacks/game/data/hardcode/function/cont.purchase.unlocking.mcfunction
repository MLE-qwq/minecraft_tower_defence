#Cactus
    execute if score #global game.saves.cont_unlocked.cactus matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.cactus matches 2 run tellraw @a "\u00a7kM\u00a7aYou just unlocked a new contraption: \u00a7bCactus\u00a7a!\u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.cactus matches 2 run scoreboard players set #global game.saves.cont_unlocked.cactus 1
#Egg Dispenser
    execute if score #global game.saves.cont_unlocked.egg_disp matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.egg_disp matches 2 run tellraw @a "\u00a7kM\u00a7aYou just unlocked a new contraption: \u00a7bEgg Dispenser\u00a7a!\u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.egg_disp matches 2 run scoreboard players set #global game.saves.cont_unlocked.egg_disp 1
#Trapdoor
    execute if score #global game.saves.cont_unlocked.trapdoor matches 2 as @a[tag=show_purchase_menu] at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~
    execute if score #global game.saves.cont_unlocked.trapdoor matches 2 run tellraw @a "\u00a7kM\u00a7aYou just unlocked a new contraption: \u00a7bTrapdoor\u00a7a!\u00a7r\u00a7kM"
    execute if score #global game.saves.cont_unlocked.trapdoor matches 2 run scoreboard players set #global game.saves.cont_unlocked.trapdoor 1
