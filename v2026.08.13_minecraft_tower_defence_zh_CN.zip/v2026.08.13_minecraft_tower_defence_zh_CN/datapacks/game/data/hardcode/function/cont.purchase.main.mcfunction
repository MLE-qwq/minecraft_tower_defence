#Cactus
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 run tellraw @a[scores={game.trigger.purchase=1},limit=1] "\u00a7c你尚未解锁装置：\u00a7eCactus\u00a7c."
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 15

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currancy matches 15.. run tellraw @s ["\u00a7c货币不足以购买\u00a72仙人掌\u00a7c。需要\u00a7a$15 \u00a7c，但你只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currancy matches 15.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run give @s minecraft:cactus[lore=["","\u00a7b功能：对怪物造成\u00a7c10点伤害\u00a7b并失去\u00a7c10点耐久\u00a7b。初始有\u00a7c15点耐久\u00a7b。","\u00a7e触发：将该物品丢弃至建好的路上。不可放置于桥上。"],custom_data={id:"cont_cactus",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run tellraw @a [{"selector":"@s"},"\u00a7b购买了\u00a7e仙人掌\u00a7e，花费\u00a7a $15\u00a7b，剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currancy matches 15.. run scoreboard players remove #global game.data.currancy 15

#鸡蛋发射器
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 run tellraw @a[scores={game.trigger.purchase=2},limit=1] "\u00a7c你尚未解锁装置：\u00a7e鸡蛋发射器\u00a7c."
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 50

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currancy matches 50.. run tellraw @s ["\u00a7c货币不足以购买\u00a7e鸡蛋发射器\u00a7c。需要\u00a7a$50\u00a7c，但你只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currancy matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run give @s minecraft:egg[lore=["","\u00a7b功能：往四周发射鸡蛋。","\u00a7e触发：丢弃该物品至建好的路旁边的方块上。","\u00a7e不可直接放置于建好的路上。"],custom_data={id:"cont_egg_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b购买了\u00a7e鸡蛋发射器\u00a7e，花费\u00a7a$50\u00a7b，剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currancy matches 50.. run scoreboard players remove #global game.data.currancy 50

#Water
    execute unless score #global game.saves.cont_unlocked.water matches 1 run tellraw @a[scores={game.trigger.purchase=3},limit=1] "\u00a7c你尚未解锁装置：\u00a71水\u00a7c."
    execute unless score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 50

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currancy matches 50.. run tellraw @s ["\u00a7c货币不足以购买\u00a71水\u00a7c。需要\u00a7a$50 \u00a7c，但你只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currancy matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run give @s minecraft:water_bucket[lore=["","\u00a7b功能：使怪物行动变缓。","\u00a7e触发：将该物品丢弃至建好的路上。不可放置于桥上。"],custom_data={id:"cont_water",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b购买了\u00a71水\u00a7e，花费\u00a7a $50\u00a7b，剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currancy matches 50.. run scoreboard players remove #global game.data.currancy 50

#Trapdoor
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 run tellraw @a[scores={game.trigger.purchase=4},limit=1] "\u00a7c你尚未解锁装置：\u00a76陷阱门\u00a7c."
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run scoreboard players remove #global game.data.currancy_new 150

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currancy matches 150.. run tellraw @s ["\u00a7c货币不足以购买\u00a76陷阱门\u00a7c。需要\u00a7a$150 \u00a7c，但你只有\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy"},"color":"green"},"\u00a7c。"]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currancy matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run give @s minecraft:oak_trapdoor[lore=["","\u00a7b功能：杀死行动慢于4格每秒的怪物。","\u00a7e触发：将该物品丢弃至建好的路上。放置于桥上时有无限容量。"],custom_data={id:"cont_trapdoor",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b购买了\u00a76陷阱门\u00a7e，花费\u00a7a $150\u00a7b，剩余\u00a7a$",{"score":{"name":"#global","objective":"game.data.currancy_new"},"color":"green"},"\u00a7b。"]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currancy matches 150.. run scoreboard players remove #global game.data.currancy 150
