function game:load_level_generic.before

#set biome
    fillbiome -24 -8 -24 24 24 24 plains

#displaying instructions in chat
    tellraw @a "\u00a7bLevel 5: Mineshaft"

#specifying path blocks and pre-built path blocks
    setblock 15 -2 -15 sand
    setblock 15 -2 -14 minecraft:sand
#specifying dedicated original block
    setblock 15 -2 -13 stone

#marking
    summon minecraft:marker -48 -64 -48 {Tags:["terrain_origin"],CustomName:"Terrain Origin"}
    summon minecraft:marker -5 7 6 {Tags:["path_start","mob_spawnpoint"],CustomName:"Path Start"}
    summon minecraft:marker -1 7 2 {Tags:["path_ending"],CustomName:"Path Ending"}

#additional mob spawnpoints
    summon minecraft:marker -11 7 -3 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 1
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie

#initial currancy
    scoreboard players set #global game.data.currancy 0

#summoning markers that lets path tracker & tester identify as air blocks
    summon marker -5 7 -4 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    summon marker -1 7 -13 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    summon marker -1 7 13 {Tags:["auto_replace"],CustomName:"Auto Replace"}

#bonus chests
    summon marker -5 7 -4 {Tags:["bonus_chest","newbie"],CustomName:"Bonus Chest"}
    scoreboard players set @e[tag=bonus_chest,tag=newbie] game.data.bonus_chest.currany 150
    tag @e[tag=bonus_chest,tag=newbie] remove newbie

    summon marker -1 7 -13 {Tags:["bonus_chest","newbie"],CustomName:"Bonus Chest"}
    scoreboard players set @e[tag=bonus_chest,tag=newbie] game.data.bonus_chest.currany 150
    tag @e[tag=bonus_chest,tag=newbie] remove newbie

    summon marker -1 7 13 {Tags:["bonus_chest","newbie"],CustomName:"Bonus Chest"}
    scoreboard players set @e[tag=bonus_chest,tag=newbie] game.data.bonus_chest.currany 150
    tag @e[tag=bonus_chest,tag=newbie] remove newbie

#stores wave data
    scoreboard players set #global game.state.total_waves 5

    #wave 1: creeper*12
    summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 12
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 1
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 10
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_has_mercy 0
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie


function game:load_level_generic.after

tellraw @a "<MLE_qwq> 呱! 不要玩这关口牙! 窝还没做完QAQ"