#for those trying to understand how this datapack works, this is the 5th file you should read
#this function is triggered per tick if the game state is 2.
#this function processes how the player interacts with the contraptions

#recovery of items accidentally put in slots preserved for functional items
    function game:item_recovery_main

#removes tools, bridging blocks and the outline at the block at the end of the path
    clear @a *[minecraft:custom_data~{id:"tool"}]
    clear @a *[minecraft:custom_data~{id:"bridging_block"}]
    #tps the outline to somewhere not visible
    tp @e[tag=block_outline] 0 -1 0
    effect clear @e[tag=block_outline] minecraft:glowing

function hardcode:generic.mob_cont_behavior_global

#process contraption upgrades
    function game:interactions
    function game:cont_upgrades

#removes all projectiles
    execute if score #global game.state.waves_have_started matches 0 run kill @e[tag=projectile]

#proccesses usage of items
    item replace entity @a hotbar.8 with compass[enchantment_glint_override=true,minecraft:item_name="游戏菜单",lore=["","\u00a7b功能：打开游戏菜单。","\u00a7e触发：丢弃该物品。"],minecraft:custom_data={id:"game_menu",kill_on_drop:1b}]

    item replace entity @a hotbar.7 with golden_hoe[damage_resistant={types:"#minecraft:is_fire"},enchantment_glint_override=true,item_name="装置选项",lore=["","\u00a7b功能：打开装置选项菜单。","\u00a7e触发：将该物品丢弃到装置上。"],custom_data={id:"cont_options"}] 1

    #if paused, prevent interaction with contraptions
        execute if score #global game.state.paused matches 1 run item replace entity @a hotbar.7 with barrier[custom_name="不可用",lore=["","\u00a7c暂停时该物品不可用。"],custom_data={kill_on_drop:1b,id:"placeholder"}]

    #contraption upgrades & operations
        execute as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @e[tag=cont,distance=..0.5] run function game:assign_cont_to_thrower with entity @s
        execute as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @e[tag=cont,distance=..0.5] run dialog clear @a
        execute as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @e[tag=cont,distance=..0.5] run kill @s
        execute as @e[type=item] at @s if items entity @s contents *[custom_data~{id:"cont_options"}] if entity @s[nbt={OnGround:1b}] run kill @s

    #processes game menu
        scoreboard players enable @a game.trigger.operation
        execute as @e[type=item] if items entity @s contents *[custom_data~{id:"game_menu"}] run dialog show @p game:contraption_placement_menu
        #processes countdown skipping: #1
            #succeeded
                execute as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run scoreboard players set #global game.state.paused 0
                execute as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run time set 14000
                execute as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run scoreboard players set #global game.mechanism.timer 0
                execute as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 as @a at @s run playsound entity.bat.takeoff master @s ~ ~ ~ 1 1
                #announces who skipped the countdown (the player nearest to the item)
                    execute as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e跳过了倒计时。"]
            
            #failed: waves already started
                execute unless score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 1.. run tellraw @s "\u00a7c当前没有倒计时可以跳过。"
                execute unless score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 1 if score #global game.state.waves_have_started matches 1.. run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
            execute as @a at @s if score @s game.trigger.operation matches 1 run scoreboard players set @s game.trigger.operation 0

        #processes purchase menu display: #2
            scoreboard players enable @a game.trigger.purchase
            execute if score #global game.state.paused matches 0 as @a at @s if score @s game.trigger.operation matches 2 run tag @s add show_purchase_menu
            execute if score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 2 run tellraw @s "\u00a7c暂停时商店菜单不可用。"
            execute if score #global game.state.paused matches 1 as @a at @s if score @s game.trigger.operation matches 2 run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
            execute if entity @a[tag=show_purchase_menu] run function game:purchases
            execute unless entity @a[tag=show_purchase_menu] as @a at @s if score @s game.trigger.purchase matches 1.. run function game:purchases
            execute as @a at @s if score @s game.trigger.operation matches 2 run scoreboard players set @s game.trigger.operation 0
    

    #removes dropped items
    execute as @e[type=item] if items entity @s contents *[custom_data~{kill_on_drop:1b}] run kill @s

    #prevents duping
        scoreboard objectives add game.watchdog.excess_items dummy

        scoreboard players set @a game.watchdog.excess_items 0
        execute as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"game_menu"}]
        execute as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"game_menu"}]

        scoreboard players set @a game.watchdog.excess_items 0
        execute as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"remove_cont"}]
        execute as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"remove_cont"}]
        
        scoreboard players set @a game.watchdog.excess_items 0
        execute as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"placeholder"}]
        execute as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"placeholder"}]

#processes the progress of time
    execute unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run scoreboard players remove #global game.mechanism.timer 1
    #time progresses from 0 to 14000 in 1 min 40 sec, hence +7 per tick
    execute unless score #global game.state.paused matches 1 if score #global game.mechanism.timer matches 1.. run time add 7
    scoreboard objectives add game.mechanism.timer.sec dummy
    scoreboard objectives add game.mechanism.timer.min dummy
    scoreboard objectives add const.20 dummy
    scoreboard objectives add const.60 dummy
    scoreboard players set #global const.20 20
    scoreboard players set #global const.60 60
    scoreboard players operation #global game.mechanism.timer.sec = #global game.mechanism.timer
    scoreboard players operation #global game.mechanism.timer.sec /= #global const.20
    scoreboard players operation #global game.mechanism.timer.min = #global game.mechanism.timer.sec
    scoreboard players operation #global game.mechanism.timer.min /= #global const.60
    scoreboard players operation #global game.mechanism.timer.sec %= #global const.60

    function game:actionbar


#processes contraction placement
    function hardcode:cont.new

    #once item falls onto the ground, or when game paused give it back to the player
        execute as @e[type=item,nbt={OnGround:1b}] at @s if items entity @s contents *[custom_data~{is_cont:true}] run data merge entity @s {PickupDelay:0s}
        execute as @e[type=item,nbt={OnGround:1b}] at @s if items entity @s contents *[custom_data~{is_cont:true}] run tellraw @p "\u00a7c该装置不可用放至该位置。"
        execute as @e[type=item,nbt={OnGround:1b}] at @s if items entity @s contents *[custom_data~{is_cont:true}] as @p at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute as @e[type=item,nbt={OnGround:1b}] at @s if items entity @s contents *[custom_data~{is_cont:true}] run tp @p

        execute if score #global game.state.paused matches 1 as @e[type=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run data merge entity @s {PickupDelay:0s}
        execute if score #global game.state.paused matches 1 as @e[type=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run tellraw @p "\u00a7c暂停时不可以放置装置。"
        execute if score #global game.state.paused matches 1 as @e[type=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] as @p at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute if score #global game.state.paused matches 1 as @e[type=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run tp @p

#processes level quitting
    #displays which player triggered level quitting in chat
        execute as @a at @s if score @s game.trigger.operation matches -1 as @a at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
        execute as @a at @s if score @s game.trigger.operation matches -1 run tellraw @a ["",{"selector":"@s"},"\u00a7e终止了关卡。"]
        execute as @a at @s if score @s game.trigger.operation matches -1 run tellraw @a "\u00a7c关卡已终止。"
    execute as @a at @s if score @s game.trigger.operation matches -1 run function game:quit_level
    execute as @a at @s if score @s game.trigger.operation matches -1 run scoreboard players set @s game.trigger.operation 0

#tps mannequin to the ending of the path
    execute as @e[tag=path_tracker] at @s run tp @e[tag=npc] ~ ~1 ~ facing entity @n[tag=path_block,tag=!additional,distance=0.5..]
    execute as @e[tag=npc] at @s run rotate @s ~ 0

#gives players effects
effect give @a saturation infinite 255 true
effect clear @a resistance