#for those trying to understand how this datapack works, this is the 7.5th file you should read (jump to the 8th file after this)
#this function is triggered per tick if the game state is 1..
#this function processes what the game would do if there are new players joining after a round has started, or a player quits within a round

execute as @a at @s unless score @s game.data.uuid matches -2147483648..2147483647 run scoreboard players set @s game.data.uuid 0

gamemode spectator @a[scores={game.data.uuid=0}]
execute as @a[tag=!admin] at @s unless score @s game.data.uuid matches 0 run gamemode adventure