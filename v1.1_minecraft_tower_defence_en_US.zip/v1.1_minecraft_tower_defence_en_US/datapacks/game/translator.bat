python "translator.py"
pause