function game:load_level_generic.before

advancement revoke @a only story/enter_the_nether
advancement grant @a only story/enter_the_nether

scoreboard players set #global game.data.what_happens_to_water 2
#water evaporates

#set biome
    execute in overworld run fillbiome -24 -8 -24 24 24 24 crimson_forest

#display
    tellraw @a "\u00a7bLevel 11: Crimson Forest"
    
    tellraw @a "\u00a7aCredits:"
    tellraw @a "\u00a7a- Terrain: \u00a7fNotch, MLE_qwq"
    tellraw @a "\u00a77> (For copy-pasting from vanilla terrain =w=)"
    tellraw @a "\u00a7a- Code: \u00a7fMLE_qwq"
    

#specifying path blocks
    execute in overworld run setblock 15 -2 -15 gravel
#specifying dedicated original block
    execute in overworld run setblock 15 -2 -13 crimson_nylium

#marking
    execute in overworld run summon minecraft:marker -16 -64 48 {Tags:["terrain_origin"],CustomName:"Terrain Origin"}
    execute in overworld run summon minecraft:marker 9 4 -6 {Tags:["path_start","mob_spawnpoint"],CustomName:"Path Start"}
    execute in overworld run summon minecraft:marker -5 4 0 {Tags:["path_ending"],CustomName:"Path Ending"}

#initial currency
    scoreboard players set #global game.data.currency 450

#stores wave data
    scoreboard players set #global game.state.total_waves 5

    #wave 1: zombified piglin * 10
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 2: zombified piglin * 15
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 2
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 20
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 3: ghast * 3
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 3
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 13
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 3
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 300
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 100
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 4: zombified piglin * 20
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 20
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 4
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 40
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 5: ghast * 5
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 13
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 600
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 100
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #scoreboard players set @e[tag=wave_data] game.data.wave.mob_spawn_cd_org 20

function game:load_level_generic.after

