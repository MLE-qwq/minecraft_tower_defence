#unlock contraptions
    execute in overworld unless score #global game.saves.cont_unlocked.lava matches 1 run scoreboard players set #global game.saves.cont_unlocked.lava 2
#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 12.. run scoreboard players set #global game.saves.levels_unlocked 12