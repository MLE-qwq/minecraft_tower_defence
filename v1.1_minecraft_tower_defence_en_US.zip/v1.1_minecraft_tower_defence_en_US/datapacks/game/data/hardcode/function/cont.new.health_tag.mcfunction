execute as @e[tag=cont,tag=newbie,tag=cactus] at @s run summon text_display ~ ~1.1 ~ {Tags:["cont_health_display"]}
execute as @e[tag=cont,tag=newbie,tag=water] at @s run summon text_display ~ ~1.1 ~ {Tags:["cont_health_display"]}
execute as @e[tag=cont,tag=newbie,tag=trapdoor] at @s run summon text_display ~ ~0.2 ~ {Tags:["cont_health_display"]}
execute as @e[tag=cont,tag=newbie,tag=iron_bars] at @s run summon text_display ~ ~1.1 ~ {Tags:["cont_health_display"]}
execute as @e[tag=cont,tag=newbie,tag=disp] at @s run summon text_display ~ ~0.2 ~ {Tags:["cont_health_display"]}
execute as @e[tag=cont,tag=newbie,tag=lava] at @s run summon text_display ~ ~1.1 ~ {Tags:["cont_health_display"]}