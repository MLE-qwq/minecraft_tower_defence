execute if score #global game.level > #global game.saves.levels_unlocked run tellraw @a ["\u00a7cYou have not yet unlocked this level! Please finish all prior levels to proceed. You may currently start the levels before and including \u00a7eLevel ",{"color":"yellow","score":{"name":"#global","objective":"game.saves.levels_unlocked"}},"\u00a7c."]
execute if score #global game.level > #global game.saves.levels_unlocked as @a at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
execute if score #global game.level > #global game.saves.levels_unlocked as @a at @s run scoreboard players set @a game.trigger.level_chosen 0
execute if score #global game.level > #global game.saves.levels_unlocked as @a at @s run scoreboard players set * game.trigger.level_chosen 0
execute if score #global game.level > #global game.saves.levels_unlocked as @a at @s run return run scoreboard players set #global game.level 0

execute if score #global game.level matches 1.. run dialog clear @a

execute if score #global game.level matches 1 run function hardcode:level.load.1
execute if score #global game.level matches 2 run function hardcode:level.load.2
execute if score #global game.level matches 3 run function hardcode:level.load.3
execute if score #global game.level matches 4 run function hardcode:level.load.4
execute if score #global game.level matches 5 run function hardcode:level.load.5
execute if score #global game.level matches 6 run function hardcode:level.load.6
execute if score #global game.level matches 7 run function hardcode:level.load.7
execute if score #global game.level matches 8 run function hardcode:level.load.8
execute if score #global game.level matches 9 run function hardcode:level.load.9
execute if score #global game.level matches 10 run function hardcode:level.load.10
execute if score #global game.level matches 11 run function hardcode:level.load.11
execute if score #global game.level matches 12 run function hardcode:level.load.12
execute if score #global game.level matches 1000 run function finale:load_level