execute if score #global game.level matches 1 run function hardcode:level.end.1
execute if score #global game.level matches 2 run function hardcode:level.end.2
execute if score #global game.level matches 3 run function hardcode:level.end.3
execute if score #global game.level matches 4 run function hardcode:level.end.4
execute if score #global game.level matches 5 run function hardcode:level.end.5
execute if score #global game.level matches 6 run function hardcode:level.end.6
execute if score #global game.level matches 7 run function hardcode:level.end.7
execute if score #global game.level matches 8 run function hardcode:level.end.8
execute if score #global game.level matches 9 run function hardcode:level.end.9
execute if score #global game.level matches 10 run function hardcode:level.end.10
execute if score #global game.level matches 11 run function hardcode:level.end.11
execute if score #global game.level matches 12 run function hardcode:level.end.12
execute if score #global game.level matches 1000 run function finale:level_end

function hardcode:cont.purchase.unlocking
