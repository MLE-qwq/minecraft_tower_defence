#unlocking contraptions
    execute in overworld unless score #global game.saves.cont_unlocked.egg_disp matches 1 run scoreboard players set #global game.saves.cont_unlocked.egg_disp 2

    execute in overworld unless score #global game.saves.cont_unlocked.water matches 1 run scoreboard players set #global game.saves.cont_unlocked.water 2
#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 2.. run scoreboard players set #global game.saves.levels_unlocked 2