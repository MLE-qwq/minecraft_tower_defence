#quits if game paused
    execute if score #global game.state.paused matches 1 run return fail
    execute if score #global game.mechanism.items_falling matches 1 run return fail

#Cactus
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 run tellraw @a[scores={game.trigger.purchase=1},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a72Cactus\u00a7c."
    execute unless score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s run scoreboard players remove #global game.data.currency_new 15

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currency matches 15.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a72 Cactus\u00a7c.\u00a7a $15 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s unless score #global game.data.currency matches 15.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run give @s minecraft:cactus[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a72Cactus",lore=["","\u00a7bUsage: Gives \u00a7c10 Damage\u00a7b to mobs","\u00a7bupon contact, while losing \u00a7c10 Durability\u00a7b.","\u00a7bInitially has \u00a7c15 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a path block.","\u00a7eCannot be put on bridges."],custom_data={id:"cont_cactus",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a72 Cactus \u00a7bfor\u00a7a $15\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.cactus matches 1 as @a[scores={game.trigger.purchase=1},limit=1] at @s if score #global game.data.currency matches 15.. run scoreboard players remove #global game.data.currency 15

#Egg Dispenser
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 run tellraw @a[scores={game.trigger.purchase=2},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7eEgg Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s run scoreboard players remove #global game.data.currency_new 50

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currency matches 50.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a7e Egg Dispenser\u00a7c.\u00a7a $50 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s unless score #global game.data.currency matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run give @s minecraft:egg[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7eEgg Dispenser",lore=["","\u00a7bUsage: Projects eggs in","\u00a7ball 4 directions. Has \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_egg_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a7e Egg Dispenser \u00a7bfor\u00a7a $50\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.egg_disp matches 1 as @a[scores={game.trigger.purchase=2},limit=1] at @s if score #global game.data.currency matches 50.. run scoreboard players remove #global game.data.currency 50

#Water
    execute unless score #global game.saves.cont_unlocked.water matches 1 run tellraw @a[scores={game.trigger.purchase=3},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7bWater\u00a7c."
    execute unless score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s run scoreboard players remove #global game.data.currency_new 50

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currency matches 50.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a7b Water\u00a7c.\u00a7a $50 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s unless score #global game.data.currency matches 50.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run give @s minecraft:water_bucket[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7bWater",lore=["","\u00a7bUsage: Slows mobs down upon contact. ","\u00a7eMethod: Drop the item onto a path block.","\u00a7eCannot be put on bridges."],custom_data={id:"cont_water",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a7b Water \u00a7bfor\u00a7a $50\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.water matches 1 as @a[scores={game.trigger.purchase=3},limit=1] at @s if score #global game.data.currency matches 50.. run scoreboard players remove #global game.data.currency 50

#Trapdoor
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 run tellraw @a[scores={game.trigger.purchase=4},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a76Trapdoor\u00a7c."
    execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s run scoreboard players remove #global game.data.currency_new 150

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currency matches 150.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase \u00a76Trapdoor\u00a7c.\u00a7a $150 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s unless score #global game.data.currency matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run give @s minecraft:oak_trapdoor[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a76Trapdoor",lore=["","\u00a7bUsage: Traps and kills mobs moving","\u00a7bslower than 4 blocks per second","\u00a7bupon contact.","\u00a7eMethod: Drop the item onto a path block.","\u00a7eHas infinite capacity if put on bridges."],custom_data={id:"cont_trapdoor",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased \u00a76Trapdoor \u00a7bfor\u00a7a $150\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.trapdoor matches 1 as @a[scores={game.trigger.purchase=4},limit=1] at @s if score #global game.data.currency matches 150.. run scoreboard players remove #global game.data.currency 150

#Arrow Dispenser
    execute unless score #global game.saves.cont_unlocked.arrow_disp matches 1 run tellraw @a[scores={game.trigger.purchase=5},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a77Arrow Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s run scoreboard players remove #global game.data.currency_new 150

    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s unless score #global game.data.currency matches 150.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a7e Arrow Dispenser\u00a7c.\u00a7a $150 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s unless score #global game.data.currency matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run give @s minecraft:arrow[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a77Arrow Dispenser",lore=["","\u00a7bUsage: Projects arrows in","\u00a7ball 4 directions. Has \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_arrow_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a7e Arrow Dispenser \u00a7bfor\u00a7a $150\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.arrow_disp matches 1 as @a[scores={game.trigger.purchase=5},limit=1] at @s if score #global game.data.currency matches 150.. run scoreboard players remove #global game.data.currency 150

#Iron Bars
    execute unless score #global game.saves.cont_unlocked.iron_bars matches 1 run tellraw @a[scores={game.trigger.purchase=6},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a77Iron Bars\u00a7c."
    execute unless score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s run scoreboard players remove #global game.data.currency_new 200

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s unless score #global game.data.currency matches 200.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase \u00a77Iron Bars\u00a7c.\u00a7a $200 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s unless score #global game.data.currency matches 200.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run give @s minecraft:iron_bars[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a77Iron Bars",lore=[" ","\u00a7bUsage: Obstructs mobs. Loses","\u00a7c20 Durability \u00a7bupon contact per mob","\u00a7bper second. Initially has \u00a7c1600 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a path block."],custom_data={id:"cont_iron_bars",is_cont:true,item_recovery:true}] 1

    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased \u00a77Iron Bars \u00a7bfor\u00a7a $200\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.iron_bars matches 1 as @a[scores={game.trigger.purchase=6},limit=1] at @s if score #global game.data.currency matches 200.. run scoreboard players remove #global game.data.currency 200

#Slime Dispenser
    execute unless score #global game.saves.cont_unlocked.slime_disp matches 1 run tellraw @a[scores={game.trigger.purchase=7},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7aSlime Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s run scoreboard players remove #global game.data.currency_new 100

    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s unless score #global game.data.currency matches 100.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a7e Slime Dispenser\u00a7c.\u00a7a $100 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s unless score #global game.data.currency matches 100.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run give @s minecraft:slime_ball[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7aSlime Dispenser",lore=[" ","\u00a7bUsage: Projects slime balls in","\u00a7ball 4 directions which slow mobs","\u00a7bdown to half of their original speed. ","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_slime_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a7e Slime Dispenser \u00a7bfor\u00a7a $100\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.slime_disp matches 1 as @a[scores={game.trigger.purchase=7},limit=1] at @s if score #global game.data.currency matches 100.. run scoreboard players remove #global game.data.currency 100

#TNT
    execute unless score #global game.saves.cont_unlocked.tnt matches 1 run tellraw @a[scores={game.trigger.purchase=8},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7cTNT\u00a7c."
    execute unless score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s run scoreboard players remove #global game.data.currency_new 250

    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s unless score #global game.data.currency matches 250.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a7e TNT\u00a7c.\u00a7a $250 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s unless score #global game.data.currency matches 250.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run give @s minecraft:tnt[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7cTNT",lore=["","\u00a7bUsage: Explodes in 2 seconds and","\u00a7bdamages mobs within a 4-block radius","\u00a7bby \u00a7c500 HP\u00a7b. ","\u00a7eMethod: Drop the item onto the path. "],custom_data={id:"cont_tnt",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a7e TNT \u00a7bfor\u00a7a $250\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.tnt matches 1 as @a[scores={game.trigger.purchase=8},limit=1] at @s if score #global game.data.currency matches 250.. run scoreboard players remove #global game.data.currency 250

#Snow Dispenser
    execute unless score #global game.saves.cont_unlocked.snow_disp matches 1 run tellraw @a[scores={game.trigger.purchase=9},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a7fSnow Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s run scoreboard players remove #global game.data.currency_new 100

    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s unless score #global game.data.currency matches 100.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a7f Snow Dispenser\u00a7c.\u00a7a $100 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s unless score #global game.data.currency matches 100.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run give @s minecraft:snowball[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a7fSnow Dispenser",lore=["","\u00a7bUsage: Projects snowballs in","\u00a7ball 4 directions which temporarily","\u00a7bfreezes a mob's motion upon hit.","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_snow_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a7e Snow Dispenser \u00a7bfor\u00a7a $100\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.snow_disp matches 1 as @a[scores={game.trigger.purchase=9},limit=1] at @s if score #global game.data.currency matches 100.. run scoreboard players remove #global game.data.currency 100

#Lava
    execute unless score #global game.saves.cont_unlocked.lava matches 1 run tellraw @a[scores={game.trigger.purchase=10},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a76Lava\u00a7c."
    execute unless score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s run scoreboard players remove #global game.data.currency_new 200

    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s unless score #global game.data.currency matches 200.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a76 Lava\u00a7c.\u00a7a $200 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s unless score #global game.data.currency matches 200.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run give @s minecraft:lava_bucket[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a76Lava",lore=["","\u00a7bUsage: Damages mobs continuously","\u00a7bupon contact and sets them on fire.","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a path block."],custom_data={id:"cont_lava",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a76 Lava \u00a7bfor\u00a7a $200\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.lava matches 1 as @a[scores={game.trigger.purchase=10},limit=1] at @s if score #global game.data.currency matches 200.. run scoreboard players remove #global game.data.currency 200

#Fireball Dispenser
    execute unless score #global game.saves.cont_unlocked.fireball_disp matches 1 run tellraw @a[scores={game.trigger.purchase=11},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a76Fireball Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s run scoreboard players remove #global game.data.currency_new 150

    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s unless score #global game.data.currency matches 150.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a76 Fireball Dispenser\u00a7c.\u00a7a $150 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s unless score #global game.data.currency matches 150.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run give @s minecraft:fire_charge[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a76Fireball Dispenser",lore=[" ","\u00a7bUsage: Projects fireballs in","\u00a7ball 4 directions which sets a mob","\u00a7bon fire upon hit. Has \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_fireball_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a76 Fireball Dispenser \u00a7bfor\u00a7a $150\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.fireball_disp matches 1 as @a[scores={game.trigger.purchase=11},limit=1] at @s if score #global game.data.currency matches 150.. run scoreboard players remove #global game.data.currency 150

#Ender Pearl Dispenser
    execute unless score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 run tellraw @a[scores={game.trigger.purchase=12},limit=1] "\u00a7cYou have not yet unlocked the contraption \u00a73Ender Pearl Dispenser\u00a7c."
    execute unless score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s run scoreboard players remove #global game.data.currency_new 450

    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s unless score #global game.data.currency matches 450.. run tellraw @s ["\u00a7cYou do not have enough currency to purchase\u00a73 Ender Pearl Dispenser\u00a7c.\u00a7a $450 \u00a7cis required, but there's only \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency"},"color":"green"},"\u00a7c."]
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s unless score #global game.data.currency matches 450.. run playsound block.anvil.land master @a ~ ~ ~ 1 0.5

    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run give @s minecraft:ender_pearl[damage_resistant={types:"#minecraft:is_fire"},max_stack_size=99,item_name="\u00a73Ender Pearl Dispenser",lore=[" ","\u00a7bUsage: Projects ender pearls in","\u00a7ball 4 directions which teleports","\u00a7bmobs Close to spawnpoint upon hit.","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."],custom_data={id:"cont_ender_pearl_disp",is_cont:true,item_recovery:true}] 1
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run tellraw @a [{"selector":"@s"},"\u00a7b has purchased\u00a73 Ender Pearl Dispenser \u00a7bfor\u00a7a $450\u00a7b, with \u00a7a$",{"score":{"name":"#global","objective":"game.data.currency_new"},"color":"green"},"\u00a7b remaining."]
    execute if score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 as @a[scores={game.trigger.purchase=12},limit=1] at @s if score #global game.data.currency matches 450.. run scoreboard players remove #global game.data.currency 450
