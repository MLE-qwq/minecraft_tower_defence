#unlock contraptions
    execute in overworld unless score #global game.saves.cont_unlocked.iron_bars matches 1 run scoreboard players set #global game.saves.cont_unlocked.iron_bars 2
#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 6.. run scoreboard players set #global game.saves.levels_unlocked 6