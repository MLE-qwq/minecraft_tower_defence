function game:load_level_generic.before

scoreboard players set #global game.data.what_happens_to_water 2
#water evaporates

#set biome
    execute in overworld run fillbiome -24 -8 -24 24 24 24 basalt_deltas

#display
    tellraw @a "\u00a7bLevel 12: Fortress"
    
    tellraw @a "\u00a7aCredits:"
    tellraw @a "\u00a7a- Terrain: \u00a7fNotch, MLE_qwq"
    tellraw @a "\u00a77> (For copy-pasting from vanilla terrain =w=)"
    tellraw @a "\u00a7a- Code: \u00a7fMLE_qwq"
    

#specifying path blocks
    execute in overworld run setblock 15 -2 -15 cracked_nether_bricks
    execute in overworld run setblock 15 -2 -14 cracked_nether_bricks
#specifying dedicated original block
    execute in overworld run setblock 15 -2 -13 air

#marking
    execute in overworld run summon minecraft:marker -48 -64 48 {Tags:["terrain_origin"],CustomName:"Terrain Origin"}
    execute in overworld run summon minecraft:marker -11 8 -2 {Tags:["path_start","mob_spawnpoint"],CustomName:"Path Start"}
    execute in overworld run summon minecraft:marker 6 8 11 {Tags:["path_ending"],CustomName:"Path Ending"}

#summoning markers that lets path tracker & tester identify as air blocks
    execute in overworld run summon marker -10 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -9 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -8 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -7 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -6 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -5 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -4 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -3 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -2 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker -1 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 0 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 1 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 -2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 -1 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 0 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 1 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 2 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 3 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 4 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 5 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 6 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 7 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 8 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 9 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 10 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 2 8 11 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 3 8 11 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 4 8 11 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 5 8 11 {Tags:["auto_replace"],CustomName:"Auto Replace"}
    execute in overworld run summon marker 6 8 11 {Tags:["auto_replace"],CustomName:"Auto Replace"}

#additional mob spawnpoints
    execute in overworld run summon minecraft:marker 2 8 -12 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 1
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie
    execute in overworld run summon minecraft:marker -9 8 11 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 2
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie

#initial currency
    scoreboard players set #global game.data.currency 450

#stores wave data
    scoreboard players set #global game.state.total_waves 10

    #wave 1: zombified piglin
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 2
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 5
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    
    #wave 2: magma cube
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 13
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 2
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 30
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 3: magma cube
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 3
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 60
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
        
    #wave 4: blaze
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 4
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 200
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
        
    #wave 5: zombified piglin
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 16
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 90
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint -1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 6: magma cube
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 17
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 6
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 120
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 7: magma cube
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 18
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 7
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 150
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
        
    #wave 8: blaze
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 19
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 8
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 300
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #wave 9: zombified piglin
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 20
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 9
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 120
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint -1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
        
    #wave 10: blaze
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 21
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 400
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint -1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    #scoreboard players set @e[tag=wave_data] game.data.wave.mob_spawn_cd_org 20

function game:load_level_generic.after

