
#unlock contraptions
    execute in overworld unless score #global game.saves.cont_unlocked.tnt matches 1 run scoreboard players set #global game.saves.cont_unlocked.tnt 2
#unlocking levels
    execute in overworld unless score #global game.saves.levels_unlocked matches 10.. run scoreboard players set #global game.saves.levels_unlocked 10