function game:load_level_generic.before

scoreboard players set #global game.data.what_happens_to_water 1
#water freezes to ice

#set biome
    execute in overworld run fillbiome -24 -8 -24 24 24 24 snowy_slopes

#displaying instructions in chat
    tellraw @a "\u00a7bLevel 10: Ice Peak"

    tellraw @a "\u00a7aCredits:"
    tellraw @a "\u00a7a- Terrain: \u00a7fNotch, MLE_qwq"
    tellraw @a "\u00a77> (For copy-pasting from vanilla terrain =w=)"
    tellraw @a "\u00a7a- Code: \u00a7fMLE_qwq"
    
#specifying path blocks and pre-built path blocks
    execute in overworld run setblock 15 -2 -15 diamond_ore
    execute in overworld run setblock 15 -2 -14 minecraft:dirt
#specifying dedicated original block
    execute in overworld run setblock 15 -2 -13 snow_block

#marking
    execute in overworld run summon minecraft:marker 16 -64 48 {Tags:["terrain_origin"],CustomName:"Terrain Origin"}
    execute in overworld run summon minecraft:marker 0 2 -1 {Tags:["path_start"],CustomName:"Path Start"}
    execute in overworld run summon minecraft:marker 0 2 -1 {Tags:["path_ending"],CustomName:"Path Ending"}

    execute in overworld run summon minecraft:marker 0 2 9 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 1
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie
    
    execute in overworld run summon minecraft:marker -1 2 -11 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 2
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie
    
    execute in overworld run summon minecraft:marker -12 2 -3 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 3
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie
    
    execute in overworld run summon minecraft:marker 12 2 -2 {Tags:["additional","mob_spawnpoint","newbie"],CustomName:"Additional Mob Spawnpoint"}
    scoreboard players set @e[tag=mob_spawnpoint,tag=newbie] game.data.spawnpoint.mob_spawnpoint 4
    tag @e[tag=mob_spawnpoint,tag=newbie] remove newbie

#initial currency
    scoreboard players set #global game.data.currency 800

#stores wave data
    scoreboard players set #global game.state.total_waves 5
    #wave 1: wolf * 12
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 10
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 1
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 2: wolf * 13
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 13
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 2
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 12
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 2
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 3: wolf * 14
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 3
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 14
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 3
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 4: wolf * 15
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 15
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 1
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 4
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 16
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 4
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    #wave 5: snow_golem * 32
        execute in overworld run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 32
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 11
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number 5
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health 60
        scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint -1
        tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie
    scoreboard players set @e[tag=wave_data] game.data.wave.mob_spawn_cd_org 20

function game:load_level_generic.after
