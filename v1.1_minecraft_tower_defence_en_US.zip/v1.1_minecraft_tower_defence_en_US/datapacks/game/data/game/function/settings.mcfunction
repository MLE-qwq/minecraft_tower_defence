execute as @a at @s if score @s game.trigger.level_chosen matches -1001 run function game:dynamic_dialog.level_selection.0

execute as @a at @s if score @s game.trigger.level_chosen matches -2001 run scoreboard players add #global game.saves.settings.night_vision 1
execute as @a at @s if score @s game.trigger.level_chosen matches -2002 run scoreboard players add #global game.saves.settings.display_health_bar_for_contraptions 1
execute as @a at @s if score @s game.trigger.level_chosen matches -2004 run scoreboard players add #global game.saves.settings.content_of_health_bars 1

execute if score #global game.saves.settings.night_vision matches 2.. run scoreboard players set #global game.saves.settings.night_vision 0
execute if score #global game.saves.settings.display_health_bar_for_contraptions matches 2.. run scoreboard players set #global game.saves.settings.display_health_bar_for_contraptions 0
execute if score #global game.saves.settings.content_of_health_bars matches 2.. run scoreboard players set #global game.saves.settings.content_of_health_bars 0

execute as @a at @s if score @s game.trigger.level_chosen matches -2001 if score #global game.saves.settings.night_vision matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bNight Vision \u00a7eto \u00a7cOFF\u00a7e."]
execute as @a at @s if score @s game.trigger.level_chosen matches -2001 if score #global game.saves.settings.night_vision matches 1 run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bNight Vision \u00a7eto \u00a7aON\u00a7e."]

execute as @a at @s if score @s game.trigger.level_chosen matches -2002 if score #global game.saves.settings.display_health_bar_for_contraptions matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bDisplay Health Bars for Contraptions \u00a7eto \u00a7cOFF\u00a7e."]
execute as @a at @s if score @s game.trigger.level_chosen matches -2002 if score #global game.saves.settings.display_health_bar_for_contraptions matches 1 run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bDisplay Health Bars for Contraptions \u00a7eto \u00a7aON\u00a7e."]

execute as @a at @s if score @s game.trigger.level_chosen matches -2003 unless entity @a[tag=raycast_debug] run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bRaycast Debugging \u00a7eto \u00a7aON\u00a7e."]
execute as @a at @s if score @s game.trigger.level_chosen matches -2003 unless entity @a[tag=raycast_debug] as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute as @a at @s if score @s game.trigger.level_chosen matches -2003 unless entity @a[tag=raycast_debug] run tag @a add _raycast_debug
execute as @a at @s if score @s game.trigger.level_chosen matches -2003 if entity @a[tag=raycast_debug] run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bRaycast Debugging \u00a7eto \u00a7cOFF\u00a7e."]
execute as @a at @s if score @s game.trigger.level_chosen matches -2003 if entity @a[tag=raycast_debug] as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
execute as @a at @s if score @s game.trigger.level_chosen matches -2003 if entity @a[tag=raycast_debug] run tag @a remove raycast_debug

tag @a[tag=_raycast_debug] add raycast_debug
tag @a remove _raycast_debug

execute as @a at @s if score @s game.trigger.level_chosen matches -2004 if score #global game.saves.settings.content_of_health_bars matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bContent of Health Bars \u00a7eto \u00a7aPercentages\u00a7e."]
execute as @a at @s if score @s game.trigger.level_chosen matches -2004 if score #global game.saves.settings.content_of_health_bars matches 1 run tellraw @a ["",{"selector":"@s"},"\u00a7e has toggled \u00a7bContent of Health Bars \u00a7eto \u00a7cValues\u00a7e. (Note: In this case the line of text may be too long than appropriate!)"]

execute as @a at @s if score @s game.trigger.level_chosen matches -2001 if score #global game.saves.settings.night_vision matches 0 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
execute as @a at @s if score @s game.trigger.level_chosen matches -2002 if score #global game.saves.settings.display_health_bar_for_contraptions matches 0 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5
execute as @a at @s if score @s game.trigger.level_chosen matches -2004 if score #global game.saves.settings.content_of_health_bars matches 0 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute as @a at @s if score @s game.trigger.level_chosen matches -2001 if score #global game.saves.settings.night_vision matches 1 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute as @a at @s if score @s game.trigger.level_chosen matches -2002 if score #global game.saves.settings.display_health_bar_for_contraptions matches 1 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute as @a at @s if score @s game.trigger.level_chosen matches -2004 if score #global game.saves.settings.content_of_health_bars matches 1 run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 0.5

execute as @a at @s if score @s game.trigger.level_chosen matches -1002 run tag @s add show_settings_dialog
execute as @a at @s if score @s game.trigger.level_chosen matches -2999..-2000 run tag @s add show_settings_dialog
function game:dynamic_dialog.settings.0
tag @a remove show_settings_dialog