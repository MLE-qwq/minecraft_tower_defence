execute as @e[type=item] at @s if items entity @s contents *[custom_data~{display_only:1b}] run kill @s
execute as @e[type=item] at @s if items entity @s contents *[custom_data~{slot_placeholder:1b}] run kill @s

#if game not paused, trigger purchase scoreboard when player interact with purchase menu
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"cactus"}] run trigger game.trigger.purchase set 1
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"water"}] run trigger game.trigger.purchase set 3
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"trapdoor"}] run trigger game.trigger.purchase set 4
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"iron_bars"}] run trigger game.trigger.purchase set 6
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"egg_disp"}] run trigger game.trigger.purchase set 2
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"arrow_disp"}] run trigger game.trigger.purchase set 5
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"slime_disp"}] run trigger game.trigger.purchase set 7
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"tnt"}] run trigger game.trigger.purchase set 8
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"snow_disp"}] run trigger game.trigger.purchase set 9
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"lava"}] run trigger game.trigger.purchase set 10
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"fireball_disp"}] run trigger game.trigger.purchase set 11
    execute if score #global game.state.paused matches 0 as @a at @s if items entity @s player.cursor *[minecraft:custom_data={display_only:1b,id:"ender_pearl_disp"}] run trigger game.trigger.purchase set 12

#if game paused, notify that they cannot interact with purchase menu rn when they do so
    execute if score #global game.state.paused matches 1 as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{display_only:1b}] run tellraw @s "\u00a7cYou may not purchase contraptions when the game is paused."
    execute if score #global game.state.paused matches 1 as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{display_only:1b}] run playsound block.anvil.land master @s ~ ~ ~ 1 0.5

#if inventory full then they cannot continue purchasing
    function game:full_inventory_check
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score @s game.mechanism.inventory_slots_occupied matches 18 run tellraw @s "\u00a7cYour inventory is full."
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score @s game.mechanism.inventory_slots_occupied matches 18 run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score @s game.mechanism.inventory_slots_occupied matches 18 run scoreboard players set @s game.trigger.purchase 0

#if there is currently a contraption item present then they cannot continue purchasing
    scoreboard objectives add game.mechanism.items_falling dummy
    scoreboard players set #global game.mechanism.items_falling 0
    execute as @e[type=item] at @s if items entity @s contents *[custom_data~{is_cont:true}] run scoreboard players set #global game.mechanism.items_falling 1

    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score #global game.mechanism.items_falling matches 1 run tellraw @s "\u00a7cPlease wait until the dropped contraption items has hit the ground."
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score #global game.mechanism.items_falling matches 1 run playsound block.anvil.land master @s ~ ~ ~ 1 0.5
    execute as @a at @s if score @s game.trigger.purchase matches 1.. if score #global game.mechanism.items_falling matches 1 run scoreboard players set @s game.trigger.purchase 0

clear @a *[minecraft:custom_data~{display_only:1b}]
execute as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{display_only:1b}] run item replace entity @s player.cursor with air

clear @a *[custom_data~{slot_placeholder:1b}]
execute as @a at @s if items entity @s player.cursor *[minecraft:custom_data~{slot_placeholder:1b}] run item replace entity @s player.cursor with air


item replace entity @a container.9 with cactus[custom_data={display_only:1b,id:"cactus"},item_name="\u00a72Cactus",lore=["\u00a7r\u00a7aCost: $15","","\u00a7bUsage: Gives \u00a7c10 Damage\u00a7b to mobs","\u00a7bupon contact, while losing \u00a7c10 Durability\u00a7b.","\u00a7bInitially has \u00a7c15 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a path block.","\u00a7eCannot be put on bridges."]]
item replace entity @a container.10 with water_bucket[custom_data={display_only:1b,id:"water"},item_name="\u00a7bWater",lore=["\u00a7aCost: $50","","\u00a7bUsage: Slows mobs down upon contact. ","\u00a7eMethod: Drop the item onto a path block.","\u00a7eCannot be put on bridges."]]
item replace entity @a container.11 with oak_trapdoor[custom_data={display_only:1b,id:"trapdoor"},item_name="\u00a76Trapdoor",lore=["\u00a7aCost: $150","","\u00a7bUsage: Traps and kills mobs moving","\u00a7bslower than 4 blocks per second","\u00a7bupon contact.","\u00a7eMethod: Drop the item onto a path block.","\u00a7eHas infinite capacity if put on bridges."]]
item replace entity @a container.12 with iron_bars[custom_data={display_only:1b,id:"iron_bars"},item_name="\u00a77Iron Bars",lore=["\u00a7aCost: $200"," ","\u00a7bUsage: Obstructs mobs. Loses","\u00a7c20 Durability \u00a7bupon contact per mob","\u00a7bper second. Initially has \u00a7c1600 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a path block."]]
item replace entity @a container.13 with tnt[custom_data={display_only:1b,id:"tnt"},item_name="\u00a7cTNT",lore=["\u00a7aCost: $250"," ","\u00a7bUsage: Explodes in 2 seconds and","\u00a7bdamages mobs within a 4-block radius","\u00a7bby \u00a7c500 HP\u00a7b. ","\u00a7eMethod: Drop the item onto the path. "]]
item replace entity @a container.14 with lava_bucket[custom_data={display_only:1b,id:"lava"},item_name="\u00a76Lava",lore=["\u00a7aCost: $200","","\u00a7bUsage: Damages mobs continuously","\u00a7bupon contact and sets them on fire.","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a path block."]]
item replace entity @a container.15 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.16 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.17 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]

item replace entity @a container.18 with egg[custom_data={display_only:1b,id:"egg_disp"},item_name="\u00a7eEgg Dispenser",lore=["\u00a7aCost: $50","","\u00a7bUsage: Projects eggs in","\u00a7ball 4 directions. Has \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."]]
item replace entity @a container.19 with arrow[custom_data={display_only:1b,id:"arrow_disp"},item_name="\u00a77Arrow Dispenser",lore=["\u00a7aCost: $150","","\u00a7bUsage: Projects arrows in","\u00a7ball 4 directions. Has \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."]]
item replace entity @a container.20 with slime_ball[custom_data={display_only:1b,id:"slime_disp"},item_name="\u00a7aSlime Dispenser",lore=["\u00a7aCost: $100","","\u00a7bUsage: Projects slime balls in","\u00a7ball 4 directions which slow mobs","\u00a7bdown to half of their original speed. ","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."]]
item replace entity @a container.21 with snowball[custom_data={display_only:1b,id:"snow_disp"},item_name="\u00a7fSnow Dispenser",lore=["\u00a7aCost: $100"," ","\u00a7bUsage: Projects snowballs in","\u00a7ball 4 directions which temporarily","\u00a7bfreezes a mob's motion upon hit.","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."]]
item replace entity @a container.22 with fire_charge[custom_data={display_only:1b,id:"fireball_disp"},item_name="\u00a76Fireball Dispenser",lore=["\u00a7aCost: $150","","\u00a7bUsage: Projects fireballs in","\u00a7ball 4 directions which sets a mob","\u00a7bon fire upon hit. Has \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."]]
item replace entity @a container.23 with ender_pearl[custom_data={display_only:1b,id:"ender_pearl_disp"},item_name="\u00a73Ender Pearl Dispenser",lore=["\u00a7aCost: $450","","\u00a7bUsage: Projects ender pearls in","\u00a7ball 4 directions which teleports","\u00a7bmobs Close to spawnpoint upon hit.","\u00a7bHas \u00a7c150 Durability\u00a7b.","\u00a7eMethod: Drop the item onto a block","\u00a7aadjacent \u00a7eto a path block.","\u00a7eCannot be put on any path blocks."]]
item replace entity @a container.24 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.25 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]
item replace entity @a container.26 with light_gray_stained_glass_pane[item_name="",custom_data={slot_placeholder:1b}]

execute unless score #global game.saves.cont_unlocked.cactus matches 1 run item replace entity @a container.9 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.water matches 1 run item replace entity @a container.10 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.trapdoor matches 1 run item replace entity @a container.11 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.iron_bars matches 1 run item replace entity @a container.12 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.tnt matches 1 run item replace entity @a container.13 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.lava matches 1 run item replace entity @a container.14 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.egg_disp matches 1 run item replace entity @a container.18 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.arrow_disp matches 1 run item replace entity @a container.19 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.slime_disp matches 1 run item replace entity @a container.20 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.snow_disp matches 1 run item replace entity @a container.21 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.fireball_disp matches 1 run item replace entity @a container.22 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
execute unless score #global game.saves.cont_unlocked.ender_pearl_disp matches 1 run item replace entity @a container.23 with red_stained_glass_pane[item_name="\u00a7c\u00a7oLocked",custom_data={slot_placeholder:1b}]
