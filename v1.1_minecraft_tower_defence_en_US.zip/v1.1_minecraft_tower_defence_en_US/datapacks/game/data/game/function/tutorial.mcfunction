#if tutorial conduction finished then return
    execute if score #global game.saves.tutorial.conducted matches 1 run return fail

#if waiting for response
    scoreboard objectives add _ dummy
    scoreboard players operation #global _ = #global game.data.tutorial.waiting_for_response
    scoreboard players operation #global _ %= #global const.200
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global _ matches 0 as @a at @s run playsound entity.cat.ambient master @s ~ ~ ~
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 2 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please select an option...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 9 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please \u00a7enagivate\u00a7f to the \u00a7btutorial level\u00a7f: [Level Selection > Level 1: Desert]...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 20 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please expand the pathway to the block with the \u00a7agreen glowing outline\u00a7f...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 25 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please \u00a7epurchase\u00a7f a \u00a7bcactus\u00a7f from your inventory, and then hold it onto your \u00a7bmainhand\u00a7f...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 29 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please set the cactus contraption up by \u00a7edropping\u00a7f it onto the pathway...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 37 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please open the \u00a7bcontrol panel\u00a7f for the cactus by \u00a7edropping the hoe\u00a7f \u00a7conto\u00a7f it...! =w="
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. if score #global game.data.tutorial.step_id matches 45 if score #global _ matches 0 run tellraw @a "<MLE_qwq> I'm waiting... Please \u00a7eskip\u00a7f the \u00a7bcountdown\u00a7f by operating in the \u00a7bgame menu\u00a7f...! =w="

    #step_id 2: Yes or No
        scoreboard objectives add game.trigger.tutorial_response trigger
        
        execute if score #global game.data.tutorial.step_id matches 2 unless score #global game.data.tutorial.waiting_for_response matches 0 if score #global _ matches 0 run tellraw @a ["",{"text":"[Yes]","color":"green","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 2"}}," ",{"text":"[No]","color":"red","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 1"}}]
        
        execute if score #global game.data.tutorial.step_id matches 2 as @a at @s if score @s game.trigger.tutorial_response matches 1.. run scoreboard players set #global game.data.tutorial.step_finished 0
        execute as @a at @s if score @s game.trigger.tutorial_response matches 1.. if score #global game.data.tutorial.step_id matches 2 run scoreboard players set #global game.data.tutorial.waiting_for_response 0

        execute if score #global game.data.tutorial.step_id matches 2 run scoreboard players enable @a game.trigger.tutorial_response

        execute if score #global game.data.tutorial.step_id matches 2 as @a at @s if score @s game.trigger.tutorial_response matches 1 run scoreboard players set #global game.data.tutorial.step_id 3
        execute if score #global game.data.tutorial.step_id matches 2 as @a at @s if score @s game.trigger.tutorial_response matches 2 run scoreboard players set #global game.data.tutorial.step_id 5

    #step id 9: waiting for the tutorial level to begin
        execute if score #global game.data.tutorial.step_id matches 9 if score #global game.state matches 1 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 9 if score #global game.state matches 1 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 9 if score #global game.state matches 1 run scoreboard players set #global game.data.tutorial.step_id 10

    #step id 20: waiting for the path construction to finish
        execute if score #global game.data.tutorial.step_id matches 20 if score #global game.state matches 2 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 20 if score #global game.state matches 2 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 20 if score #global game.state matches 2 run scoreboard players set #global game.data.tutorial.step_id 21

    #step id 25: waiting for a cactus to be purchased
        execute if score #global game.data.tutorial.step_id matches 25 if items entity @a weapon.mainhand cactus[custom_data~{is_cont:true}] run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 25 if items entity @a weapon.mainhand cactus[custom_data~{is_cont:true}] run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 25 if items entity @a weapon.mainhand cactus[custom_data~{is_cont:true}] run scoreboard players set #global game.data.tutorial.step_id 26

    #step id 29: waiting for a cactus to be placed
        execute if score #global game.data.tutorial.step_id matches 29 if entity @e[tag=cont] run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 29 if entity @e[tag=cont] run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 29 if entity @e[tag=cont] run scoreboard players set #global game.data.tutorial.step_id 30

    #step id 37: waiting for control panel to be opened
        execute if score #global game.data.tutorial.step_id matches 37 if score #global game.data.tutorial.opened_control_panel matches 1 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 37 if score #global game.data.tutorial.opened_control_panel matches 1 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 37 if score #global game.data.tutorial.opened_control_panel matches 1 run scoreboard players set #global game.data.tutorial.step_id 38

    #step id 45: waiting for waves to start
        execute if score #global game.data.tutorial.step_id matches 45 if score #global game.state.waves_have_started matches 1 run scoreboard players set #global game.data.tutorial.step_finished 0
        execute if score #global game.data.tutorial.step_id matches 45 if score #global game.state.waves_have_started matches 1 run scoreboard players set #global game.data.tutorial.waiting_for_response 0
        execute if score #global game.data.tutorial.step_id matches 45 if score #global game.state.waves_have_started matches 1 run scoreboard players set #global game.data.tutorial.step_id 46

        
    execute if score #global game.data.tutorial.waiting_for_response matches 1.. run scoreboard players add #global game.data.tutorial.waiting_for_response 1

    #return
        execute if score #global game.data.tutorial.waiting_for_response matches 1.. run return fail

#if the current step in tutorial finished then return
    execute if score #global game.data.tutorial.step_finished matches 1 run return fail

scoreboard players set #global game.data.tutorial.step_finished 1

execute if score #global game.data.tutorial.step_id matches 1.. as @a at @s run playsound entity.cat.ambient master @s ~ ~ ~
execute if score #global game.data.tutorial.step_id matches 1 run tellraw @a "<MLE_qwq> Welcome aboard! uwu"
execute if score #global game.data.tutorial.step_id matches 1 run scoreboard players set * game.trigger.tutorial_response 0
execute if score #global game.data.tutorial.step_id matches 1 run scoreboard players set @a game.trigger.tutorial_response 0

execute if score #global game.data.tutorial.step_id matches 2 run tellraw @a "<MLE_qwq> Shall we conduct a tutorial? OwO"
execute if score #global game.data.tutorial.step_id matches 2 run tellraw @a ["",{"text":"[Yes]","color":"green","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 2"}}," ",{"text":"[No]","color":"red","click_event":{"action":"run_command","command":"/trigger game.trigger.tutorial_response set 1"}}]
execute if score #global game.data.tutorial.step_id matches 2 run scoreboard players set #global game.data.tutorial.waiting_for_response 1


execute if score #global game.data.tutorial.step_id matches 3 run tellraw @a "<MLE_qwq> Well, if that's what you think... =w="
execute if score #global game.data.tutorial.step_id matches 4 run tellraw @a "<MLE_qwq> Good luck and have fun then! OwO"
execute if score #global game.data.tutorial.step_id matches 4 run tellraw @a "\u00a7a=== End of Tutorial ==="
execute if score #global game.data.tutorial.step_id matches 4 run scoreboard players set #global game.saves.tutorial.conducted 1
execute if score #global game.data.tutorial.step_id matches 4 run return fail

execute if score #global game.data.tutorial.step_id matches 5 run tellraw @a "<MLE_qwq> Oh okay! Let's get started!"
execute if score #global game.data.tutorial.step_id matches 6 run tellraw @a "<MLE_qwq> See the \u00a7bcompass\u00a7f in your \u00a7bhotbar\u00a7f?"
execute if score #global game.data.tutorial.step_id matches 7 run tellraw @a "<MLE_qwq> You'll have to \u00a7ehold\u00a7f it in your \u00a7bmainhand\u00a7f..."
execute if score #global game.data.tutorial.step_id matches 8 run tellraw @a "<MLE_qwq> And then you'll have to \u00a7eright-click\u00a7f afterwards."
execute if score #global game.data.tutorial.step_id matches 9 run tellraw @a "<MLE_qwq> After opening the menu, please \u00a7enagivate\u00a7f to the \u00a7btutorial level\u00a7f: [Level Selection > Level 1: Desert]!"
execute if score #global game.data.tutorial.step_id matches 9 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 10 run tellraw @a "<MLE_qwq> Good! OwO"
execute if score #global game.data.tutorial.step_id matches 11 run tellraw @a "<MLE_qwq> Now, see that \u00a7bshovel\u00a7f in your \u00a7bhotbar\u00a7f?"
execute if score #global game.data.tutorial.step_id matches 12 run tellraw @a "<MLE_qwq> Please \u00a7ehold\u00a7f it in your \u00a7bmainhand\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 13 run tellraw @a "<MLE_qwq> And then \u00a7ewalking around\u00a7f shall \u00a7eexpand\u00a7f the \u00a7bpathway\u00a7f below your feet!"
execute if score #global game.data.tutorial.step_id matches 14 run tellraw @a "<MLE_qwq> Apparently, the \u00a7bend of the pathway\u00a7f is indicated by a \u00a7eyellow glowing outline\u00a7f."
execute if score #global game.data.tutorial.step_id matches 15 run tellraw @a "<MLE_qwq> Note that the pathway can only expand to the blocks \u00a7cadjacent\u00a7f to the block with the \u00a7eyellow glowing outline\u00a7f."
execute if score #global game.data.tutorial.step_id matches 16 run tellraw @a "<MLE_qwq> Also, the pathway shall not \u00a7eoverlap\u00a7f with its previous section."
execute if score #global game.data.tutorial.step_id matches 17 run tellraw @a "<MLE_qwq> The pathway will \u00a7eexpand\u00a7f to \u00a7bthe block you're standing on\u00a7f \u00a7conly if\u00a7f it is \u00a7avalid\u00a7f...! OwO"
execute if score #global game.data.tutorial.step_id matches 18 run tellraw @a "<MLE_qwq> You may even expand the path onto \u00a7bwater\u00a7f if you desire!"
execute if score #global game.data.tutorial.step_id matches 20 run tellraw @a "<MLE_qwq> Now, please \u00a7eexpand\u00a7f the \u00a7bpathway\u00a7f to the block with the \u00a7agreen glowing outline\u00a7f!"
execute if score #global game.data.tutorial.step_id matches 19 run tellraw @a "<MLE_qwq> Note that after this tutorial level you'll only have \u00a7b1 min 40 sec\u00a7f for doing so...!"
execute if score #global game.data.tutorial.step_id matches 20 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 21 run tellraw @a "<MLE_qwq> Alright! OwO"
execute if score #global game.data.tutorial.step_id matches 22 run tellraw @a "<MLE_qwq> Now you shall \u00a7edefend\u00a7f yourself with \u00a7bcontraptions\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 23 run tellraw @a "<MLE_qwq> Open your inventory..."
execute if score #global game.data.tutorial.step_id matches 24 run tellraw @a "<MLE_qwq> Then you will see a list of available contraptions to purchase!"
execute if score #global game.data.tutorial.step_id matches 25 run tellraw @a "<MLE_qwq> Go on and grab a \u00a7bcactus\u00a7f, and then hold it onto your \u00a7bmainhand\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 25 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 26 run tellraw @a "<MLE_qwq> Good! OwO"
execute if score #global game.data.tutorial.step_id matches 27 run tellraw @a "<MLE_qwq> Now \u00a7edrop\u00a7f (default keybind: Q) the cactus onto the pathway to set it up!"
execute if score #global game.data.tutorial.step_id matches 28 run tellraw @a "<MLE_qwq> Note that if the contraption to be set up is a \u00a7bdispenser\u00a7f (which in this case it isn't), you'll have to drop it onto a block \u00a7cadjacent\u00a7f to the pathway, in other words, it \u00a7ccannot\u00a7f be set up \u00a7cdirectly\u00a7f on the pathway...!"
execute if score #global game.data.tutorial.step_id matches 29 run tellraw @a "<MLE_qwq> Anyways... Go ahead!"
execute if score #global game.data.tutorial.step_id matches 29 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 30 run tellraw @a "<MLE_qwq> Well done! awa"
execute if score #global game.data.tutorial.step_id matches 31 run tellraw @a "<MLE_qwq> Apparantly, the text displayed above contraptions are their durabilities!"
execute if score #global game.data.tutorial.step_id matches 32 run tellraw @a "<MLE_qwq> Also, by dropping the \u00a7bgolden hoe\u00a7f in your hotbar \u00a7conto\u00a7f a contraption..."
execute if score #global game.data.tutorial.step_id matches 33 run tellraw @a "<MLE_qwq> You could then see the \u00a7bcontrol panel\u00a7f for that contraption...!"
execute if score #global game.data.tutorial.step_id matches 34 run tellraw @a "<MLE_qwq> In that control panel, you'll see a list of operations that could be done to the contraption..."
execute if score #global game.data.tutorial.step_id matches 35 run tellraw @a "<MLE_qwq> Including the removal of the contraption..."
execute if score #global game.data.tutorial.step_id matches 36 run tellraw @a "<MLE_qwq> Along with some upgrading options (which in this case there isn't any)!"
execute if score #global game.data.tutorial.step_id matches 37 run tellraw @a "<MLE_qwq> Go on, \u00a7edrop\u00a7f the \u00a7bgolden hoe\u00a7f onto the cactus...!"
scoreboard objectives add game.data.tutorial.opened_control_panel dummy
execute if score #global game.data.tutorial.step_id matches 36 run scoreboard players set #global game.data.tutorial.opened_control_panel 0
execute if score #global game.data.tutorial.step_id matches 37 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 38 run tellraw @a "<MLE_qwq> Good! OwO"
execute if score #global game.data.tutorial.step_id matches 39 run tellraw @a "<MLE_qwq> Note that you could \u00a7epause\u00a7f or \u00a7eresume\u00a7f the game anytime by operating in the game menu..."
execute if score #global game.data.tutorial.step_id matches 40 run tellraw @a "<MLE_qwq> If you needed to travel between places without the progression of time..."
execute if score #global game.data.tutorial.step_id matches 41 run tellraw @a "<MLE_qwq> Or rather, when you simply wanted to stroll around...!"
execute if score #global game.data.tutorial.step_id matches 42 run tellraw @a "<MLE_qwq> You can also \u00a7etoggle\u00a7f the \u00a7bspeed multiplier\u00a7f of time progression among x1.0, x2.0 and x3.0, which is also in the \u00a7bgame menu\u00a7f!"
execute if score #global game.data.tutorial.step_id matches 43 run tellraw @a "<MLE_qwq> Whenever you think you're ready for the next wave of mobs to come..."
execute if score #global game.data.tutorial.step_id matches 44 run tellraw @a "<MLE_qwq> You could choose to \u00a7eskip\u00a7f the \u00a7bcountdown\u00a7f, which is again in the \u00a7bgame menu\u00a7f!"
execute if score #global game.data.tutorial.step_id matches 45 run tellraw @a "<MLE_qwq> Give it a shot! Skip the countdown, unless you wanted to wait all the way till the end...!"
execute if score #global game.data.tutorial.step_id matches 45 run scoreboard players set #global game.data.tutorial.waiting_for_response 1

execute if score #global game.data.tutorial.step_id matches 46 run scoreboard players set #global game.state.paused 1
execute if score #global game.data.tutorial.step_id matches 46 as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.5
execute if score #global game.data.tutorial.step_id matches 46 run tellraw @a ["MLE_qwq","\u00a7e has \u00a7cpaused \u00a7etime."]
execute if score #global game.data.tutorial.step_id matches 46 run tellraw @a "<MLE_qwq> Similar to the contraptions, you could also see the health of a mob by targeting your crosshair at the mob...!"
execute if score #global game.data.tutorial.step_id matches 47 run tellraw @a "<MLE_qwq> Note that you can only damage the mobs through contraptions!"
execute if score #global game.data.tutorial.step_id matches 48 run tellraw @a "<MLE_qwq> And after doing so you will gain a certain amount of currency, which could be used for upgrading or purchasing new contraptions!"
execute if score #global game.data.tutorial.step_id matches 49 run tellraw @a "<MLE_qwq> In this tutorial level, you have \u00a7b1 min\u00a7f preparation time between waves..."
execute if score #global game.data.tutorial.step_id matches 49 run tellraw @a "<MLE_qwq> And after the tutorial level, the number goes down to \u00a7b20 sec\u00a7f...!"
execute if score #global game.data.tutorial.step_id matches 50 run tellraw @a "<MLE_qwq> Ehh... Perhaps I'd better not bother you from defending the mobs for now... =w="
execute if score #global game.data.tutorial.step_id matches 51 run tellraw @a "<MLE_qwq> Well, that's pretty much it!"
execute if score #global game.data.tutorial.step_id matches 52 run tellraw @a "<MLE_qwq> Good luck! Off I go! OwO"
execute if score #global game.data.tutorial.step_id matches 52 run tellraw @a "\u00a7a=== End of Tutorial ==="
execute if score #global game.data.tutorial.step_id matches 52 run tellraw @a ["MLE_qwq","\u00a7e has \u00a7aresumed \u00a7etime."]
execute if score #global game.data.tutorial.step_id matches 52 run scoreboard players set #global game.state.paused 0
execute if score #global game.data.tutorial.step_id matches 52 as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
execute if score #global game.data.tutorial.step_id matches 52 run scoreboard players set #global game.saves.tutorial.conducted 1
execute if score #global game.data.tutorial.step_id matches 52 run return fail

schedule clear game:tutorial_progression
execute unless score #global game.data.tutorial.waiting_for_response matches 1 run schedule function game:tutorial_progression 50 append