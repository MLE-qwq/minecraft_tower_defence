data merge storage game:dynamic_dialog.level_selection {this:{lvl_1:"\u00a77\u00a7oLocked",lvl_2:"\u00a77\u00a7oLocked",lvl_3:"\u00a77\u00a7oLocked",lvl_4:"\u00a77\u00a7oLocked",lvl_5:"\u00a77\u00a7oLocked",lvl_6:"\u00a77\u00a7oLocked",lvl_7:"\u00a77\u00a7oLocked",lvl_8:"\u00a77\u00a7oLocked",lvl_9:"\u00a77\u00a7oLocked",lvl_10:"\u00a77\u00a7oLocked",lvl_11:"\u00a77\u00a7oLocked",lvl_12:"\u00a77\u00a7oLocked",lvl_finale:"\u00a77\u00a7oLocked"}}

execute if score #global game.saves.levels_unlocked matches 1.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_1:"Level 1: Desert"}}
execute if score #global game.saves.levels_unlocked matches 2.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_2:"Level 2: Forest"}}
execute if score #global game.saves.levels_unlocked matches 3.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_3:"Level 3: Village"}}
execute if score #global game.saves.levels_unlocked matches 4.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_4:"Level 4: Ravine"}}
execute if score #global game.saves.levels_unlocked matches 5.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_5:"Level 5: Mineshaft 1"}}
execute if score #global game.saves.levels_unlocked matches 6.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_6:"Level 6: Mineshaft 2"}}
execute if score #global game.saves.levels_unlocked matches 7.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_7:"Level 7: Spider Cavern"}}
execute if score #global game.saves.levels_unlocked matches 8.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_8:"Level 8: Underground Ravine"}}
execute if score #global game.saves.levels_unlocked matches 9.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_9:"Level 9: Mountain Ascent"}}
execute if score #global game.saves.levels_unlocked matches 10.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_10:"Level 10: Ice Peak"}}
execute if score #global game.saves.levels_unlocked matches 11.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_11:"Level 11: Crimson Forest"}}
execute if score #global game.saves.levels_unlocked matches 12.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_12:"Level 12: Fortress"}}
execute if score #global game.saves.levels_unlocked matches 1000.. run data merge storage game:dynamic_dialog.level_selection {this:{lvl_finale:"\u00a7dFinale: The End (Bossfight)"}}

function game:dynamic_dialog.level_selection.1 with storage game:dynamic_dialog.level_selection this
