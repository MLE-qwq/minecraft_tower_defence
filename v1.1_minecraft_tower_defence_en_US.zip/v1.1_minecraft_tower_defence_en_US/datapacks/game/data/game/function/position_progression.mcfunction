tag @e[tag=mob] remove freezed
execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 1.. run tag @s add freezed

scoreboard objectives add game.mechanism.position_progression_block_count dummy
scoreboard objectives add game.mechanism.cur_position dummy

execute as @e[tag=mob] at @s run scoreboard players operation @s game.mechanism.position_progression_block_count = #global const.1000000
execute as @e[tag=mob] at @s run scoreboard players operation @s game.mechanism.position_progression_block_count /= @s game.data.mob.ticks_per_block

#if the mob is currently slowed down then halve the distance moving
    execute as @e[tag=mob] at @s if score @s game.data.mob.slowness_remaining_duration matches 1.. run scoreboard players operation @s game.mechanism.position_progression_block_count /= #global const.2
    #along with visual effects
    execute as @e[tag=mob] at @s if score @s game.data.mob.slowness_remaining_duration matches 1.. run particle item_slime ~ ~ ~ 0 0 0 0.1 5

#burning indicator
    team add game.burning_outline
    team modify game.burning_outline color gold
    execute as @e[tag=mob,team=game.burning_outline] at @s unless score @s game.data.mob.fire_remaining_duration matches 1.. run effect clear @s glowing
    execute as @e[tag=mob,team=game.burning_outline] at @s unless score @s game.data.mob.fire_remaining_duration matches 1.. run team leave @s
    execute as @e[tag=mob] at @s if score @s game.data.mob.fire_remaining_duration matches 1.. run team join game.burning_outline @s
    execute as @e[tag=mob] at @s if score @s game.data.mob.fire_remaining_duration matches 1.. run effect give @s glowing infinite 255 true

#freezing indicator
    team add game.freezing_outline
    team modify game.freezing_outline color aqua
    execute as @e[tag=mob,team=game.freezing_outline] at @s unless score @s game.data.mob.freezing_remaining_duration matches 1.. run effect clear @s glowing
    execute as @e[tag=mob,team=game.freezing_outline] at @s unless score @s game.data.mob.freezing_remaining_duration matches 1.. run team leave @s
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 1.. run team join game.freezing_outline @s
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 1.. run effect give @s glowing infinite 255 true

#freezing indicator - block display
    execute as @e[tag=freezing_indicator] at @s run data merge entity @s {block_state:{Name:"minecraft:air",id:"minecraft:air"}}

    scoreboard objectives add _ dummy
    execute as @e[tag=mob] at @s run scoreboard players operation @s _ = @s game.data.mob.freezing_total_duration
    execute as @e[tag=mob] at @s run scoreboard players remove @s _ 1
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration = @s _ run summon block_display ~ ~ ~ {block_state:{id:"minecraft:air",Name:"minecraft:air"},Tags:["freezing_indicator"]}
    
    execute as @e[tag=mob] at @s run scoreboard players operation @s _ = @s game.data.mob.freezing_remaining_duration
    execute as @e[tag=mob] at @s run scoreboard players operation @s _ *= #global const.1000000
    execute as @e[tag=mob] at @s run scoreboard players operation @s _ /= @s game.data.mob.freezing_total_duration
    
    #note: this section uses both Name and id for compatibility

    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 750001..1000000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{Name:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"0"},id:"minecraft:frosted_ice",properties:{age:"0"}}}
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 500001..750000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{Name:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"1"},id:"minecraft:frosted_ice",properties:{age:"1"}}}
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 250001..500000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{Name:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"2"},id:"minecraft:frosted_ice",properties:{age:"2"}}}
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 0..250000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{Name:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"3"},id:"minecraft:frosted_ice",properties:{age:"3"}}}


    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 750001..1000000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{id:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"0"},id:"minecraft:frosted_ice",properties:{age:"0"}}}
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 500001..750000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{id:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"1"},id:"minecraft:frosted_ice",properties:{age:"1"}}}
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 250001..500000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{id:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"2"},id:"minecraft:frosted_ice",properties:{age:"2"}}}
    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 2.. if score @s _ matches 0..250000 run data merge entity @n[tag=freezing_indicator,nbt={block_state:{id:"minecraft:air"}}] {transformation:{translation:[-0.5,0,-0.5]},block_state:{Name:"minecraft:frosted_ice",Properties:{age:"3"},id:"minecraft:frosted_ice",properties:{age:"3"}}}

    execute as @e[tag=mob] at @s if score @s game.data.mob.freezing_remaining_duration matches 1 run kill @n[tag=freezing_indicator,nbt={block_state:{Name:"minecraft:air",id:"minecraft:air"}}]

execute as @e[tag=mob,tag=x] at @s store result score @s game.mechanism.cur_position run data get entity @s Pos[0] 1000000
execute as @e[tag=mob,tag=z] at @s store result score @s game.mechanism.cur_position run data get entity @s Pos[2] 1000000

execute as @e[tag=mob] at @s run scoreboard players add @s game.mechanism.position_progression_block_count 1

execute as @e[tag=mob,tag=-] at @s run scoreboard players operation @s game.mechanism.position_progression_block_count *= #global const.-1

execute as @e[tag=mob] at @s run scoreboard players operation @s game.mechanism.cur_position += @s game.mechanism.position_progression_block_count

execute as @e[tag=x,tag=mob,tag=!obstructed,tag=!freezed,tag=!riding,tag=!reached_the_end,tag=!move_by_teleportation] at @s if score @s game.data.mob.ticks_left_until_next_anchor matches 1.. store result entity @s Pos[0] double 0.000001 run scoreboard players get @s game.mechanism.cur_position
execute as @e[tag=z,tag=mob,tag=!obstructed,tag=!freezed,tag=!riding,tag=!reached_the_end,tag=!move_by_teleportation] at @s if score @s game.data.mob.ticks_left_until_next_anchor matches 1.. store result entity @s Pos[2] double 0.000001 run scoreboard players get @s game.mechanism.cur_position
