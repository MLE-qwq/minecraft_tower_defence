scoreboard players enable @a game.trigger.level_chosen
function game:settings
scoreboard players set @a game.trigger.level_chosen 0
scoreboard players set * game.trigger.level_chosen 0
