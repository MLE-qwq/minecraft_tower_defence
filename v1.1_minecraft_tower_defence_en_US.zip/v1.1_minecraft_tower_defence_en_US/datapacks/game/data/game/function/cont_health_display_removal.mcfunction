scoreboard objectives add _x dummy
scoreboard objectives add _z dummy

$execute as @e[nbt={UUID:$(UUID)}] at @s store result score #global _x run data get entity @s Pos[0] 1
$execute as @e[nbt={UUID:$(UUID)}] at @s store result score #global _z run data get entity @s Pos[2] 1

execute as @e[tag=cont_health_display] at @s store result score @s _x run data get entity @s Pos[0] 1
execute as @e[tag=cont_health_display] at @s store result score @s _z run data get entity @s Pos[2] 1

execute as @e[tag=cont_health_display] at @s if score @s _x = #global _x if score @s _z = #global _z run kill @s