scoreboard objectives add game.mechanism.inventory_slots_occupied dummy
scoreboard players set @a game.mechanism.inventory_slots_occupied 0

execute as @a at @s if data entity @s Inventory[{Slot:0b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:1b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:2b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:3b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:4b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:5b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:6b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:7b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:8b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1

execute as @a at @s if data entity @s Inventory[{Slot:27b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:28b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:29b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:30b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:31b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:32b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:33b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:34b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1
execute as @a at @s if data entity @s Inventory[{Slot:35b}] run scoreboard players add @s game.mechanism.inventory_slots_occupied 1