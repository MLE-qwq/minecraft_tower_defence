$tag @e[nbt={UUID:$(UUID)},limit=1] add target_cont
execute as @a at @s if score @s game.data.uuid = @e[tag=target_cont,limit=1] game.data.uuid run tag @s add target_player

execute store result storage game:dynamic_dialog.upgrades.lava this.currency int 1 run scoreboard players get #global game.data.currency

execute store result storage game:dynamic_dialog.upgrades.lava this.health int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.health
execute store result storage game:dynamic_dialog.upgrades.lava this.max_health int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.max_health

scoreboard objectives add _ dummy
scoreboard players operation #global _ = #global const.100
scoreboard players operation #global _ *= @e[tag=target_cont,limit=1] game.data.health
scoreboard players operation #global _ /= @e[tag=target_cont,limit=1] game.data.max_health
execute store result storage game:dynamic_dialog.upgrades.lava this.health_percentage int 1 run scoreboard players get #global _

scoreboard players operation #global _ = @e[tag=target_cont,limit=1] game.data.cont.worth_raw
scoreboard players operation #global _ *= @e[tag=target_cont,limit=1] game.data.health
scoreboard players operation #global _ /= @e[tag=target_cont,limit=1] game.data.max_health
execute store result storage game:dynamic_dialog.upgrades.lava this.worth int 1 run scoreboard players get #global _
scoreboard players operation #global _ *= #global const.60
scoreboard players operation #global _ /= #global const.100
execute store result storage game:dynamic_dialog.upgrades.lava this.worth_discount int 1 run scoreboard players get #global _

execute store result storage game:dynamic_dialog.upgrades.lava this.damage int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.damage
execute store result storage game:dynamic_dialog.upgrades.lava this.damage_next int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.damage_next
execute store result storage game:dynamic_dialog.upgrades.lava this.damage_cost int 1 run scoreboard players get @e[tag=target_cont,limit=1] game.data.cont.damage_cost

function game:dynamic_dialog.upgrades.lava.1 with storage game:dynamic_dialog.upgrades.lava this

tag @a remove target_player
tag @e[tag=cont] remove target_cont