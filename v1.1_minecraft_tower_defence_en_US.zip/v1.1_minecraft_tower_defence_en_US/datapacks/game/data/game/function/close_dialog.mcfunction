scoreboard objectives add game.trigger.close_dialog trigger
scoreboard players enable @a game.trigger.close_dialog

#1 for a regular close_dialog
#2 indicates that the player just stopped viewing the statistics of a contraption

execute as @a at @s if score @s game.trigger.close_dialog matches 1.. run dialog clear @s
execute as @e[tag=cont] at @s as @a if score @s game.trigger.close_dialog matches 2 if score @s game.data.uuid = @n[tag=cont] game.data.uuid run scoreboard players set @n[tag=cont] game.data.uuid 0
execute as @a at @s if score @s game.trigger.close_dialog matches 1.. run scoreboard players set @s game.trigger.close_dialog 0
