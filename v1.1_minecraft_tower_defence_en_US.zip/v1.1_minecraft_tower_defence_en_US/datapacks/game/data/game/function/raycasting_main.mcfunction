#this function tags the mob or contraption being targeted by the crosshair of the player (such that their health could be shown above them)

execute if entity @a[tag=raycast_debug] run tag @a add raycast_debug

#assigns contraption durability
    scoreboard objectives add _ dummy
    execute as @e[tag=cont_health_display] at @s run scoreboard players operation @s _ = @n[tag=cont] game.data.health
    execute as @e[tag=cont_health_display] at @s run scoreboard players operation @s _ *= #global const.100
    execute as @e[tag=cont_health_display] at @s run scoreboard players operation @s _ *= #global const.100
    execute as @e[tag=cont_health_display] at @s run scoreboard players operation @s _ /= @n[tag=cont] game.data.max_health
    execute as @e[tag=cont_health_display] at @s run scoreboard players operation @s _ /= #global const.100

    execute if score #global game.saves.settings.display_health_bar_for_contraptions matches 1 if score #global game.saves.settings.content_of_health_bars matches 1 as @e[tag=cont_health_display] at @s run data merge entity @s {billboard:"center","text":[{"score":{"name":"@n[tag=cont]","objective":"game.data.health"},"color":"aqua"},"\u00a73/",{"score":{"name":"@n[tag=cont]","objective":"game.data.max_health"},"color":"dark_aqua"}],see_through:0b}
    execute if score #global game.saves.settings.display_health_bar_for_contraptions matches 1 if score #global game.saves.settings.content_of_health_bars matches 0 as @e[tag=cont_health_display] at @s run data merge entity @s {billboard:"center","text":[{"score":{"name":"@s","objective":"_"},"color":"aqua"},"\u00a73%"],see_through:0b}
    execute if score #global game.saves.settings.display_health_bar_for_contraptions matches 0 run data merge entity @s {billboard:"center","text":""}
#termination
    execute unless entity @a[tag=!raycast_done] as @e[tag=health_display,tag=!hd_processed] at @s run data merge entity @s {text:""}
    execute unless entity @a[tag=!raycast_done] run return run tag @a remove raycast_done

#init
    execute unless entity @a[tag=raycast_done] run tag @e[tag=health_display] remove hd_processed
    
tag @a[limit=1,tag=!raycast_done] add raycast_target_player

function game:raycasting_sub

tag @a[tag=raycast_target_player] add raycast_done
tag @a remove raycast_target_player

function game:raycasting_main
