#this function drop the items in the slots that is preserved for functional items (e.g. the clock, the door) into item entities and will be given Close to the player, otherwise they'll get replaced with those functional items immediately and get lost

#if already finished processing for everyone, return with the removal of the tag
    execute unless entity @a[tag=!item_recovery_done] run return run tag @a remove item_recovery_done

#tag a player which hasn't done the processing
    tag @a[limit=1,tag=!item_recovery_done] add item_recovery_target_player

#stores the item in those slots into storage, and summons the item with the same data in the storage onto the face of the player by starting the function item_recovery_sub
    #slot hotbar.7
        execute if score #global game.state matches 1 as @a[tag=item_recovery_target_player] at @s if items entity @s hotbar.7 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:0b}]
        execute if score #global game.state matches 1 as @a[tag=item_recovery_target_player] at @s if items entity @s hotbar.7 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
    #slot hotbar.7
        execute if score #global game.state matches 2 as @a[tag=item_recovery_target_player] at @s if items entity @s hotbar.7 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:7b}]
        execute if score #global game.state matches 2 as @a[tag=item_recovery_target_player] at @s if items entity @s hotbar.7 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
    #slot hotbar.8
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s hotbar.8 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:8b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s hotbar.8 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item

    #slot weapon.offhand
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s weapon.offhand *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s equipment.offhand
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s weapon.offhand *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item

    #slot container.9~26
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.9 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:9b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.9 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.10 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:10b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.10 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.11 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:11b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.11 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.12 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:12b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.12 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.13 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:13b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.13 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.14 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:14b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.14 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.15 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:15b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.15 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.16 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:16b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.16 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.17 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:17b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.17 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.18 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:18b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.18 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.19 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:19b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.19 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.20 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:20b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.20 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.21 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:21b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.21 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.22 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:22b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.22 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.23 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:23b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.23 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.24 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:24b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.24 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.25 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:25b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.25 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.26 *[minecraft:custom_data~{item_recovery:true}] run data modify storage game:item_recovery item set from entity @s Inventory[{Slot:26b}]
        execute as @a[tag=item_recovery_target_player] at @s if items entity @s container.26 *[minecraft:custom_data~{item_recovery:true}] run function game:item_recovery_sub with storage game:item_recovery item
        

tag @a[tag=item_recovery_target_player] add item_recovery_done
tag @a remove item_recovery_target_player
function game:item_recovery_main
