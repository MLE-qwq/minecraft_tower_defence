execute if score #global game.state.paused matches 0 run data merge storage game:dynamic_dialog.game_menu {this:{pausing:"\u00a7cPause \u00a7eTime"}}
execute if score #global game.state.paused matches 1 run data merge storage game:dynamic_dialog.game_menu {this:{pausing:"\u00a7aResume \u00a7eTime"}}


execute if score #global game.data.speed_up matches 0 run data merge storage game:dynamic_dialog.game_menu {this:{speed_up:"Speed Up: \u00a7ax1.0"}}
execute if score #global game.data.speed_up matches 1 run data merge storage game:dynamic_dialog.game_menu {this:{speed_up:"Speed Up: \u00a7ex2.0"}}
execute if score #global game.data.speed_up matches 2 run data merge storage game:dynamic_dialog.game_menu {this:{speed_up:"Speed Up: \u00a7cx3.0"}}

function game:dynamic_dialog.game_menu.1 with storage game:dynamic_dialog.game_menu this
