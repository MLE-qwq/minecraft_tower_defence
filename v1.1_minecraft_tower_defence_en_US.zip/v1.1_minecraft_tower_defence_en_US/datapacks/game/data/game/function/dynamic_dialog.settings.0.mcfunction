#display the dialog to those who has the show_settings_dialog tag

execute if score #global game.saves.settings.night_vision matches 0 run data merge storage game:dynamic_dialog.settings {this:{night_vision:"\u00a7cOFF"}}
execute if score #global game.saves.settings.night_vision matches 1 run data merge storage game:dynamic_dialog.settings {this:{night_vision:"\u00a7aON"}}

execute if score #global game.saves.settings.display_health_bar_for_contraptions matches 0 run data merge storage game:dynamic_dialog.settings {this:{display_health_bar_for_contraptions:"\u00a7cOFF"}}
execute if score #global game.saves.settings.display_health_bar_for_contraptions matches 1 run data merge storage game:dynamic_dialog.settings {this:{display_health_bar_for_contraptions:"\u00a7aON"}}

execute if score #global game.saves.settings.content_of_health_bars matches 0 run data merge storage game:dynamic_dialog.settings {this:{content_of_health_bars:"\u00a7aPercentages"}}
execute if score #global game.saves.settings.content_of_health_bars matches 1 run data merge storage game:dynamic_dialog.settings {this:{content_of_health_bars:"\u00a7cValues"}}

execute unless entity @a[tag=raycast_debug] run data merge storage game:dynamic_dialog.settings {this:{raycast_debugging:"\u00a7cOFF"}}
execute if entity @a[tag=raycast_debug] run data merge storage game:dynamic_dialog.settings {this:{raycast_debugging:"\u00a7aON"}}

function game:dynamic_dialog.settings.1 with storage game:dynamic_dialog.settings this
