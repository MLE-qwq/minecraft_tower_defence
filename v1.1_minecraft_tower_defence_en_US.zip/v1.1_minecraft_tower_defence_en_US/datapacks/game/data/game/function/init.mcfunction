#gamerules
    gamerule advance_time false
    gamerule advance_weather false
    gamerule allow_entering_nether_using_portals false
    gamerule drowning_damage false
    gamerule entity_drops false
    gamerule fall_damage true
    gamerule fire_damage true
    gamerule freeze_damage false
    gamerule immediate_respawn false
    gamerule keep_inventory true
    gamerule mob_drops false
    gamerule mob_griefing false
    gamerule natural_health_regeneration false
    gamerule pvp false
    gamerule players_sleeping_percentage 101
    gamerule show_death_messages true
    gamerule spawn_mobs false
    gamerule spawn_monsters false
    gamerule spawn_patrols false
    gamerule spawn_phantoms false
    gamerule spawner_blocks_work false
    gamerule spawn_wandering_traders false
    gamerule spawn_wardens false
    gamerule spread_vines false
    gamerule tnt_explodes false
    gamerule command_block_output true
    gamerule command_blocks_work true
    #switch the following to false after debugging
    #also clear all scoreboard objectives in saves file. better to let them know how to preserve their progress through guiding them copy-paste that file.
        gamerule send_command_feedback false
    xp set @a 0 levels
    xp set @a 0 points
#end

#revokes triggering advancements
    advancement revoke @a only game:interactions.show_menu

#scoreboards
    scoreboard objectives add game.saves.tutorial.conducted dummy
    scoreboard objectives add game.data.tutorial.step_id dummy
    scoreboard objectives add game.data.tutorial.step_finished dummy
    scoreboard objectives add game.data.tutorial.waiting_for_response dummy
    scoreboard players set #global game.data.tutorial.step_id 0
    scoreboard players set #global game.data.tutorial.step_finished 0
    scoreboard players set #global game.data.tutorial.waiting_for_response 0
    execute unless score #global game.saves.tutorial.conducted matches 1 run scoreboard players set #global game.saves.tutorial.conducted 0

    function hardcode:cont.purchase.unlocked_scoreboards
    
    scoreboard objectives add game.data.speed_up dummy

    scoreboard objectives add game.level dummy
    scoreboard objectives add game.state dummy
    scoreboard players set #global game.state 0
    scoreboard objectives add game.state_prev dummy
    scoreboard players set #global game.state_prev -1
    scoreboard players set @a game.trigger.level_chosen 0
    scoreboard players set * game.trigger.level_chosen 0
    scoreboard objectives add game.trigger.level_chosen trigger
    
    scoreboard objectives add game.state.current_wave dummy
    scoreboard players set #global game.state.current_wave 0
    scoreboard objectives add game.state.total_waves dummy
    scoreboard objectives add game.state.waves_have_started dummy
    scoreboard players set #global game.state.waves_have_started 0

    scoreboard objectives add game.data.currency dummy
    scoreboard objectives add game.trigger.purchase trigger

    #health does not fall within the mob class since durability of contraptions share the same variable
    scoreboard objectives add game.data.health dummy
    scoreboard objectives add game.data.health_prev dummy
    scoreboard objectives add game.data.max_health dummy
    scoreboard objectives add game.data.mob.spawnpoint dummy
    scoreboard objectives add game.data.mob.has_mercy dummy
    scoreboard objectives add game.data.mob.currency_drop dummy
    #the speed of the mob: how many ticks it takes for it to progress one block
        scoreboard objectives add game.data.mob.ticks_per_block dummy
        scoreboard objectives add game.data.mob.ticks_per_block_original dummy
    #once reaches zero, the mob will be anchored onto the next path block marker
        scoreboard objectives add game.data.mob.ticks_left_until_next_anchor dummy
        scoreboard objectives add game.data.spawnpoint.mob_spawnpoint dummy
    #size of slime
        scoreboard objectives add game.data.slime_size dummy

    scoreboard objectives add game.mechanism.mob_spawn_cd dummy

    scoreboard objectives add game.state.player_dead deathCount
    scoreboard players set * game.state.player_dead 0

    scoreboard objectives add game.data.cont.damage_cd dummy

    scoreboard objectives add game.state.paused dummy

    scoreboard objectives add game.data.uuid dummy
    scoreboard objectives add game.data.mob_uuid dummy

    scoreboard objectives add game.data.disp_cont.damage dummy
    scoreboard objectives add game.data.disp_cont.damage_next dummy
    scoreboard objectives add game.data.disp_cont.damage_cost dummy
    scoreboard objectives add game.data.disp_cont.range dummy
    scoreboard objectives add game.data.disp_cont.range_next dummy
    scoreboard objectives add game.data.disp_cont.range_cost dummy
    scoreboard objectives add game.data.disp_cont.fire_rate dummy
    scoreboard objectives add game.data.disp_cont.fire_rate_next dummy
    scoreboard objectives add game.data.disp_cont.fire_rate_cost dummy
    scoreboard objectives add game.data.cont.viscosity dummy
    scoreboard objectives add game.data.cont.viscosity_next dummy
    scoreboard objectives add game.data.cont.viscosity_cost dummy
    scoreboard objectives add game.data.cont.damage dummy
    scoreboard objectives add game.data.cont.damage_next dummy
    scoreboard objectives add game.data.cont.damage_cost dummy
    scoreboard objectives add game.data.disp_cont.duration dummy
    scoreboard objectives add game.data.disp_cont.duration_next dummy
    scoreboard objectives add game.data.disp_cont.duration_cost dummy
    
    scoreboard objectives add game.data.cont.mobs_trapped dummy
    scoreboard objectives add game.data.cont.capacity dummy
    scoreboard objectives add game.data.cont.capacity_next dummy
    scoreboard objectives add game.data.cont.capacity_cost dummy
    
    scoreboard objectives add game.mechanism.disp_cont.fire_cd dummy
    scoreboard objectives add game.mechanism.projectile.init_xz dummy

    scoreboard objectives add game.data.mob_spawn_cd_org dummy
    scoreboard objectives add game.data.wave.mob_spawn_cd_org dummy

    scoreboard objectives add game.data.bonus_chest.currency dummy

    
    scoreboard objectives add game.trigger.operation trigger
    scoreboard players set @a game.trigger.operation 0
    scoreboard players set * game.trigger.operation 0

    scoreboard objectives add game.mechanism.new_currency_display dummy
    scoreboard objectives add game.mechanism.new_currency_display_cd dummy
    scoreboard players set #global game.mechanism.new_currency_display_cd 0

    gamerule max_block_modifications 114514

    
    scoreboard objectives add const.1000000 dummy
    scoreboard players set #global const.1000000 1000000
    scoreboard objectives add const.100 dummy
    scoreboard players set #global const.100 100
    scoreboard objectives add const.80 dummy
    scoreboard players set #global const.80 80
    scoreboard objectives add const.70 dummy
    scoreboard players set #global const.70 70
    scoreboard objectives add const.55 dummy
    scoreboard players set #global const.55 55
    scoreboard objectives add const.40 dummy
    scoreboard players set #global const.40 40
    scoreboard objectives add const.30 dummy
    scoreboard players set #global const.30 30
    scoreboard objectives add const.67 dummy
    scoreboard players set #global const.67 67
    scoreboard objectives add const.35 dummy
    scoreboard players set #global const.35 35
    scoreboard objectives add const.25 dummy
    scoreboard players set #global const.25 25
    scoreboard objectives add const.57 dummy
    scoreboard players set #global const.57 57
    scoreboard objectives add const.45 dummy
    scoreboard players set #global const.45 45
    scoreboard objectives add const.33 dummy
    scoreboard players set #global const.33 33
    scoreboard objectives add const.-1 dummy
    scoreboard players set #global const.-1 -1
    scoreboard objectives add const.10 dummy
    scoreboard players set #global const.10 10
    scoreboard objectives add const.5 dummy
    scoreboard players set #global const.5 5
    scoreboard objectives add const.2 dummy
    scoreboard players set #global const.2 2
    scoreboard objectives add const.3 dummy
    scoreboard players set #global const.3 3
    scoreboard objectives add const.6 dummy
    scoreboard players set #global const.6 6
    scoreboard objectives add const.200 dummy
    scoreboard players set #global const.200 200


    scoreboard objectives add game.finale.dragon dummy

    scoreboard objectives add game.infinite_waves dummy
    
    scoreboard objectives add game.data.cont.worth_raw dummy

    scoreboard objectives add game.saves.levels_unlocked dummy
    execute unless score #global game.saves.levels_unlocked matches 1.. run scoreboard players set #global game.saves.levels_unlocked 1

    scoreboard objectives add game.saves.game_beat dummy
    execute unless score #global game.saves.game_beat matches 1 run scoreboard players set #global game.saves.game_beat 0

    scoreboard objectives add game.saves.easter_egg.count dummy
    scoreboard players set #global game.saves.easter_egg.count -1
    scoreboard objectives add game.saves.easter_egg.0 dummy
    scoreboard objectives add game.saves.easter_egg.1 dummy
    scoreboard objectives add game.saves.easter_egg.2 dummy
    execute unless score #global game.saves.easter_egg.0 matches 1 run scoreboard players set #global game.saves.easter_egg.0 0
    execute unless score #global game.saves.easter_egg.1 matches 1 run scoreboard players set #global game.saves.easter_egg.1 0
    execute unless score #global game.saves.easter_egg.2 matches 1 run scoreboard players set #global game.saves.easter_egg.2 0

    scoreboard objectives add game.saves.settings.night_vision dummy
    scoreboard objectives add game.saves.settings.display_health_bar_for_contraptions dummy
    scoreboard objectives add game.saves.settings.content_of_health_bars dummy
    execute unless score #global game.saves.settings.content_of_health_bars matches 1 run scoreboard players set #global game.saves.settings.content_of_health_bars 0
    execute unless score #global game.saves.settings.night_vision matches 1 run scoreboard players set #global game.saves.settings.night_vision 0
    execute unless score #global game.saves.settings.display_health_bar_for_contraptions matches 0 run scoreboard players set #global game.saves.settings.display_health_bar_for_contraptions 1
    execute unless score #global game.saves.settings.display_health_bar_for_contraptions matches 1 run scoreboard players set #global game.saves.settings.display_health_bar_for_contraptions 0

    scoreboard objectives add game.data.mob.fire_remaining_duration dummy
    scoreboard objectives add game.data.mob.slowness_remaining_duration dummy
    scoreboard objectives add game.data.mob.freezing_remaining_duration dummy
    scoreboard objectives add game.data.mob.freezing_total_duration dummy
    scoreboard objectives add game.data.poisoning dummy

    scoreboard objectives add game.data.mob.damage_cd.lava dummy

    scoreboard objectives add game.mechanism.active_ticks dummy
    scoreboard players set #global game.mechanism.active_ticks 0

    scoreboard objectives add game.data.what_happens_to_water dummy

    scoreboard objectives add game.data.y_level dummy

    difficulty normal
    
    execute in overworld run forceload add -48 -48 48 80
    execute in the_end run forceload add -21 -21 21 21

    scoreboard players set @a game.finale.ending_music_cd -1
    scoreboard players set * game.finale.ending_music_cd -1
    stopsound @a * music_disc.mellohi

    gamemode adventure @a
#end

function game:quit_level
tellraw @a "\u00a7aInitialized command set."
