$execute as @a[tag=item_recovery_target_player] at @s run summon item ~ ~ ~ {Item:{id:"$(id)",count:$(count),components:$(components)},Tags:["ignore_existence"]}
