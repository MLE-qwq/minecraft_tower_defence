execute if score #global game.level matches 1000 in the_end run tp @a 0 1000 0
execute unless score #global game.level matches 1000 in overworld run tp @a 0 1000 0

scoreboard players set #global game.infinite_waves 0

#removing leftover entities
    tp @e[tag=block_outline] 0 -10000 0
    tp @e[tag=block_outline2] 0 -10000 0
    kill @e[tag=block_outline]
    kill @e[tag=block_outline2]
    kill @e[tag=terrain_origin]
    kill @e[tag=path_start]
    kill @e[tag=path_ending]
    kill @e[tag=path_tracker]
    kill @e[tag=path_tester]
    kill @e[tag=path_block]
    kill @e[tag=mob_spawnpoint]
    kill @e[tag=health_display]
    kill @e[tag=cont_health_display]
    kill @e[tag=projectile]
    kill @e[tag=auto_replace]
    kill @e[tag=bonus_chest]
    kill @e[tag=bonus_chest_display]
    kill @e[tag=batch_sub]
    kill @e[tag=path_forbidden]
    kill @e[tag=path_validity]
    kill @e[tag=freezing_indicator]
    kill @e[tag=end_crystal]
    kill @e[tag=finale_path_start_or_end]
    kill @e[tag=ender_dragon]
    kill @e[tag=dragon_fireball]
    
    tp @e[tag=display_entity] 0 -10000 0
    kill @e[tag=display_entity]
    kill @e[tag=tnt_launchpad]
    
    kill @e[tag=cont]
    kill @e[tag=inferior_cont]
    kill @e[tag=wave_data]

    tp @e[tag=npc] 0 -10000 0
    kill @e[tag=npc]

    tp @e[tag=mob] 0 -10000 0
    kill @e[tag=mob]

scoreboard players set #global game.mechanism.active_ticks 0
scoreboard players set #global game.data.speed_up 0

scoreboard players set #global game.data.what_happens_to_water 0
#0: nothing happens; 1: water freezes; 2: water disappears

#wave data init
    scoreboard objectives add game.data.wave.mob_count dummy
    scoreboard objectives add game.data.wave.mob_type dummy
    scoreboard objectives add game.data.wave.mob_health dummy
    scoreboard objectives add game.data.wave.mob_spawnpoint dummy
    scoreboard objectives add game.data.wave.mob_has_mercy dummy
    scoreboard objectives add game.data.wave.wave_number dummy
    
    scoreboard players set #global game.state.current_wave 0

#resets player death
    scoreboard players set @a game.state.player_dead 0
    scoreboard players set * game.state.player_dead 0

#resets purchase info
    scoreboard players set @a game.trigger.purchase 0
    scoreboard players set * game.trigger.purchase 0

#pauses time if enabled in settings
    scoreboard players set #global game.state.paused 0

#clears operations to be done
    scoreboard players set @a game.trigger.operation 0
    scoreboard players set * game.trigger.operation 0

#removes bossbar
    bossbar remove current_wave
    bossbar remove finale

#removes poisoning state
    scoreboard players set #global game.data.poisoning 0
    effect clear @a poison

#removes items
    clear @a
    item replace entity @a player.cursor with air
    kill @e[type=item]

#sets player max health
    execute in overworld as @a at @s run attribute @s minecraft:max_health base set 14

#displaying instructions in chat
    tellraw @a "\n\u00a7d-----------------------------------------------------"

