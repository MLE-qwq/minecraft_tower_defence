function game:load_level_generic.before

advancement revoke @a only story/enter_the_end
advancement grant @a only story/enter_the_end

#bossbar
    bossbar add finale "\u00a7dEnd Crystal \u00a77- \u00a7e1 \u00a7dof \u00a7e3"
    bossbar set finale visible true
    bossbar set finale color purple
    bossbar set finale max 1600
    bossbar set finale value 1600

scoreboard players set #global game.finale.dragon 0
scoreboard players set #global game.infinite_waves 1

scoreboard objectives add game.finale.stage dummy
scoreboard players set #global game.finale.stage 0

#displaying instructions in chat
    tellraw @a "\u00a7dFinale: The End (Bossfight)"
    tellraw @a "\u00a7aCredits:"
    tellraw @a "\u00a7a- Terrain: \u00a7fMLE_qwq"
    tellraw @a "\u00a7a- Code: \u00a7fMLE_qwq"

#specifying path blocks and pre-built path blocks
    execute in the_end run setblock 15 1 -15 end_stone_bricks
#specifying dedicated original block
    execute in the_end run setblock 15 0 -13 end_stone

#marking
    execute in the_end run summon minecraft:marker -12 61 12 {Tags:["finale_path_start_or_end","finale_path_start_or_end_1","path_start","mob_spawnpoint"],CustomName:"Finale Path Start/Ending 1"}
    execute in the_end run summon minecraft:marker -12 61 -12 {Tags:["finale_path_start_or_end","finale_path_start_or_end_2","path_ending"],CustomName:"Finale Path Start/Ending 2"}
    execute in the_end run summon minecraft:marker 12 61 -12 {Tags:["finale_path_start_or_end","finale_path_start_or_end_3"],CustomName:"Finale Path Start/Ending 3"}
    execute in the_end run summon minecraft:marker 12 61 12 {Tags:["finale_path_start_or_end","finale_path_start_or_end_4"],CustomName:"Finale Path Start/Ending 4"}
    execute in the_end run summon minecraft:marker 0 61 4 {Tags:["finale_path_start_or_end","finale_path_start_or_end_5"],CustomName:"Finale Path Start/Ending 5"}

    execute in the_end run summon minecraft:text_display -14 62.5 -14 {text:"",billboard:"center",see_through:1b,Tags:["tnt_launchpad"]}

    execute in overworld run summon marker -14 61 -14 {Tags:["path_forbidden"],CustomName:"Path Forbidden"}
    execute in overworld run summon marker 14 61 -14 {Tags:["path_forbidden"],CustomName:"Path Forbidden"}
    execute in overworld run summon marker 14 61 14 {Tags:["path_forbidden"],CustomName:"Path Forbidden"}

#end crystals
    execute in the_end run summon minecraft:end_crystal -15.5 74 -15.5 {Tags:["end_crystal","end_crystal_1","current_end_crystal"]}
    execute in the_end run summon minecraft:end_crystal 16.5 74 -15.5 {Tags:["end_crystal","end_crystal_2"]}
    execute in the_end run summon minecraft:end_crystal 16.5 74 16.5 {Tags:["end_crystal","end_crystal_3"]}

#initial currency
    scoreboard players set #global game.data.currency 450


#-------------------------------------

#stores y coord of path start
    execute in the_end store result score #global game.data.y_level run data get entity @e[tag=path_start,limit=1] Pos[1] 1.0

#assign a unique id for each player
    scoreboard players set @a game.data.uuid 0
    scoreboard players set * game.data.uuid 0
    scoreboard players set #global game.data.uuid 1

    execute in the_end as @a at @s run function game:assign_unique_id with entity @s

#tps player to the beginning of the path
    execute in the_end as @e[tag=path_start] at @s run tp @a ~ ~1 ~ facing entity @n[tag=path_ending]

#terrain init
    function finale:build_terrain

#scoreboard
    scoreboard players set @e[tag=path_start] game.data.spawnpoint.mob_spawnpoint 0

function finale:block_outline

#spawnpoint
    execute in the_end as @e[tag=path_start] at @s run spawnpoint @a ~ ~1 ~ 0.0 0.0
    execute in the_end as @e[tag=path_start] at @s run setworldspawn ~ ~1 ~


#setting up path construction system
#path_tracker: a marker that indicates the most recent path block
#path_tester: a marker that will be teleported in all 4 directions around the path_tracker looking for legitimate air blocks

    execute in the_end as @e[tag=path_start] at @s run execute in the_end run summon minecraft:marker ~ ~ ~ {Tags:["path_tracker"],CustomName:"Path Tracker"}
    execute in the_end as @e[tag=path_start] at @s run execute in the_end run summon minecraft:marker ~ ~ ~ {Tags:["path_tester"],CustomName:"Path Tester"}
    #generates path block marker
    execute in the_end as @e[tag=path_tracker] at @s run execute in the_end run summon minecraft:marker ~ ~ ~ {Tags:["path_block"],CustomName:"Path Block"}

#displaying instructions in chat

    tellraw @a "\u00a7d-----------------------------------------------------"
    execute in the_end as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~

#sets the loop function to path_construction
    scoreboard players set #global game.state 1
    scoreboard players set #global game.state.waves_have_started 0

#removes player on fire state
    gamemode spectator @a

tellraw @a "<MLE_qwq> Hi there! You're just about to reach the \u00a7dend\u00a7f of this map! There is indeed \u00a7bnew stuff\u00a7f in this finale level, so I will be \u00a7eproviding necessary information\u00a7f as we move on...! =w="
execute as @a at @s run playsound entity.cat.ambient master @a ~ ~ ~ 1 1