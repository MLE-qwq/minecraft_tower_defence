#processing time pause
    execute in the_end as @a at @s if score @s game.trigger.operation matches -2 run scoreboard players add #global game.state.paused 1
    execute in the_end if score #global game.state.paused matches 2.. run scoreboard players set #global game.state.paused 0

    execute in the_end as @a at @s if score @s game.trigger.operation matches -2 run dialog clear @s

    #announcing which player paused/resumed time
        execute in the_end as @a at @s if score @s game.trigger.operation matches -2 if score #global game.state.paused matches 0 run tellraw @a ["",{"selector":"@s"},"\u00a7e has \u00a7aresumed \u00a7etime."]
        execute in the_end as @a at @s if score @s game.trigger.operation matches -2 if score #global game.state.paused matches 1 run tellraw @a ["",{"selector":"@s"},"\u00a7e has \u00a7cpaused \u00a7etime."]
    execute in the_end as @a at @s if score @s game.trigger.operation matches -2 if score #global game.state.paused matches 0 as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1
    execute in the_end as @a at @s if score @s game.trigger.operation matches -2 if score #global game.state.paused matches 1 as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.5
    execute in the_end if score #global game.state.paused matches 1 run title @a actionbar "\u00a7cTime paused. Operate in game menu to resume." 
    execute in the_end as @a at @s if score @s game.trigger.operation matches -2 run scoreboard players set @s game.trigger.operation 0

    execute in the_end if score #global game.mechanism.timer matches ..0 if score #global game.state.waves_have_started matches 0 run scoreboard players set #global game.state.waves_have_started 2

#starting other functions
    execute in the_end if score #global game.state matches 0 run function game:game_menu
    execute in the_end if score #global game.state matches 1 run function finale:path_construction
    execute in the_end if score #global game.state matches 2 run function finale:contraption_placement
    execute in the_end if score #global game.state matches 1..2 run function game:players_joining_or_quitting_within_a_round
    execute in the_end if score #global game.state matches 1..2 run function game:raycasting_main
    execute in the_end if score #global game.state.paused matches 0 if score #global game.state matches 1..2 if score #global game.state.waves_have_started matches 1.. run function game:waves
    execute in the_end if score #global game.state matches 1..2 run function game:death_detector

    execute if score #global game.state matches 1..2 run function finale:ender_dragon

#display settings menu during gameplay
    execute if score #global game.state matches 1..2 run function game:settings_in_game
    execute in the_end if score #global game.state matches 1..2 run function hardcode:level.special_effects
    execute in the_end if score #global game.state matches 1..2 run function game:interactions
#gives players night vision if enabled in settings
    execute in the_end if score #global game.saves.settings.night_vision matches 1 run effect give @a night_vision infinite 255 true
    execute in the_end unless score #global game.saves.settings.night_vision matches 1 run effect clear @a night_vision

#disabling offhand and crafting slots
    item replace entity @a weapon.offhand with air

#syncing previous state with current state, such that when they are different the subfunction knows that it needs to initialize
    scoreboard players operation #global game.state_prev = #global game.state

scoreboard players add #global game.mechanism.active_ticks 1
function game:easter_eggs