execute unless score #global game.finale.dragon matches 1.. run return fail

kill @e[type=dragon_fireball]

execute in the_end if score #global game.finale.dragon matches 2 run summon ender_dragon -128 90 128 {Tags:["ender_dragon"],DragonPhase:10}
execute in the_end if score #global game.finale.dragon matches 2 run rotate @s 45 0
execute in the_end if score #global game.finale.dragon matches 2 run scoreboard players set #global game.finale.dragon 1

execute in the_end as @e[tag=ender_dragon] at @s run tp @s ^ ^ ^-0.35 45 0
scoreboard objectives add _ dummy
execute in the_end as @e[tag=ender_dragon] at @s store result score #global _ run data get entity @s Pos[0] 1.0
#tellraw @a [{"score":{"name":"#global","objective":"_"}}]
execute unless entity @e[tag=ender_dragon,tag=fired] in the_end unless entity @e[tag=dragon_fireball] if score #global _ matches 0.. run tag @e[tag=cont,sort=random,limit=1] add dragon_fireball_bombardment_target
execute in the_end unless entity @e[tag=dragon_fireball] if score #global _ matches 0.. if entity @e[tag=dragon_fireball_bombardment_target] as @a at @s run playsound minecraft:entity.ender_dragon.shoot hostile @a ~ ~ ~ 1 1
execute in the_end unless entity @e[tag=dragon_fireball] if score #global _ matches 0.. if entity @e[tag=dragon_fireball_bombardment_target] run tag @e[tag=ender_dragon] add fired
execute in the_end unless entity @e[tag=dragon_fireball] if score #global _ matches 0.. if entity @e[tag=dragon_fireball_bombardment_target] as @e[tag=ender_dragon] at @s run summon item_display ~ ~ ~ {Tags:["dragon_fireball"],item:{id:"clay_ball",count:1},billboard:"center",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2f,2f,2f]}}

execute in the_end if entity @e[tag=dragon_fireball] as @e[tag=dragon_fireball] at @s run rotate @s facing entity @n[tag=dragon_fireball_bombardment_target]
execute in the_end if entity @e[tag=dragon_fireball] as @e[tag=dragon_fireball] at @s run tp @s ^ ^ ^0.25
execute in the_end if entity @e[tag=dragon_fireball] as @e[tag=dragon_fireball] at @s run tp @s ^ ^ ^0.25
execute in the_end if entity @e[tag=dragon_fireball] as @e[tag=dragon_fireball] at @s run tp @s ^ ^ ^0.25
execute in the_end if entity @e[tag=dragon_fireball] as @e[tag=dragon_fireball] at @s run tp @s ^ ^ ^0.25
execute in the_end if entity @e[tag=dragon_fireball] as @e[tag=dragon_fireball] at @s if entity @e[tag=dragon_fireball_bombardment_target,distance=..2] run tag @s add boom
execute in the_end if entity @e[tag=dragon_fireball] unless entity @e[tag=dragon_fireball_bombardment_target] as @e[tag=dragon_fireball] at @s unless block ~ ~ ~ air run tag @s add boom
#in case they remove the contraption after dragon fireball was shooted

execute as @e[tag=dragon_fireball] at @s run particle dragon_breath ~ ~ ~ 0 0 0 1 1

execute in the_end as @e[tag=dragon_fireball,tag=boom] at @s run tp @s @n[tag=dragon_fireball_bombardment_target]
execute in the_end as @e[tag=dragon_fireball,tag=boom] at @s run particle explosion_emitter ~ ~ ~ 0 0 0 1 1
execute in the_end as @e[tag=dragon_fireball,tag=boom] at @s run playsound entity.generic.explode block @a ~ ~1 ~ 1 0.7

scoreboard objectives add __ dummy
execute store result score #global __ run bossbar get finale value
execute if score #global game.finale.stage matches 3 in the_end positioned 0 63 0 if entity @e[tag=dragon_fireball,tag=boom,distance=..8] run scoreboard players remove #global __ 200
execute if score #global game.finale.stage matches 3 in the_end positioned 0 63 0 if entity @e[tag=dragon_fireball,tag=boom,distance=..8] unless score #global __ matches ..0 run damage @e[tag=ender_dragon,limit=1] 1 mob_attack by @r
execute if score #global game.finale.stage matches 3 in the_end positioned 0 63 0 if entity @e[tag=dragon_fireball,tag=boom,distance=..8] unless score #global __ matches ..0 run data merge entity @e[tag=ender_dragon,limit=1] {Health:200.0f}
execute if score #global game.finale.stage matches 3 in the_end positioned 0 63 0 if entity @e[tag=dragon_fireball,tag=boom,distance=..8] if score #global __ matches ..0 run damage @e[tag=ender_dragon,limit=1] 114514 mob_attack by @r

execute if score #global game.finale.stage matches 3 in the_end positioned 0 63 0 if entity @e[tag=dragon_fireball,tag=boom,distance=..8] if score #global __ matches ..0 run scoreboard players set #global game.finale.stage -1

execute store result bossbar finale value run scoreboard players get #global __
execute in the_end as @e[tag=dragon_fireball,tag=boom] at @s run scoreboard players set @e[tag=dragon_fireball_bombardment_target] game.data.health 0
kill @e[tag=dragon_fireball,tag=boom]

execute if score #global _ matches 128.. run kill @e[tag=ender_dragon]
execute unless entity @e[tag=ender_dragon] unless entity @e[tag=dragon_fireball] run scoreboard players set #global game.finale.dragon 0