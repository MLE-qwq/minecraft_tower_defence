execute in the_end if score #global game.saves.game_beat matches 1 run setblock 0 66 0 air destroy
execute in the_end if score #global game.saves.game_beat matches 1 run fill -2 61 -2 2 61 2 air replace minecraft:bedrock destroy
execute in the_end if score #global game.saves.game_beat matches 1 run setblock 2 61 2 minecraft:bedrock
execute in the_end if score #global game.saves.game_beat matches 1 run setblock 2 61 -2 minecraft:bedrock
execute in the_end if score #global game.saves.game_beat matches 1 run setblock -2 61 -2 minecraft:bedrock
execute in the_end if score #global game.saves.game_beat matches 1 run setblock -2 61 2 minecraft:bedrock
execute in the_end if score #global game.saves.game_beat matches 1 as @a[nbt={Dimension:"minecraft:the_end"}] at @s run playsound minecraft:block.end_portal.spawn master @a ~ ~ ~ 1 1