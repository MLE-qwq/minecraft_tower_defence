#stores wave data: count = 5 + wave, health = 10 + 3 * wave
    execute in the_end run summon marker 0 0 0 {Tags:["wave_data","newbie"],CustomName:"Wave Data"}
    
    scoreboard players operation @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count = #global game.state.current_wave
    scoreboard players add @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_count 5
    
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_type 9
    
    scoreboard players operation @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.wave_number = #global game.state.current_wave
    
    scoreboard players operation @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health = #global game.state.current_wave
    scoreboard players operation @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health *= #global const.3
    scoreboard players operation @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_health += #global const.10
    
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawnpoint 0
    
    scoreboard players set @e[tag=wave_data,tag=newbie,limit=1] game.data.wave.mob_spawn_cd_org 20
    
    tag @e[tag=wave_data,tag=newbie,limit=1] remove newbie

    execute if score #global game.finale.stage matches 1.. run scoreboard players set #global game.finale.dragon 2