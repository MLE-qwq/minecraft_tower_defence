scoreboard objectives add game.finale.ending_music_cd dummy
scoreboard objectives add game.finale.ending_dialog dummy
scoreboard objectives add game.finale.ending_dialog_progression_cd dummy
execute as @a[x=4,dx=-8,y=0,dy=4,z=4,dz=-24,nbt={Dimension:"minecraft:the_end"}] at @s run tag @s add ending_music

execute as @a[x=-2,y=6,z=-2,dx=5,dy=8,dz=5,nbt={Dimension:"minecraft:the_end"}] at @s run playsound entity.player.big_fall player @s ~ ~ ~ 1 1
execute as @a[x=-2,y=6,z=-2,dx=5,dy=8,dz=5,nbt={Dimension:"minecraft:the_end"}] at @s run tp @s 0 2 0
effect give @a[x=-2,y=6,z=-2,dx=5,dy=50,dz=5,nbt={Dimension:"minecraft:the_end"}] darkness 3 1 true

stopsound @a[tag=!ending_music] master music_disc.mellohi
stopsound @a[tag=ending_music] music
scoreboard players set @a[tag=!ending_music] game.finale.ending_music_cd -1

execute as @a[tag=ending_music] at @s if score @s game.finale.ending_music_cd matches -1 run title @s actionbar "\u00a75Now Playing: \u00a7d\u00a7oNiko and the World Machine \u00a7r\u00a75- \u00a7dNightmargin"
execute as @a[tag=ending_music] at @s if score @s game.finale.ending_music_cd matches -1 unless score @s game.finale.ending_dialog matches -1 run scoreboard players set @s game.finale.ending_dialog 0
execute as @a[tag=ending_music] at @s if score @s game.finale.ending_music_cd matches -1 unless score @s game.finale.ending_dialog matches -1 run scoreboard players set @s game.finale.ending_dialog_progression_cd 0


execute as @a[tag=ending_music] at @s if score @s game.finale.ending_music_cd matches ..0 run playsound minecraft:music_disc.mellohi master @a ~ ~ ~ 1 1
execute as @a[tag=ending_music] at @s if score @s game.finale.ending_music_cd matches ..0 if score @s game.finale.ending_music_cd matches ..0 run scoreboard players set @s game.finale.ending_music_cd 3840

execute as @a[tag=ending_music] at @s run scoreboard players remove @s game.finale.ending_music_cd 1
execute unless entity @e[tag=ending_music] run tp @e[tag=npc2] 0 -10000 0
execute unless entity @e[tag=ending_music] run kill @e[tag=npc2]
execute if entity @e[tag=ending_music] unless entity @e[tag=npc2] run summon minecraft:mannequin 0.5 2 -9.5 {Invulnerable:1b,CustomNameVisible:true,CustomName:"MLE_qwq",profile:"MLE_qwq",pose:"crouching",immovable:1b,Tags:["npc2"]}

effect give @e[tag=npc2] resistance infinite 255 true
effect give @e[tag=npc2] regeneration infinite 255 true
execute as @e[tag=npc2] at @s at @p run rotate @s facing ~ ~0.5 ~


execute as @e[type=item] at @s if items entity @s contents *[custom_data~{kill_on_drop:1b}] run kill @s

scoreboard objectives add game.watchdog.excess_items dummy
scoreboard players set @a game.watchdog.excess_items 0
execute as @a at @s store result score @s game.watchdog.excess_items if items entity @s container.* *[minecraft:custom_data~{id:"guider"}]
execute as @a at @s if score @s game.watchdog.excess_items matches 2.. run clear @s *[minecraft:custom_data~{id:"guider"}]
execute as @a at @s if items entity @s player.cursor *[custom_data~{id:"guider"}] run item replace entity @s player.cursor with air
clear @a[tag=!ending_music] *[custom_data~{id:"guider"}]

#dialog
    execute as @a[tag=ending_music,x=1,dx=-3,z=-7,dz=-3,y=0,dy=4,nbt={Dimension:"minecraft:the_end"}] at @s if score @s game.finale.ending_dialog matches 0 run scoreboard players set @s game.finale.ending_dialog_progression_cd 50
    execute as @a[tag=ending_music,x=1,dx=-3,z=-7,dz=-3,y=0,dy=4,nbt={Dimension:"minecraft:the_end"}] at @s if score @s game.finale.ending_dialog matches 0 run scoreboard players set @s game.finale.ending_dialog 1

    execute as @a at @s if score @s game.finale.ending_dialog matches 1.. if score @s game.finale.ending_dialog_progression_cd matches 50 unless score @s game.finale.ending_dialog matches 6 unless score @s game.finale.ending_dialog matches 7 at @e[tag=npc2,limit=1] run playsound entity.cat.ambient player @s ~ ~ ~ 1 1
    execute as @a at @s if score @s game.finale.ending_dialog_progression_cd matches 50 if score @s game.finale.ending_dialog matches 6 at @e[tag=npc2,limit=1] run playsound entity.cat.beg_for_food player @s ~ ~ ~ 1 1
    execute as @a at @s if score @s game.finale.ending_dialog_progression_cd matches 50 if score @s game.finale.ending_dialog matches 7 at @e[tag=npc2,limit=1] run playsound entity.cat.beg_for_food player @s ~ ~ ~ 1 1
    execute as @a at @s if score @s game.finale.ending_dialog matches 1 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> Hi there, ",{"selector":"@s"},"! =w="]
    execute as @a at @s if score @s game.finale.ending_dialog matches 2 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> First of all, huge congrats on beating the entire map!"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 3 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> Thank you so much for downloading, attemping to play and eventually finishing the map till the end..."]
    execute as @a at @s if score @s game.finale.ending_dialog matches 4 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> A project which, I've spent nearly half a year on... ÓwÒ"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 5 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> Hope you've enjoyed it anyways!"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 6 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> Also I'd appreciate that you give a like, tip a coin and favorite the introduction video I made about this map on Bilibili... (My channel: ",{"text":"\u00a7b\u00a7nLink","click_event":{"action":"open_url","url":"https://space.bilibili.com/1351759750"}},")"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 7 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> And that you hit the like button on my QQ homepage... (My account: ",{"text":"\u00a7e\u00a7n482284091","click_event":{"action":"copy_to_clipboard","value":"482284091"}},")"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 8 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> That would mean a lot to me... Please consider doing so...! ÓwÒ"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 9 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> ...that is, if you have an account!"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 10 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> (Also, if you're willing to chat, I'd be happy to accompany...!) =w="]
    execute as @a at @s if score @s game.finale.ending_dialog matches 11 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> And, yeah, again, thanks for playing! =w="]
    execute as @a at @s if score @s game.finale.ending_dialog matches 12 if score @s game.finale.ending_dialog_progression_cd matches 50 run tellraw @s ["<MLE_qwq> I think that's all I had to say...! OwO"]
    execute as @a at @s if score @s game.finale.ending_dialog matches 12 run scoreboard players set @s game.finale.ending_dialog -1

    execute as @a at @s if score @s game.finale.ending_dialog matches 1.. run scoreboard players remove @s game.finale.ending_dialog_progression_cd 1
    execute as @a at @s if score @s game.finale.ending_dialog matches 1.. if score @s game.finale.ending_dialog_progression_cd matches ..0 run scoreboard players add @s game.finale.ending_dialog 1
    execute as @a at @s if score @s game.finale.ending_dialog matches 1.. if score @s game.finale.ending_dialog_progression_cd matches ..0 run scoreboard players set @s game.finale.ending_dialog_progression_cd 50

execute unless entity @a[scores={game.finale.ending_dialog=-1}] in the_end run fill 0 2 3 0 3 3 minecraft:black_concrete
execute if entity @a[scores={game.finale.ending_dialog=-1}] in the_end if block 0 2 3 black_concrete run fill 0 2 3 0 3 3 tinted_glass
execute if entity @a[scores={game.finale.ending_dialog=-1}] in the_end if block 0 2 3 tinted_glass run playsound minecraft:block.end_portal.spawn block @a 0.5 3 3.5 1 1.3
execute if entity @a[scores={game.finale.ending_dialog=-1}] in the_end if block 0 2 3 tinted_glass run fill 0 2 3 0 3 3 light destroy
execute unless entity @a[scores={game.finale.ending_dialog=-1}] run item replace entity @e[tag=ending_music] hotbar.7 with minecraft:compass[custom_name="\u00a7rFollow Me",minecraft:lodestone_tracker={target:{pos:[I;0,6,-10],dimension:"minecraft:the_end"}},custom_data={id:"guider",kill_on_drop:1b}]

execute if entity @a[scores={game.finale.ending_dialog=-1}] run item replace entity @e[tag=ending_music] hotbar.7 with minecraft:compass[custom_name="\u00a7rFollow Me\u00a7r",minecraft:lodestone_tracker={target:{pos:[I;0,4,4],dimension:"minecraft:the_end"}},custom_data={id:"guider",kill_on_drop:1b}]

execute as @a[x=0,y=2,z=4,dx=0,dy=1,dz=0,nbt={Dimension:"minecraft:the_end"}] at @s in overworld run fillbiome -24 -8 -24 24 24 24 beach
execute as @a[x=0,y=2,z=4,dx=0,dy=1,dz=0,nbt={Dimension:"minecraft:the_end"}] at @s in minecraft:overworld run clone -16 -64 -16 16 -47 16 -16 0 -16
execute as @a[x=0,y=2,z=4,dx=0,dy=1,dz=0,nbt={Dimension:"minecraft:the_end"}] at @s in minecraft:overworld run tp @s 0 10 0 0 -90

tag @a remove ending_music